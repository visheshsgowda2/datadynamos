"""
Shared authentication utilities
"""

from typing import Optional, Dict, Any
from enum import Enum

class UserRole(str, Enum):
    CEO = "ceo"
    FACILITY_MANAGER = "facility_manager"
    BUILDING_ADMIN = "building_admin"
    RECEPTIONIST = "receptionist"
    EMPLOYEE = "employee"
    AUDITOR = "auditor"
    SECURITY = "security"

class Permission(str, Enum):
    # Campus level
    CAMPUS_READ = "campus:read"
    CAMPUS_WRITE = "campus:write"
    
    # Building level
    BUILDING_READ = "building:read"
    BUILDING_WRITE = "building:write"
    
    # Floor level
    FLOOR_READ = "floor:read"
    FLOOR_WRITE = "floor:write"
    
    # Room level
    ROOM_READ = "room:read"
    ROOM_WRITE = "room:write"
    
    # Device control
    DEVICE_CONTROL = "devices:control"
    
    # Bookings
    BOOKING_READ = "bookings:read"
    BOOKING_WRITE = "bookings:write"
    
    # Reports
    REPORTS_READ = "reports:read"
    BILLING_READ = "billing:read"
    
    # Audit
    AUDIT_READ = "audit:read"
    
    # Alerts
    ALERTS_READ = "alerts:read"
    OCCUPANCY_READ = "occupancy:read"

def get_role_permissions(role: UserRole) -> Dict[str, Any]:
    """Get default permissions for a role"""
    
    role_matrix = {
        UserRole.CEO: {
            "description": "Full system access, strategic oversight",
            "permissions": [
                Permission.CAMPUS_READ,
                Permission.CAMPUS_WRITE,
                Permission.REPORTS_READ,
                Permission.BILLING_READ,
                Permission.AUDIT_READ
            ],
            "scope": "campus",
            "can_control_devices": True,
            "can_view_all_bookings": True,
            "can_generate_reports": True
        },
        
        UserRole.FACILITY_MANAGER: {
            "description": "Building operations and energy management",
            "permissions": [
                Permission.CAMPUS_READ,
                Permission.CAMPUS_WRITE,
                Permission.DEVICE_CONTROL,
                Permission.REPORTS_READ,
                Permission.BOOKING_READ,
                Permission.ALERTS_READ
            ],
            "scope": "campus",
            "can_control_devices": True,
            "can_view_all_bookings": True,
            "can_generate_reports": True
        },
        
        UserRole.BUILDING_ADMIN: {
            "description": "Building-specific management",
            "permissions": [
                Permission.BUILDING_READ,
                Permission.BUILDING_WRITE,
                Permission.DEVICE_CONTROL,
                Permission.BOOKING_READ,
                Permission.BOOKING_WRITE
            ],
            "scope": "building",
            "can_control_devices": True,
            "can_view_all_bookings": False,
            "can_generate_reports": False
        },
        
        UserRole.RECEPTIONIST: {
            "description": "Room booking and basic facility access",
            "permissions": [
                Permission.BOOKING_READ,
                Permission.BOOKING_WRITE,
                Permission.ROOM_READ
            ],
            "scope": "building",
            "can_control_devices": False,
            "can_view_all_bookings": True,
            "can_generate_reports": False
        },
        
        UserRole.EMPLOYEE: {
            "description": "Personal room booking and own-room control",
            "permissions": [
                Permission.ROOM_READ,
                Permission.ROOM_WRITE,
                Permission.BOOKING_READ,
                Permission.BOOKING_WRITE
            ],
            "scope": "own-room",
            "can_control_devices": True,  # Only own rooms
            "can_view_all_bookings": False,
            "can_generate_reports": False
        },
        
        UserRole.AUDITOR: {
            "description": "Read-only access for compliance and reporting",
            "permissions": [
                Permission.CAMPUS_READ,
                Permission.REPORTS_READ,
                Permission.AUDIT_READ,
                Permission.BILLING_READ
            ],
            "scope": "campus",
            "can_control_devices": False,
            "can_view_all_bookings": True,
            "can_generate_reports": True
        },
        
        UserRole.SECURITY: {
            "description": "Security monitoring and occupancy tracking",
            "permissions": [
                Permission.CAMPUS_READ,
                Permission.ALERTS_READ,
                Permission.OCCUPANCY_READ
            ],
            "scope": "campus",
            "can_control_devices": False,
            "can_view_all_bookings": False,
            "can_generate_reports": False
        }
    }
    
    return role_matrix.get(role, {})

def check_permission(user_role: UserRole, required_permission: Permission) -> bool:
    """Check if a role has a specific permission"""
    role_info = get_role_permissions(user_role)
    return required_permission in role_info.get("permissions", [])
