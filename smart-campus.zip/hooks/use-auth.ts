"use client"

import { useState, useEffect } from "react"

interface User {
  id: string
  name: string
  email: string
  role: string
}

export function useAuth() {
  const [user, setUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Mock authentication - in real app, check JWT token
    const mockUser = {
      id: "1",
      name: "Facility Manager",
      email: "fm@demo.local",
      role: "facility_manager",
    }

    setTimeout(() => {
      setUser(mockUser)
      setIsLoading(false)
    }, 1000)
  }, [])

  return { user, isLoading }
}
