-- Smart Campus Database Initialization
-- Enable TimescaleDB extension
CREATE EXTENSION IF NOT EXISTS timescaledb;

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Users and Authentication
CREATE TABLE users (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    role VARCHAR(50) NOT NULL CHECK (role IN ('ceo', 'facility_manager', 'building_admin', 'receptionist', 'employee', 'auditor', 'security')),
    dept VARCHAR(100),
    password_hash VARCHAR(255) NOT NULL,
    status VARCHAR(20) DEFAULT 'active' CHECK (status IN ('active', 'inactive', 'suspended')),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Building Hierarchy
CREATE TABLE buildings (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    address TEXT,
    geofence JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE floors (
    id VARCHAR(50) PRIMARY KEY,
    building_id VARCHAR(50) REFERENCES buildings(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    number INTEGER NOT NULL,
    floor_plan_url TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE rooms (
    id VARCHAR(50) PRIMARY KEY,
    floor_id VARCHAR(50) REFERENCES floors(id) ON DELETE CASCADE,
    name VARCHAR(255) NOT NULL,
    capacity INTEGER DEFAULT 0,
    amenities JSONB DEFAULT '[]',
    area_sqm DECIMAL(10,2),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- User Assignments (RBAC)
CREATE TABLE assignments (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    building_id VARCHAR(50) REFERENCES buildings(id) ON DELETE CASCADE,
    floor_id VARCHAR(50) REFERENCES floors(id) ON DELETE CASCADE,
    room_id VARCHAR(50) REFERENCES rooms(id) ON DELETE CASCADE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Devices
CREATE TABLE devices (
    id VARCHAR(50) PRIMARY KEY,
    room_id VARCHAR(50) REFERENCES rooms(id) ON DELETE CASCADE,
    type VARCHAR(50) NOT NULL CHECK (type IN ('light', 'hvac', 'plug', 'projector', 'sensor')),
    model VARCHAR(100),
    state JSONB DEFAULT '{}',
    last_seen TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Time-series Tables
CREATE TABLE telemetry_ts (
    time TIMESTAMPTZ NOT NULL,
    device_id VARCHAR(50) NOT NULL,
    metric VARCHAR(100) NOT NULL,
    value DOUBLE PRECISION NOT NULL,
    tags JSONB DEFAULT '{}',
    FOREIGN KEY (device_id) REFERENCES devices(id) ON DELETE CASCADE
);

-- Convert to hypertable
SELECT create_hypertable('telemetry_ts', 'time');

CREATE TABLE energy_ts (
    time TIMESTAMPTZ NOT NULL,
    room_id VARCHAR(50) NOT NULL,
    kw DOUBLE PRECISION NOT NULL,
    kwh_rollup DOUBLE PRECISION DEFAULT 0,
    FOREIGN KEY (room_id) REFERENCES rooms(id) ON DELETE CASCADE
);

-- Convert to hypertable
SELECT create_hypertable('energy_ts', 'time');

-- Bookings
CREATE TABLE bookings (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    room_id VARCHAR(50) REFERENCES rooms(id) ON DELETE CASCADE,
    user_id UUID REFERENCES users(id) ON DELETE CASCADE,
    start_ts TIMESTAMPTZ NOT NULL,
    end_ts TIMESTAMPTZ NOT NULL,
    status VARCHAR(20) DEFAULT 'confirmed' CHECK (status IN ('confirmed', 'checked_in', 'completed', 'cancelled', 'auto_released')),
    purpose TEXT,
    attendees INTEGER DEFAULT 1,
    checkin_ts TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Policies and Scenes
CREATE TABLE policies (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    name VARCHAR(255) NOT NULL,
    scope JSONB NOT NULL,
    rule_dsl TEXT NOT NULL,
    enabled BOOLEAN DEFAULT true,
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE scenes (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    payload JSONB NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Anomalies
CREATE TABLE anomalies (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    room_id VARCHAR(50) REFERENCES rooms(id) ON DELETE CASCADE,
    device_id VARCHAR(50) REFERENCES devices(id) ON DELETE CASCADE,
    metric VARCHAR(100) NOT NULL,
    baseline DOUBLE PRECISION NOT NULL,
    observed DOUBLE PRECISION NOT NULL,
    delta_pct DOUBLE PRECISION NOT NULL,
    severity VARCHAR(20) CHECK (severity IN ('low', 'medium', 'high', 'critical')),
    status VARCHAR(20) DEFAULT 'open' CHECK (status IN ('open', 'acknowledged', 'resolved')),
    explanation TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    acknowledged_at TIMESTAMPTZ,
    acknowledged_by UUID REFERENCES users(id)
);

-- Billing
CREATE TABLE bills (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    building_id VARCHAR(50) REFERENCES buildings(id) ON DELETE CASCADE,
    period_start DATE NOT NULL,
    period_end DATE NOT NULL,
    energy_kwh DOUBLE PRECISION NOT NULL,
    demand_kw DOUBLE PRECISION NOT NULL,
    tariff JSONB NOT NULL,
    cost_currency VARCHAR(3) DEFAULT 'USD',
    cost_total DECIMAL(12,2) NOT NULL,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Reports
CREATE TABLE reports (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    type VARCHAR(50) NOT NULL,
    period_start DATE,
    period_end DATE,
    url TEXT,
    signer JSONB,
    sha256 VARCHAR(64),
    created_by UUID REFERENCES users(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Audit Logs
CREATE TABLE audit_logs (
    id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id UUID REFERENCES users(id),
    action VARCHAR(100) NOT NULL,
    resource VARCHAR(100) NOT NULL,
    resource_id VARCHAR(100),
    scope JSONB,
    metadata JSONB DEFAULT '{}',
    ip_address INET,
    user_agent TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Indexes for performance
CREATE INDEX idx_telemetry_device_time ON telemetry_ts (device_id, time DESC);
CREATE INDEX idx_telemetry_metric_time ON telemetry_ts (metric, time DESC);
CREATE INDEX idx_energy_room_time ON energy_ts (room_id, time DESC);
CREATE INDEX idx_bookings_room_time ON bookings (room_id, start_ts, end_ts);
CREATE INDEX idx_bookings_user ON bookings (user_id);
CREATE INDEX idx_anomalies_status ON anomalies (status, created_at DESC);
CREATE INDEX idx_audit_logs_user_time ON audit_logs (user_id, created_at DESC);
CREATE INDEX idx_devices_room ON devices (room_id);
CREATE INDEX idx_assignments_user ON assignments (user_id);

-- Materialized Views for Performance
CREATE MATERIALIZED VIEW room_current_state AS
SELECT 
    r.id as room_id,
    r.name as room_name,
    f.name as floor_name,
    b.name as building_name,
    COALESCE(latest_energy.kw, 0) as current_kw,
    COALESCE(latest_occupancy.value, 0) as occupancy,
    COALESCE(latest_temp.value, 20) as temperature,
    COUNT(d.id) as device_count,
    COUNT(CASE WHEN d.type = 'light' THEN 1 END) as light_count,
    COUNT(CASE WHEN d.type = 'hvac' THEN 1 END) as hvac_count
FROM rooms r
JOIN floors f ON r.floor_id = f.id
JOIN buildings b ON f.building_id = b.id
LEFT JOIN devices d ON r.id = d.room_id
LEFT JOIN LATERAL (
    SELECT kw FROM energy_ts 
    WHERE room_id = r.id 
    ORDER BY time DESC LIMIT 1
) latest_energy ON true
LEFT JOIN LATERAL (
    SELECT value FROM telemetry_ts t
    JOIN devices dev ON t.device_id = dev.id
    WHERE dev.room_id = r.id AND t.metric = 'occupancy'
    ORDER BY time DESC LIMIT 1
) latest_occupancy ON true
LEFT JOIN LATERAL (
    SELECT value FROM telemetry_ts t
    JOIN devices dev ON t.device_id = dev.id
    WHERE dev.room_id = r.id AND t.metric = 'temperature'
    ORDER BY time DESC LIMIT 1
) latest_temp ON true
GROUP BY r.id, r.name, f.name, b.name, latest_energy.kw, latest_occupancy.value, latest_temp.value;

-- Refresh materialized view function
CREATE OR REPLACE FUNCTION refresh_room_current_state()
RETURNS void AS $$
BEGIN
    REFRESH MATERIALIZED VIEW room_current_state;
END;
$$ LANGUAGE plpgsql;

-- Set up automatic refresh (every minute)
-- Note: In production, use pg_cron or external scheduler
