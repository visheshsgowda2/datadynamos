"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { FileText, Download, TrendingUp, Leaf, DollarSign, Building, BarChart3 } from "lucide-react"
import { format } from "date-fns"
import { useAuth } from "@/hooks/use-auth"

interface Report {
  id: number
  title: string
  type: "energy_bill" | "compliance" | "analytics"
  status: "generating" | "completed" | "failed"
  building_name: string
  generated_at: string
  compliance_score?: number
  total_cost?: number
}

interface EnergyMetrics {
  current_consumption: number
  today_consumption: number
  today_cost: number
  carbon_footprint_today: number
  active_rooms: number
}

export default function ReportsPage() {
  const { user } = useAuth()
  const [activeTab, setActiveTab] = useState("overview")
  const [selectedBuilding, setSelectedBuilding] = useState<string>("all")
  const [reports, setReports] = useState<Report[]>([])
  const [energyMetrics, setEnergyMetrics] = useState<EnergyMetrics | null>(null)
  const [isGenerating, setIsGenerating] = useState(false)

  // Mock data - replace with actual API calls
  useEffect(() => {
    setReports([
      {
        id: 1,
        title: "January 2024 Energy Bill",
        type: "energy_bill",
        status: "completed",
        building_name: "Main Building",
        generated_at: new Date().toISOString(),
        total_cost: 2450.75,
      },
      {
        id: 2,
        title: "Q4 2023 Compliance Report",
        type: "compliance",
        status: "completed",
        building_name: "Main Building",
        generated_at: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
        compliance_score: 87.5,
      },
      {
        id: 3,
        title: "Energy Analytics - Last 30 Days",
        type: "analytics",
        status: "generating",
        building_name: "All Buildings",
        generated_at: new Date().toISOString(),
      },
    ])

    setEnergyMetrics({
      current_consumption: 125.5,
      today_consumption: 2840.2,
      today_cost: 340.82,
      carbon_footprint_today: 1136.1,
      active_rooms: 45,
    })
  }, [])

  const handleGenerateReport = async (type: string) => {
    setIsGenerating(true)
    try {
      console.log("Generating report:", type)
      // API call to generate report
      await new Promise((resolve) => setTimeout(resolve, 2000)) // Mock delay

      // Add new report to list
      const newReport: Report = {
        id: Date.now(),
        title: `${type === "energy_bill" ? "Energy Bill" : type === "compliance" ? "Compliance Report" : "Analytics Report"} - ${format(new Date(), "MMM yyyy")}`,
        type: type as any,
        status: "generating",
        building_name: selectedBuilding === "all" ? "All Buildings" : "Main Building",
        generated_at: new Date().toISOString(),
      }

      setReports((prev) => [newReport, ...prev])
    } catch (error) {
      console.error("Error generating report:", error)
    } finally {
      setIsGenerating(false)
    }
  }

  const handleDownloadReport = (reportId: number) => {
    console.log("Downloading report:", reportId)
    // API call to download report
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge variant="default">Completed</Badge>
      case "generating":
        return <Badge variant="secondary">Generating...</Badge>
      case "failed":
        return <Badge variant="destructive">Failed</Badge>
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  const getReportIcon = (type: string) => {
    switch (type) {
      case "energy_bill":
        return <DollarSign className="h-4 w-4" />
      case "compliance":
        return <Leaf className="h-4 w-4" />
      case "analytics":
        return <BarChart3 className="h-4 w-4" />
      default:
        return <FileText className="h-4 w-4" />
    }
  }

  return (
    <div className="container mx-auto py-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Reports & Analytics</h1>
          <p className="text-muted-foreground">Generate and manage energy reports and compliance documentation</p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={selectedBuilding} onValueChange={setSelectedBuilding}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Buildings</SelectItem>
              <SelectItem value="1">Main Building</SelectItem>
              <SelectItem value="2">Executive Building</SelectItem>
              <SelectItem value="3">Training Center</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Real-time Metrics */}
      {energyMetrics && (
        <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Current Usage</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{energyMetrics.current_consumption} kWh</div>
              <p className="text-xs text-muted-foreground">This hour</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Today's Consumption</CardTitle>
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{energyMetrics.today_consumption.toLocaleString()} kWh</div>
              <p className="text-xs text-muted-foreground">+12% from yesterday</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Today's Cost</CardTitle>
              <DollarSign className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">${energyMetrics.today_cost}</div>
              <p className="text-xs text-muted-foreground">$0.12 per kWh</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Carbon Footprint</CardTitle>
              <Leaf className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{energyMetrics.carbon_footprint_today.toLocaleString()} kg</div>
              <p className="text-xs text-muted-foreground">CO₂ today</p>
            </CardContent>
          </Card>

          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Active Rooms</CardTitle>
              <Building className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{energyMetrics.active_rooms}</div>
              <p className="text-xs text-muted-foreground">Currently occupied</p>
            </CardContent>
          </Card>
        </div>
      )}

      {/* Reports Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="energy-bills">Energy Bills</TabsTrigger>
          <TabsTrigger value="compliance">Compliance</TabsTrigger>
          <TabsTrigger value="analytics">Analytics</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          {/* Quick Actions */}
          <Card>
            <CardHeader>
              <CardTitle>Generate New Report</CardTitle>
              <CardDescription>Create energy bills, compliance reports, and analytics</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <Button
                  onClick={() => handleGenerateReport("energy_bill")}
                  disabled={isGenerating}
                  className="h-20 flex-col gap-2"
                >
                  <DollarSign className="h-6 w-6" />
                  Energy Bill
                </Button>
                <Button
                  onClick={() => handleGenerateReport("compliance")}
                  disabled={isGenerating}
                  variant="outline"
                  className="h-20 flex-col gap-2"
                >
                  <Leaf className="h-6 w-6" />
                  Compliance Report
                </Button>
                <Button
                  onClick={() => handleGenerateReport("analytics")}
                  disabled={isGenerating}
                  variant="outline"
                  className="h-20 flex-col gap-2"
                >
                  <BarChart3 className="h-6 w-6" />
                  Analytics Report
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Recent Reports */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Reports</CardTitle>
              <CardDescription>Latest generated reports and their status</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {reports.slice(0, 5).map((report) => (
                  <div key={report.id} className="flex items-center justify-between p-3 border rounded-lg">
                    <div className="flex items-center gap-3">
                      {getReportIcon(report.type)}
                      <div>
                        <h4 className="font-medium">{report.title}</h4>
                        <p className="text-sm text-muted-foreground">
                          {report.building_name} • {format(new Date(report.generated_at), "MMM d, yyyy")}
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3">
                      {getStatusBadge(report.status)}
                      {report.status === "completed" && (
                        <Button size="sm" variant="outline" onClick={() => handleDownloadReport(report.id)}>
                          <Download className="h-4 w-4 mr-1" />
                          Download
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="energy-bills" className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Energy Bills</h3>
            <Button onClick={() => handleGenerateReport("energy_bill")} disabled={isGenerating}>
              <FileText className="mr-2 h-4 w-4" />
              Generate Bill
            </Button>
          </div>

          <div className="grid gap-4">
            {reports
              .filter((r) => r.type === "energy_bill")
              .map((report) => (
                <Card key={report.id}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <DollarSign className="h-5 w-5 text-green-600" />
                        <div>
                          <h4 className="font-medium">{report.title}</h4>
                          <p className="text-sm text-muted-foreground">
                            {report.building_name} • Generated{" "}
                            {format(new Date(report.generated_at), "MMM d, yyyy HH:mm")}
                          </p>
                          {report.total_cost && (
                            <p className="text-sm font-medium text-green-600">
                              Total Cost: ${report.total_cost.toLocaleString()}
                            </p>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        {getStatusBadge(report.status)}
                        {report.status === "completed" && (
                          <Button size="sm" variant="outline" onClick={() => handleDownloadReport(report.id)}>
                            <Download className="h-4 w-4 mr-1" />
                            Download
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
          </div>
        </TabsContent>

        <TabsContent value="compliance" className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Compliance Reports</h3>
            <Button onClick={() => handleGenerateReport("compliance")} disabled={isGenerating}>
              <Leaf className="mr-2 h-4 w-4" />
              Generate Report
            </Button>
          </div>

          <div className="grid gap-4">
            {reports
              .filter((r) => r.type === "compliance")
              .map((report) => (
                <Card key={report.id}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Leaf className="h-5 w-5 text-green-600" />
                        <div>
                          <h4 className="font-medium">{report.title}</h4>
                          <p className="text-sm text-muted-foreground">
                            {report.building_name} • Generated{" "}
                            {format(new Date(report.generated_at), "MMM d, yyyy HH:mm")}
                          </p>
                          {report.compliance_score && (
                            <p className="text-sm font-medium">Compliance Score: {report.compliance_score}%</p>
                          )}
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        {getStatusBadge(report.status)}
                        {report.status === "completed" && (
                          <Button size="sm" variant="outline" onClick={() => handleDownloadReport(report.id)}>
                            <Download className="h-4 w-4 mr-1" />
                            Download
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
          </div>
        </TabsContent>

        <TabsContent value="analytics" className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-lg font-semibold">Analytics Reports</h3>
            <Button onClick={() => handleGenerateReport("analytics")} disabled={isGenerating}>
              <BarChart3 className="mr-2 h-4 w-4" />
              Generate Analytics
            </Button>
          </div>

          <div className="grid gap-4">
            {reports
              .filter((r) => r.type === "analytics")
              .map((report) => (
                <Card key={report.id}>
                  <CardContent className="p-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <BarChart3 className="h-5 w-5 text-blue-600" />
                        <div>
                          <h4 className="font-medium">{report.title}</h4>
                          <p className="text-sm text-muted-foreground">
                            {report.building_name} • Generated{" "}
                            {format(new Date(report.generated_at), "MMM d, yyyy HH:mm")}
                          </p>
                        </div>
                      </div>
                      <div className="flex items-center gap-3">
                        {getStatusBadge(report.status)}
                        {report.status === "completed" && (
                          <Button size="sm" variant="outline" onClick={() => handleDownloadReport(report.id)}>
                            <Download className="h-4 w-4 mr-1" />
                            Download
                          </Button>
                        )}
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
