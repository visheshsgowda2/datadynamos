"use client"

import { useState } from "react"
import { DashboardLayout } from "@/components/dashboard/dashboard-layout"
import { DashboardOverview } from "@/components/dashboard/dashboard-overview"
import { EnergyHeatmap } from "@/components/dashboard/energy-heatmap"
import { DeviceControls } from "@/components/dashboard/device-controls"
import { AlertsPanel } from "@/components/dashboard/alerts-panel"
import { ReportsSection } from "@/components/dashboard/reports-section"
import { useAuth } from "@/hooks/use-auth"
import { LoginForm } from "@/components/auth/login-form"

export default function HomePage() {
  const { user, isLoading } = useAuth()
  const [activeView, setActiveView] = useState("dashboard")

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="glass rounded-lg p-8">
          <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary mx-auto"></div>
          <p className="text-muted-foreground mt-4 text-center">Loading Smart Campus...</p>
        </div>
      </div>
    )
  }

  if (!user) {
    return <LoginForm />
  }

  const renderActiveView = () => {
    switch (activeView) {
      case "dashboard":
        return <DashboardOverview />
      case "heatmap":
        return <EnergyHeatmap />
      case "controls":
        return <DeviceControls />
      case "alerts":
        return <AlertsPanel />
      case "reports":
        return <ReportsSection />
      default:
        return <DashboardOverview />
    }
  }

  return (
    <DashboardLayout activeView={activeView} onViewChange={setActiveView}>
      {renderActiveView()}
    </DashboardLayout>
  )
}
