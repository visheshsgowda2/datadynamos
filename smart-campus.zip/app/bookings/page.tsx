"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { BookingForm, type BookingFormData } from "@/components/booking/booking-form"
import { BookingList } from "@/components/booking/booking-list"
import { Plus, Calendar, TrendingUp } from "lucide-react"
import { useAuth } from "@/hooks/use-auth"

interface Room {
  id: number
  name: string
  capacity: number
  building_name: string
}

interface Booking {
  id: number
  room_id: number
  room_name: string
  start_time: string
  end_time: string
  purpose: string
  attendees: number
  status: "confirmed" | "checked_in" | "completed" | "cancelled" | "auto_released"
  check_in_code: string
  checked_in_at?: string
  user_name: string
}

export default function BookingsPage() {
  const { user } = useAuth()
  const [activeTab, setActiveTab] = useState("my-bookings")
  const [showBookingForm, setShowBookingForm] = useState(false)
  const [rooms, setRooms] = useState<Room[]>([])
  const [bookings, setBookings] = useState<Booking[]>([])
  const [isLoading, setIsLoading] = useState(false)

  // Mock data - replace with actual API calls
  useEffect(() => {
    // Load rooms
    setRooms([
      { id: 1, name: "Conference Room A", capacity: 12, building_name: "Main Building" },
      { id: 2, name: "Meeting Room B", capacity: 6, building_name: "Main Building" },
      { id: 3, name: "Boardroom", capacity: 20, building_name: "Executive Building" },
      { id: 4, name: "Training Room", capacity: 30, building_name: "Training Center" },
    ])

    // Load bookings
    setBookings([
      {
        id: 1,
        room_id: 1,
        room_name: "Conference Room A",
        start_time: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(), // 2 hours from now
        end_time: new Date(Date.now() + 3 * 60 * 60 * 1000).toISOString(),
        purpose: "Weekly Team Standup",
        attendees: 8,
        status: "confirmed",
        check_in_code: "ABC12345",
        user_name: "John Doe",
      },
      {
        id: 2,
        room_id: 2,
        room_name: "Meeting Room B",
        start_time: new Date(Date.now() - 30 * 60 * 1000).toISOString(), // 30 min ago
        end_time: new Date(Date.now() + 30 * 60 * 1000).toISOString(),
        purpose: "Client Presentation",
        attendees: 4,
        status: "checked_in",
        check_in_code: "XYZ67890",
        checked_in_at: new Date(Date.now() - 25 * 60 * 1000).toISOString(),
        user_name: "Jane Smith",
      },
    ])
  }, [])

  const handleCreateBooking = async (bookingData: BookingFormData) => {
    setIsLoading(true)
    try {
      // API call to create booking
      console.log("Creating booking:", bookingData)

      // Mock success
      await new Promise((resolve) => setTimeout(resolve, 1000))

      setShowBookingForm(false)
      // Refresh bookings list
    } catch (error) {
      console.error("Error creating booking:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleCheckIn = async (bookingId: number, checkInCode: string) => {
    try {
      console.log("Checking in to booking:", bookingId, "with code:", checkInCode)
      // API call to check in

      // Update local state
      setBookings((prev) =>
        prev.map((booking) =>
          booking.id === bookingId
            ? { ...booking, status: "checked_in" as const, checked_in_at: new Date().toISOString() }
            : booking,
        ),
      )
    } catch (error) {
      console.error("Error checking in:", error)
    }
  }

  const handleCancelBooking = async (bookingId: number) => {
    try {
      console.log("Cancelling booking:", bookingId)
      // API call to cancel booking

      // Update local state
      setBookings((prev) =>
        prev.map((booking) => (booking.id === bookingId ? { ...booking, status: "cancelled" as const } : booking)),
      )
    } catch (error) {
      console.error("Error cancelling booking:", error)
    }
  }

  const handleExtendBooking = async (bookingId: number, minutes: number) => {
    try {
      console.log("Extending booking:", bookingId, "by", minutes, "minutes")
      // API call to extend booking

      // Update local state
      setBookings((prev) =>
        prev.map((booking) =>
          booking.id === bookingId
            ? {
                ...booking,
                end_time: new Date(new Date(booking.end_time).getTime() + minutes * 60 * 1000).toISOString(),
              }
            : booking,
        ),
      )
    } catch (error) {
      console.error("Error extending booking:", error)
    }
  }

  const myBookings = bookings.filter((booking) => booking.user_name === user?.full_name)
  const allBookings = bookings

  if (showBookingForm) {
    return (
      <div className="container mx-auto py-8">
        <BookingForm
          rooms={rooms}
          onSubmit={handleCreateBooking}
          onCancel={() => setShowBookingForm(false)}
          isLoading={isLoading}
        />
      </div>
    )
  }

  return (
    <div className="container mx-auto py-8 space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold">Room Bookings</h1>
          <p className="text-muted-foreground">Manage your meeting room reservations</p>
        </div>
        <Button onClick={() => setShowBookingForm(true)}>
          <Plus className="mr-2 h-4 w-4" />
          New Booking
        </Button>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">My Active Bookings</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {myBookings.filter((b) => b.status === "confirmed" || b.status === "checked_in").length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Check-in Rate</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">85%</div>
            <p className="text-xs text-muted-foreground">+2% from last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Available Rooms</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{rooms.length}</div>
            <p className="text-xs text-muted-foreground">Across all buildings</p>
          </CardContent>
        </Card>
      </div>

      {/* Bookings Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="my-bookings">My Bookings</TabsTrigger>
          {(user?.role === "facility_manager" || user?.role === "building_admin") && (
            <TabsTrigger value="all-bookings">All Bookings</TabsTrigger>
          )}
        </TabsList>

        <TabsContent value="my-bookings" className="space-y-4">
          <BookingList
            bookings={myBookings}
            onCheckIn={handleCheckIn}
            onCancel={handleCancelBooking}
            onExtend={handleExtendBooking}
            currentUserId={user?.id}
          />
        </TabsContent>

        {(user?.role === "facility_manager" || user?.role === "building_admin") && (
          <TabsContent value="all-bookings" className="space-y-4">
            <BookingList
              bookings={allBookings}
              onCheckIn={handleCheckIn}
              onCancel={handleCancelBooking}
              onExtend={handleExtendBooking}
              showUserColumn={true}
            />
          </TabsContent>
        )}
      </Tabs>
    </div>
  )
}
