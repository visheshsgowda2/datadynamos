"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { FileText, Download, TrendingUp, Leaf, DollarSign, BarChart3, Calendar, Clock } from "lucide-react"
import { format } from "date-fns"

interface Report {
  id: number
  title: string
  type: "energy_bill" | "compliance" | "analytics"
  status: "generating" | "completed" | "failed"
  building_name: string
  generated_at: string
  file_size?: string
  compliance_score?: number
  total_cost?: number
  progress?: number
}

export function ReportsSection() {
  const [reports, setReports] = useState<Report[]>([])
  const [isGenerating, setIsGenerating] = useState(false)

  // Mock data - replace with actual API calls
  useEffect(() => {
    const mockReports: Report[] = [
      {
        id: 1,
        title: "January 2024 Energy Bill",
        type: "energy_bill",
        status: "completed",
        building_name: "Main Building",
        generated_at: new Date().toISOString(),
        file_size: "2.4 MB",
        total_cost: 2450.75,
      },
      {
        id: 2,
        title: "Q4 2023 Compliance Report",
        type: "compliance",
        status: "completed",
        building_name: "Main Building",
        generated_at: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
        file_size: "5.1 MB",
        compliance_score: 87.5,
      },
      {
        id: 3,
        title: "Energy Analytics - Last 30 Days",
        type: "analytics",
        status: "generating",
        building_name: "All Buildings",
        generated_at: new Date().toISOString(),
        progress: 65,
      },
      {
        id: 4,
        title: "December 2023 Energy Bill",
        type: "energy_bill",
        status: "completed",
        building_name: "Executive Building",
        generated_at: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000).toISOString(),
        file_size: "1.8 MB",
        total_cost: 1890.25,
      },
    ]

    setReports(mockReports)
  }, [])

  const handleGenerateReport = async (type: string) => {
    setIsGenerating(true)
    try {
      console.log("Generating report:", type)
      // API call to generate report
      await new Promise((resolve) => setTimeout(resolve, 2000)) // Mock delay

      // Add new report to list
      const newReport: Report = {
        id: Date.now(),
        title: `${type === "energy_bill" ? "Energy Bill" : type === "compliance" ? "Compliance Report" : "Analytics Report"} - ${format(new Date(), "MMM yyyy")}`,
        type: type as any,
        status: "generating",
        building_name: "Main Building",
        generated_at: new Date().toISOString(),
        progress: 0,
      }

      setReports((prev) => [newReport, ...prev])

      // Simulate progress updates
      let progress = 0
      const progressInterval = setInterval(() => {
        progress += Math.random() * 20
        if (progress >= 100) {
          progress = 100
          clearInterval(progressInterval)
          // Mark as completed
          setReports((prev) =>
            prev.map((report) =>
              report.id === newReport.id
                ? { ...report, status: "completed", progress: undefined, file_size: "3.2 MB" }
                : report,
            ),
          )
        }
        setReports((prev) => prev.map((report) => (report.id === newReport.id ? { ...report, progress } : report)))
      }, 500)
    } catch (error) {
      console.error("Error generating report:", error)
    } finally {
      setIsGenerating(false)
    }
  }

  const handleDownloadReport = (reportId: number) => {
    console.log("Downloading report:", reportId)
    // API call to download report
  }

  const getReportIcon = (type: string) => {
    switch (type) {
      case "energy_bill":
        return <DollarSign className="h-5 w-5 text-green-600" />
      case "compliance":
        return <Leaf className="h-5 w-5 text-green-600" />
      case "analytics":
        return <BarChart3 className="h-5 w-5 text-blue-600" />
      default:
        return <FileText className="h-5 w-5" />
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return <Badge variant="default">Completed</Badge>
      case "generating":
        return <Badge variant="secondary">Generating...</Badge>
      case "failed":
        return <Badge variant="destructive">Failed</Badge>
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  const getTypeLabel = (type: string) => {
    switch (type) {
      case "energy_bill":
        return "Energy Bill"
      case "compliance":
        return "Compliance Report"
      case "analytics":
        return "Analytics Report"
      default:
        return "Report"
    }
  }

  const recentReports = reports.slice(0, 6)
  const completedReports = reports.filter((r) => r.status === "completed")

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Reports & Analytics</h2>
          <p className="text-muted-foreground">Generate and manage energy reports and compliance documentation</p>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Reports</CardTitle>
            <FileText className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{reports.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">This Month</CardTitle>
            <Calendar className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {reports.filter((r) => new Date(r.generated_at).getMonth() === new Date().getMonth()).length}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Generating</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{reports.filter((r) => r.status === "generating").length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Avg. Compliance</CardTitle>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">
              {Math.round(
                reports.filter((r) => r.compliance_score).reduce((acc, r) => acc + (r.compliance_score || 0), 0) /
                  reports.filter((r) => r.compliance_score).length || 0,
              )}
              %
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Generate New Report</CardTitle>
          <CardDescription>Create energy bills, compliance reports, and analytics</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Button
              onClick={() => handleGenerateReport("energy_bill")}
              disabled={isGenerating}
              className="h-20 flex-col gap-2"
            >
              <DollarSign className="h-6 w-6" />
              Energy Bill
            </Button>
            <Button
              onClick={() => handleGenerateReport("compliance")}
              disabled={isGenerating}
              variant="outline"
              className="h-20 flex-col gap-2"
            >
              <Leaf className="h-6 w-6" />
              Compliance Report
            </Button>
            <Button
              onClick={() => handleGenerateReport("analytics")}
              disabled={isGenerating}
              variant="outline"
              className="h-20 flex-col gap-2"
            >
              <BarChart3 className="h-6 w-6" />
              Analytics Report
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Recent Reports */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Reports</CardTitle>
          <CardDescription>Latest generated reports and their status</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentReports.map((report) => (
              <div key={report.id} className="flex items-center justify-between p-4 border rounded-lg">
                <div className="flex items-center gap-3 flex-1">
                  {getReportIcon(report.type)}
                  <div className="flex-1">
                    <div className="flex items-center gap-2 mb-1">
                      <h4 className="font-medium">{report.title}</h4>
                      {getStatusBadge(report.status)}
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {report.building_name} • {format(new Date(report.generated_at), "MMM d, yyyy HH:mm")}
                    </p>
                    {report.file_size && <p className="text-xs text-muted-foreground mt-1">Size: {report.file_size}</p>}
                    {report.total_cost && (
                      <p className="text-sm font-medium text-green-600 mt-1">
                        Total Cost: ${report.total_cost.toLocaleString()}
                      </p>
                    )}
                    {report.compliance_score && (
                      <p className="text-sm font-medium mt-1">Compliance Score: {report.compliance_score}%</p>
                    )}
                    {report.status === "generating" && report.progress !== undefined && (
                      <div className="mt-2">
                        <div className="flex items-center justify-between text-sm mb-1">
                          <span>Generating...</span>
                          <span>{Math.round(report.progress)}%</span>
                        </div>
                        <Progress value={report.progress} className="h-2" />
                      </div>
                    )}
                  </div>
                </div>
                <div className="flex items-center gap-2">
                  {report.status === "completed" && (
                    <Button size="sm" variant="outline" onClick={() => handleDownloadReport(report.id)}>
                      <Download className="h-4 w-4 mr-1" />
                      Download
                    </Button>
                  )}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
