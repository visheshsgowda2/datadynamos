"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Thermometer, Zap, Users, Settings, Eye, EyeOff } from "lucide-react"
import { cn } from "@/lib/utils"

interface Room {
  id: number
  name: string
  floor: number
  x: number
  y: number
  width: number
  height: number
  temperature: number
  energy_consumption: number
  occupancy: number
  capacity: number
  status: "normal" | "high" | "critical"
}

interface Building {
  id: number
  name: string
  floors: number
}

export function EnergyHeatmap() {
  const [selectedBuilding, setSelectedBuilding] = useState("1")
  const [selectedFloor, setSelectedFloor] = useState("1")
  const [heatmapMode, setHeatmapMode] = useState<"energy" | "temperature" | "occupancy">("energy")
  const [selectedRoom, setSelectedRoom] = useState<Room | null>(null)
  const [showLabels, setShowLabels] = useState(true)
  const [rooms, setRooms] = useState<Room[]>([])
  const [buildings, setBuildings] = useState<Building[]>([])

  // Mock data - replace with actual API calls
  useEffect(() => {
    setBuildings([
      { id: 1, name: "Main Building", floors: 3 },
      { id: 2, name: "Executive Building", floors: 2 },
      { id: 3, name: "Training Center", floors: 1 },
    ])

    // Generate mock room data for floor plan
    const mockRooms: Room[] = [
      {
        id: 101,
        name: "Conference Room A",
        floor: 1,
        x: 50,
        y: 50,
        width: 120,
        height: 80,
        temperature: 22.5,
        energy_consumption: 8.2,
        occupancy: 6,
        capacity: 12,
        status: "normal",
      },
      {
        id: 102,
        name: "Meeting Room B",
        floor: 1,
        x: 200,
        y: 50,
        width: 100,
        height: 60,
        temperature: 24.1,
        energy_consumption: 12.8,
        occupancy: 0,
        capacity: 8,
        status: "high",
      },
      {
        id: 103,
        name: "Open Office",
        floor: 1,
        x: 50,
        y: 160,
        width: 200,
        height: 120,
        temperature: 23.2,
        energy_consumption: 25.6,
        occupancy: 18,
        capacity: 24,
        status: "normal",
      },
      {
        id: 104,
        name: "Break Room",
        floor: 1,
        x: 280,
        y: 160,
        width: 80,
        height: 60,
        temperature: 26.8,
        energy_consumption: 15.4,
        occupancy: 3,
        capacity: 10,
        status: "critical",
      },
      {
        id: 105,
        name: "Server Room",
        floor: 1,
        x: 280,
        y: 240,
        width: 80,
        height: 40,
        temperature: 18.5,
        energy_consumption: 45.2,
        occupancy: 0,
        capacity: 2,
        status: "critical",
      },
    ]

    setRooms(mockRooms)
  }, [])

  const getHeatmapColor = (room: Room) => {
    let intensity = 0
    let maxValue = 1

    switch (heatmapMode) {
      case "energy":
        intensity = room.energy_consumption
        maxValue = 50 // Max expected energy consumption
        break
      case "temperature":
        intensity = Math.abs(room.temperature - 22) // Deviation from ideal 22°C
        maxValue = 8 // Max deviation
        break
      case "occupancy":
        intensity = room.occupancy / room.capacity
        maxValue = 1
        break
    }

    const normalizedIntensity = Math.min(intensity / maxValue, 1)

    if (heatmapMode === "energy") {
      // Energy: Green (low) to Red (high)
      const red = Math.round(255 * normalizedIntensity)
      const green = Math.round(255 * (1 - normalizedIntensity))
      return `rgb(${red}, ${green}, 0)`
    } else if (heatmapMode === "temperature") {
      // Temperature: Blue (cold) to Red (hot)
      if (room.temperature < 22) {
        const blue = Math.round(255 * normalizedIntensity)
        return `rgb(0, 100, ${blue})`
      } else {
        const red = Math.round(255 * normalizedIntensity)
        return `rgb(${red}, 0, 0)`
      }
    } else {
      // Occupancy: Light to Dark blue
      const blue = Math.round(100 + 155 * normalizedIntensity)
      return `rgb(0, 50, ${blue})`
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "normal":
        return "border-green-500"
      case "high":
        return "border-yellow-500"
      case "critical":
        return "border-red-500"
      default:
        return "border-gray-500"
    }
  }

  const handleRoomClick = (room: Room) => {
    setSelectedRoom(room)
  }

  return (
    <div className="space-y-6">
      {/* Header Controls */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Energy Heatmap</h2>
          <p className="text-muted-foreground">Interactive floor plan with real-time energy visualization</p>
        </div>
        <div className="flex items-center gap-3">
          <Button
            variant="outline"
            size="sm"
            onClick={() => setShowLabels(!showLabels)}
            className="flex items-center gap-2"
          >
            {showLabels ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            {showLabels ? "Hide Labels" : "Show Labels"}
          </Button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        {/* Controls Panel */}
        <div className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Controls</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-2">
                <label className="text-sm font-medium">Building</label>
                <Select value={selectedBuilding} onValueChange={setSelectedBuilding}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {buildings.map((building) => (
                      <SelectItem key={building.id} value={building.id.toString()}>
                        {building.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Floor</label>
                <Select value={selectedFloor} onValueChange={setSelectedFloor}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="1">Floor 1</SelectItem>
                    <SelectItem value="2">Floor 2</SelectItem>
                    <SelectItem value="3">Floor 3</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <label className="text-sm font-medium">Heatmap Mode</label>
                <Select value={heatmapMode} onValueChange={(value: any) => setHeatmapMode(value)}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="energy">Energy Consumption</SelectItem>
                    <SelectItem value="temperature">Temperature</SelectItem>
                    <SelectItem value="occupancy">Occupancy</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>

          {/* Legend */}
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Legend</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {heatmapMode === "energy" && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-green-500 rounded"></div>
                      <span className="text-sm">Low Energy (0-15 kWh)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-yellow-500 rounded"></div>
                      <span className="text-sm">Medium Energy (15-30 kWh)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-red-500 rounded"></div>
                      <span className="text-sm">High Energy (30+ kWh)</span>
                    </div>
                  </div>
                )}

                {heatmapMode === "temperature" && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-blue-500 rounded"></div>
                      <span className="text-sm">Cold (&lt;20°C)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-green-500 rounded"></div>
                      <span className="text-sm">Optimal (20-24°C)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-red-500 rounded"></div>
                      <span className="text-sm">Hot (&gt;24°C)</span>
                    </div>
                  </div>
                )}

                {heatmapMode === "occupancy" && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-blue-200 rounded"></div>
                      <span className="text-sm">Empty (0%)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-blue-500 rounded"></div>
                      <span className="text-sm">Partial (1-75%)</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-4 h-4 bg-blue-800 rounded"></div>
                      <span className="text-sm">Full (75%+)</span>
                    </div>
                  </div>
                )}

                <div className="pt-2 border-t">
                  <p className="text-xs text-muted-foreground">Status Indicators:</p>
                  <div className="space-y-1 mt-1">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 border-2 border-green-500 rounded"></div>
                      <span className="text-xs">Normal</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 border-2 border-yellow-500 rounded"></div>
                      <span className="text-xs">Alert</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 border-2 border-red-500 rounded"></div>
                      <span className="text-xs">Critical</span>
                    </div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Floor Plan */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Settings className="h-5 w-5" />
                Floor Plan - {buildings.find((b) => b.id.toString() === selectedBuilding)?.name} (Floor {selectedFloor})
              </CardTitle>
              <CardDescription>Click on rooms to view details and controls</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="relative bg-muted/20 rounded-lg p-4 min-h-[400px]">
                <svg width="100%" height="400" viewBox="0 0 400 300" className="border rounded">
                  {/* Floor outline */}
                  <rect x="20" y="20" width="360" height="260" fill="none" stroke="#e2e8f0" strokeWidth="2" />

                  {/* Rooms */}
                  {rooms.map((room) => (
                    <g key={room.id}>
                      <rect
                        x={room.x}
                        y={room.y}
                        width={room.width}
                        height={room.height}
                        fill={getHeatmapColor(room)}
                        stroke="currentColor"
                        strokeWidth="2"
                        className={cn(
                          "cursor-pointer transition-all hover:stroke-primary hover:stroke-4",
                          getStatusColor(room.status),
                          selectedRoom?.id === room.id && "stroke-primary stroke-4",
                        )}
                        onClick={() => handleRoomClick(room)}
                        opacity="0.8"
                      />
                      {showLabels && (
                        <text
                          x={room.x + room.width / 2}
                          y={room.y + room.height / 2}
                          textAnchor="middle"
                          dominantBaseline="middle"
                          className="text-xs font-medium fill-white"
                          style={{ textShadow: "1px 1px 2px rgba(0,0,0,0.8)" }}
                        >
                          {room.name}
                        </text>
                      )}
                    </g>
                  ))}
                </svg>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Room Details Panel */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">Room Details</CardTitle>
            </CardHeader>
            <CardContent>
              {selectedRoom ? (
                <div className="space-y-4">
                  <div>
                    <h3 className="font-semibold text-lg">{selectedRoom.name}</h3>
                    <p className="text-sm text-muted-foreground">Floor {selectedRoom.floor}</p>
                    <Badge variant={selectedRoom.status === "normal" ? "default" : "destructive"} className="mt-1">
                      {selectedRoom.status}
                    </Badge>
                  </div>

                  <div className="space-y-3">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Thermometer className="h-4 w-4 text-blue-500" />
                        <span className="text-sm">Temperature</span>
                      </div>
                      <span className="font-medium">{selectedRoom.temperature}°C</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Zap className="h-4 w-4 text-yellow-500" />
                        <span className="text-sm">Energy</span>
                      </div>
                      <span className="font-medium">{selectedRoom.energy_consumption} kWh</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Users className="h-4 w-4 text-green-500" />
                        <span className="text-sm">Occupancy</span>
                      </div>
                      <span className="font-medium">
                        {selectedRoom.occupancy}/{selectedRoom.capacity}
                      </span>
                    </div>
                  </div>

                  <div className="pt-4 border-t">
                    <Button size="sm" className="w-full">
                      Control Devices
                    </Button>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8">
                  <Settings className="h-12 w-12 text-muted-foreground mx-auto mb-3" />
                  <p className="text-muted-foreground">Select a room to view details</p>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
