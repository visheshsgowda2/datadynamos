"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Progress } from "@/components/ui/progress"
import { Zap, TrendingUp, AlertTriangle, DollarSign, Users, Thermometer, Activity, Target } from "lucide-react"
import { AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts"

// Mock data - in real app, this would come from API
const energyData = [
  { time: "00:00", kw: 45 },
  { time: "04:00", kw: 32 },
  { time: "08:00", kw: 78 },
  { time: "12:00", kw: 95 },
  { time: "16:00", kw: 87 },
  { time: "20:00", kw: 56 },
  { time: "24:00", kw: 41 },
]

const buildingData = [
  { name: "Main Campus", current: 85, forecast: 92, efficiency: 87 },
  { name: "Tech Center", current: 67, forecast: 71, efficiency: 91 },
  { name: "Admin Building", current: 43, forecast: 48, efficiency: 89 },
]

export function DashboardOverview() {
  const [currentTime, setCurrentTime] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000)
    return () => clearInterval(timer)
  }, [])

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Energy Dashboard</h1>
          <p className="text-muted-foreground">Real-time campus energy monitoring • {currentTime.toLocaleString()}</p>
        </div>
        <div className="flex gap-2">
          <Badge variant="outline" className="glass">
            <Activity className="w-3 h-3 mr-1" />
            Live Data
          </Badge>
          <Badge variant="secondary">All Systems Operational</Badge>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="glass">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Current Load</CardTitle>
            <Zap className="h-4 w-4 text-primary" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">87.3 kW</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">↓ 12%</span> from yesterday
            </p>
            <Progress value={73} className="mt-2" />
          </CardContent>
        </Card>

        <Card className="glass">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">24h Forecast Peak</CardTitle>
            <TrendingUp className="h-4 w-4 text-chart-2" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">124.7 kW</div>
            <p className="text-xs text-muted-foreground">
              Expected at <span className="font-medium">2:30 PM</span>
            </p>
            <div className="mt-2 text-xs text-amber-600">Peak alert threshold: 130 kW</div>
          </CardContent>
        </Card>

        <Card className="glass">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active Anomalies</CardTitle>
            <AlertTriangle className="h-4 w-4 text-destructive" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">3</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-red-600">2 High</span> • <span className="text-yellow-600">1 Medium</span>
            </p>
            <Button variant="outline" size="sm" className="mt-2 w-full bg-transparent">
              View Details
            </Button>
          </CardContent>
        </Card>

        <Card className="glass">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Monthly Savings</CardTitle>
            <DollarSign className="h-4 w-4 text-green-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">$2,847</div>
            <p className="text-xs text-muted-foreground">
              <span className="text-green-600">↑ 23%</span> vs last month
            </p>
            <div className="mt-2 text-xs text-green-600">Target: $3,200 (89% achieved)</div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Energy Consumption Chart */}
        <Card className="lg:col-span-2 glass">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Activity className="w-5 h-5 text-primary" />
              Campus Energy Consumption
            </CardTitle>
            <CardDescription>Real-time power consumption across all buildings</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={energyData}>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis dataKey="time" />
                <YAxis />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "var(--card)",
                    border: "1px solid var(--border)",
                    borderRadius: "8px",
                  }}
                />
                <Area type="monotone" dataKey="kw" stroke="var(--primary)" fill="var(--primary)" fillOpacity={0.2} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Building Performance */}
        <Card className="glass">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Target className="w-5 h-5 text-chart-2" />
              Building Performance
            </CardTitle>
            <CardDescription>Current vs forecast efficiency</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {buildingData.map((building) => (
              <div key={building.name} className="space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="font-medium">{building.name}</span>
                  <span className="text-muted-foreground">{building.current} kW</span>
                </div>
                <Progress value={(building.current / building.forecast) * 100} className="h-2" />
                <div className="flex justify-between text-xs text-muted-foreground">
                  <span>Efficiency: {building.efficiency}%</span>
                  <span>Target: {building.forecast} kW</span>
                </div>
              </div>
            ))}
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions and Recent Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <Card className="glass">
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Frequently used controls and optimizations</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Button className="w-full justify-start bg-transparent" variant="outline">
              <Thermometer className="w-4 h-4 mr-2" />
              Apply After-Hours Scene
            </Button>
            <Button className="w-full justify-start bg-transparent" variant="outline">
              <Users className="w-4 h-4 mr-2" />
              Check Room Occupancy
            </Button>
            <Button className="w-full justify-start bg-transparent" variant="outline">
              <AlertTriangle className="w-4 h-4 mr-2" />
              Review Anomalies
            </Button>
            <Button className="w-full justify-start bg-transparent" variant="outline">
              <TrendingUp className="w-4 h-4 mr-2" />
              Generate Efficiency Report
            </Button>
          </CardContent>
        </Card>

        <Card className="glass">
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Latest system events and optimizations</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 rounded-full bg-green-500 mt-2"></div>
              <div className="flex-1">
                <p className="text-sm font-medium">HVAC optimization applied</p>
                <p className="text-xs text-muted-foreground">Main Campus Floor 3 • 2 minutes ago</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 rounded-full bg-yellow-500 mt-2"></div>
              <div className="flex-1">
                <p className="text-sm font-medium">Anomaly detected</p>
                <p className="text-xs text-muted-foreground">Tech Center Room 205 • 15 minutes ago</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 rounded-full bg-blue-500 mt-2"></div>
              <div className="flex-1">
                <p className="text-sm font-medium">Auto-release triggered</p>
                <p className="text-xs text-muted-foreground">Conference Room A • 1 hour ago</p>
              </div>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-2 h-2 rounded-full bg-green-500 mt-2"></div>
              <div className="flex-1">
                <p className="text-sm font-medium">Energy savings achieved</p>
                <p className="text-xs text-muted-foreground">$127 saved today • 2 hours ago</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
