"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Switch } from "@/components/ui/switch"
import { Slider } from "@/components/ui/slider"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Lightbulb, Thermometer, Monitor, Wifi, Power, Settings, Zap, AlertTriangle, CheckCircle } from "lucide-react"

interface Device {
  id: number
  name: string
  type: "hvac" | "lighting" | "equipment" | "sensor"
  room_name: string
  status: "online" | "offline" | "error"
  is_on: boolean
  value: number
  unit: string
  last_updated: string
}

export function DeviceControls() {
  const [selectedRoom, setSelectedRoom] = useState("all")
  const [selectedType, setSelectedType] = useState("all")
  const [devices, setDevices] = useState<Device[]>([])
  const [isLoading, setIsLoading] = useState(false)

  // Mock data - replace with actual API calls
  useEffect(() => {
    const mockDevices: Device[] = [
      {
        id: 1,
        name: "Main HVAC Unit",
        type: "hvac",
        room_name: "Conference Room A",
        status: "online",
        is_on: true,
        value: 22.5,
        unit: "°C",
        last_updated: new Date().toISOString(),
      },
      {
        id: 2,
        name: "LED Panel 1",
        type: "lighting",
        room_name: "Conference Room A",
        status: "online",
        is_on: true,
        value: 80,
        unit: "%",
        last_updated: new Date().toISOString(),
      },
      {
        id: 3,
        name: "Smart Projector",
        type: "equipment",
        room_name: "Conference Room A",
        status: "offline",
        is_on: false,
        value: 0,
        unit: "W",
        last_updated: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
      },
      {
        id: 4,
        name: "Temperature Sensor",
        type: "sensor",
        room_name: "Conference Room A",
        status: "online",
        is_on: true,
        value: 22.8,
        unit: "°C",
        last_updated: new Date().toISOString(),
      },
      {
        id: 5,
        name: "HVAC Unit B",
        type: "hvac",
        room_name: "Meeting Room B",
        status: "error",
        is_on: false,
        value: 0,
        unit: "°C",
        last_updated: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
      },
    ]

    setDevices(mockDevices)
  }, [])

  const handleDeviceToggle = async (deviceId: number, newState: boolean) => {
    setIsLoading(true)
    try {
      console.log("Toggling device:", deviceId, "to:", newState)
      // API call to toggle device

      // Update local state
      setDevices((prev) =>
        prev.map((device) =>
          device.id === deviceId ? { ...device, is_on: newState, last_updated: new Date().toISOString() } : device,
        ),
      )
    } catch (error) {
      console.error("Error toggling device:", error)
    } finally {
      setIsLoading(false)
    }
  }

  const handleValueChange = async (deviceId: number, newValue: number) => {
    try {
      console.log("Changing device value:", deviceId, "to:", newValue)
      // API call to change device value

      // Update local state
      setDevices((prev) =>
        prev.map((device) =>
          device.id === deviceId ? { ...device, value: newValue, last_updated: new Date().toISOString() } : device,
        ),
      )
    } catch (error) {
      console.error("Error changing device value:", error)
    }
  }

  const getDeviceIcon = (type: string) => {
    switch (type) {
      case "hvac":
        return <Thermometer className="h-5 w-5" />
      case "lighting":
        return <Lightbulb className="h-5 w-5" />
      case "equipment":
        return <Monitor className="h-5 w-5" />
      case "sensor":
        return <Wifi className="h-5 w-5" />
      default:
        return <Settings className="h-5 w-5" />
    }
  }

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "online":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "offline":
        return <Power className="h-4 w-4 text-gray-500" />
      case "error":
        return <AlertTriangle className="h-4 w-4 text-red-500" />
      default:
        return <Settings className="h-4 w-4" />
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "online":
        return <Badge variant="default">Online</Badge>
      case "offline":
        return <Badge variant="secondary">Offline</Badge>
      case "error":
        return <Badge variant="destructive">Error</Badge>
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  const filteredDevices = devices.filter((device) => {
    const roomMatch = selectedRoom === "all" || device.room_name.includes(selectedRoom)
    const typeMatch = selectedType === "all" || device.type === selectedType
    return roomMatch && typeMatch
  })

  const devicesByType = {
    hvac: filteredDevices.filter((d) => d.type === "hvac"),
    lighting: filteredDevices.filter((d) => d.type === "lighting"),
    equipment: filteredDevices.filter((d) => d.type === "equipment"),
    sensor: filteredDevices.filter((d) => d.type === "sensor"),
  }

  const renderDeviceCard = (device: Device) => (
    <Card key={device.id} className="hover:shadow-md transition-shadow">
      <CardHeader className="pb-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            {getDeviceIcon(device.type)}
            <CardTitle className="text-lg">{device.name}</CardTitle>
          </div>
          <div className="flex items-center gap-2">
            {getStatusIcon(device.status)}
            {getStatusBadge(device.status)}
          </div>
        </div>
        <CardDescription>{device.room_name}</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* Power Toggle */}
        {device.type !== "sensor" && (
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">Power</span>
            <Switch
              checked={device.is_on}
              onCheckedChange={(checked) => handleDeviceToggle(device.id, checked)}
              disabled={device.status === "offline" || device.status === "error" || isLoading}
            />
          </div>
        )}

        {/* Value Display/Control */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-sm font-medium">
              {device.type === "hvac"
                ? "Temperature"
                : device.type === "lighting"
                  ? "Brightness"
                  : device.type === "equipment"
                    ? "Power"
                    : "Reading"}
            </span>
            <span className="text-sm font-mono">
              {device.value} {device.unit}
            </span>
          </div>

          {/* Slider for controllable devices */}
          {device.type !== "sensor" && device.is_on && device.status === "online" && (
            <div className="px-2">
              <Slider
                value={[device.value]}
                onValueChange={([value]) => handleValueChange(device.id, value)}
                max={device.type === "hvac" ? 30 : 100}
                min={device.type === "hvac" ? 16 : 0}
                step={device.type === "hvac" ? 0.5 : 5}
                className="w-full"
              />
            </div>
          )}
        </div>

        {/* Last Updated */}
        <div className="text-xs text-muted-foreground">
          Last updated: {new Date(device.last_updated).toLocaleTimeString()}
        </div>

        {/* Quick Actions */}
        {device.type !== "sensor" && (
          <div className="flex gap-2 pt-2">
            <Button size="sm" variant="outline" className="flex-1 bg-transparent">
              Schedule
            </Button>
            <Button size="sm" variant="outline" className="flex-1 bg-transparent">
              Settings
            </Button>
          </div>
        )}
      </CardContent>
    </Card>
  )

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Device Controls</h2>
          <p className="text-muted-foreground">Monitor and control building devices in real-time</p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={selectedRoom} onValueChange={setSelectedRoom}>
            <SelectTrigger className="w-48">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Rooms</SelectItem>
              <SelectItem value="Conference">Conference Room A</SelectItem>
              <SelectItem value="Meeting">Meeting Room B</SelectItem>
              <SelectItem value="Office">Open Office</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Devices</CardTitle>
            <Settings className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{devices.length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Online</CardTitle>
            <CheckCircle className="h-4 w-4 text-green-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{devices.filter((d) => d.status === "online").length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active</CardTitle>
            <Zap className="h-4 w-4 text-blue-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{devices.filter((d) => d.is_on).length}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Alerts</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{devices.filter((d) => d.status === "error").length}</div>
          </CardContent>
        </Card>
      </div>

      {/* Device Controls by Type */}
      <Tabs defaultValue="all" className="space-y-4">
        <TabsList>
          <TabsTrigger value="all">All Devices</TabsTrigger>
          <TabsTrigger value="hvac">HVAC ({devicesByType.hvac.length})</TabsTrigger>
          <TabsTrigger value="lighting">Lighting ({devicesByType.lighting.length})</TabsTrigger>
          <TabsTrigger value="equipment">Equipment ({devicesByType.equipment.length})</TabsTrigger>
          <TabsTrigger value="sensor">Sensors ({devicesByType.sensor.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="all" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {filteredDevices.map(renderDeviceCard)}
          </div>
        </TabsContent>

        <TabsContent value="hvac" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {devicesByType.hvac.map(renderDeviceCard)}
          </div>
        </TabsContent>

        <TabsContent value="lighting" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {devicesByType.lighting.map(renderDeviceCard)}
          </div>
        </TabsContent>

        <TabsContent value="equipment" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {devicesByType.equipment.map(renderDeviceCard)}
          </div>
        </TabsContent>

        <TabsContent value="sensor" className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {devicesByType.sensor.map(renderDeviceCard)}
          </div>
        </TabsContent>
      </Tabs>
    </div>
  )
}
