"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import {
  AlertTriangle,
  AlertCircle,
  Info,
  CheckCircle,
  Clock,
  Zap,
  Thermometer,
  Droplets,
  Settings,
  X,
} from "lucide-react"
import { format } from "date-fns"

interface Alert {
  id: number
  type: "energy_spike" | "temperature_anomaly" | "humidity_anomaly" | "device_malfunction" | "occupancy_mismatch"
  severity: "low" | "medium" | "high" | "critical"
  title: string
  description: string
  room_name: string
  device_name?: string
  timestamp: string
  status: "active" | "acknowledged" | "resolved"
  recommended_action: string
  value?: number
  expected_value?: number
}

export function AlertsPanel() {
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [filterSeverity, setFilterSeverity] = useState("all")
  const [filterStatus, setFilterStatus] = useState("active")

  // Mock data - replace with actual API calls
  useEffect(() => {
    const mockAlerts: Alert[] = [
      {
        id: 1,
        type: "energy_spike",
        severity: "high",
        title: "Energy Consumption Spike",
        description: "Unusual energy consumption detected in Conference Room A",
        room_name: "Conference Room A",
        device_name: "HVAC Unit 1",
        timestamp: new Date().toISOString(),
        status: "active",
        recommended_action: "Check HVAC filters and settings, inspect for blockages",
        value: 45.2,
        expected_value: 25.0,
      },
      {
        id: 2,
        type: "temperature_anomaly",
        severity: "medium",
        title: "Temperature Outside Normal Range",
        description: "Room temperature is significantly higher than expected",
        room_name: "Server Room",
        device_name: "Temperature Sensor 3",
        timestamp: new Date(Date.now() - 30 * 60 * 1000).toISOString(),
        status: "acknowledged",
        recommended_action: "Check cooling system and ventilation",
        value: 28.5,
        expected_value: 22.0,
      },
      {
        id: 3,
        type: "device_malfunction",
        severity: "critical",
        title: "Device Malfunction",
        description: "HVAC unit appears to be stuck - temperature readings constant",
        room_name: "Meeting Room B",
        device_name: "HVAC Unit 2",
        timestamp: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
        status: "active",
        recommended_action: "Inspect device and check connections",
        value: 22.0,
        expected_value: 22.0,
      },
      {
        id: 4,
        type: "humidity_anomaly",
        severity: "medium",
        title: "High Humidity Detected",
        description: "Humidity levels are above normal range",
        room_name: "Break Room",
        device_name: "Humidity Sensor 1",
        timestamp: new Date(Date.now() - 45 * 60 * 1000).toISOString(),
        status: "resolved",
        recommended_action: "Check ventilation system, inspect for moisture sources",
        value: 85.0,
        expected_value: 50.0,
      },
      {
        id: 5,
        type: "occupancy_mismatch",
        severity: "low",
        title: "Energy Usage Without Occupancy",
        description: "High energy consumption detected with no occupancy",
        room_name: "Training Room",
        timestamp: new Date(Date.now() - 4 * 60 * 60 * 1000).toISOString(),
        status: "active",
        recommended_action: "Check for devices left on or phantom loads",
      },
    ]

    setAlerts(mockAlerts)
  }, [])

  const handleAcknowledge = async (alertId: number) => {
    try {
      console.log("Acknowledging alert:", alertId)
      // API call to acknowledge alert

      setAlerts((prev) => prev.map((alert) => (alert.id === alertId ? { ...alert, status: "acknowledged" } : alert)))
    } catch (error) {
      console.error("Error acknowledging alert:", error)
    }
  }

  const handleResolve = async (alertId: number) => {
    try {
      console.log("Resolving alert:", alertId)
      // API call to resolve alert

      setAlerts((prev) => prev.map((alert) => (alert.id === alertId ? { ...alert, status: "resolved" } : alert)))
    } catch (error) {
      console.error("Error resolving alert:", error)
    }
  }

  const handleDismiss = async (alertId: number) => {
    try {
      console.log("Dismissing alert:", alertId)
      // API call to dismiss alert

      setAlerts((prev) => prev.filter((alert) => alert.id !== alertId))
    } catch (error) {
      console.error("Error dismissing alert:", error)
    }
  }

  const getSeverityIcon = (severity: string) => {
    switch (severity) {
      case "critical":
        return <AlertTriangle className="h-5 w-5 text-red-500" />
      case "high":
        return <AlertCircle className="h-5 w-5 text-orange-500" />
      case "medium":
        return <AlertCircle className="h-5 w-5 text-yellow-500" />
      case "low":
        return <Info className="h-5 w-5 text-blue-500" />
      default:
        return <Info className="h-5 w-5" />
    }
  }

  const getSeverityBadge = (severity: string) => {
    switch (severity) {
      case "critical":
        return <Badge variant="destructive">Critical</Badge>
      case "high":
        return <Badge className="bg-orange-500 hover:bg-orange-600">High</Badge>
      case "medium":
        return <Badge className="bg-yellow-500 hover:bg-yellow-600">Medium</Badge>
      case "low":
        return <Badge variant="secondary">Low</Badge>
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge variant="destructive">Active</Badge>
      case "acknowledged":
        return <Badge variant="secondary">Acknowledged</Badge>
      case "resolved":
        return <Badge variant="default">Resolved</Badge>
      default:
        return <Badge variant="outline">Unknown</Badge>
    }
  }

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "energy_spike":
        return <Zap className="h-4 w-4" />
      case "temperature_anomaly":
        return <Thermometer className="h-4 w-4" />
      case "humidity_anomaly":
        return <Droplets className="h-4 w-4" />
      case "device_malfunction":
        return <Settings className="h-4 w-4" />
      case "occupancy_mismatch":
        return <Clock className="h-4 w-4" />
      default:
        return <AlertCircle className="h-4 w-4" />
    }
  }

  const filteredAlerts = alerts.filter((alert) => {
    const severityMatch = filterSeverity === "all" || alert.severity === filterSeverity
    const statusMatch = filterStatus === "all" || alert.status === filterStatus
    return severityMatch && statusMatch
  })

  const alertCounts = {
    total: alerts.length,
    active: alerts.filter((a) => a.status === "active").length,
    critical: alerts.filter((a) => a.severity === "critical").length,
    high: alerts.filter((a) => a.severity === "high").length,
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold">Alerts & Notifications</h2>
          <p className="text-muted-foreground">Monitor system alerts and anomalies in real-time</p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={filterSeverity} onValueChange={setFilterSeverity}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Severity</SelectItem>
              <SelectItem value="critical">Critical</SelectItem>
              <SelectItem value="high">High</SelectItem>
              <SelectItem value="medium">Medium</SelectItem>
              <SelectItem value="low">Low</SelectItem>
            </SelectContent>
          </Select>
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-32">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Status</SelectItem>
              <SelectItem value="active">Active</SelectItem>
              <SelectItem value="acknowledged">Acknowledged</SelectItem>
              <SelectItem value="resolved">Resolved</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      {/* Alert Summary */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Total Alerts</CardTitle>
            <AlertCircle className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{alertCounts.total}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Active</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{alertCounts.active}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">Critical</CardTitle>
            <AlertTriangle className="h-4 w-4 text-red-600" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{alertCounts.critical}</div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">High Priority</CardTitle>
            <AlertCircle className="h-4 w-4 text-orange-500" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{alertCounts.high}</div>
          </CardContent>
        </Card>
      </div>

      {/* Alerts List */}
      <div className="space-y-4">
        {filteredAlerts.length === 0 ? (
          <Card>
            <CardContent className="flex items-center justify-center py-8">
              <div className="text-center">
                <CheckCircle className="h-12 w-12 text-green-500 mx-auto mb-3" />
                <p className="text-muted-foreground">No alerts found</p>
              </div>
            </CardContent>
          </Card>
        ) : (
          filteredAlerts.map((alert) => (
            <Card key={alert.id} className="hover:shadow-md transition-shadow">
              <CardContent className="p-4">
                <div className="flex items-start justify-between">
                  <div className="flex items-start gap-3 flex-1">
                    {getSeverityIcon(alert.severity)}
                    <div className="flex-1 space-y-2">
                      {/* Header */}
                      <div className="flex items-center gap-2 flex-wrap">
                        <h3 className="font-semibold">{alert.title}</h3>
                        {getSeverityBadge(alert.severity)}
                        {getStatusBadge(alert.status)}
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          {getTypeIcon(alert.type)}
                          <span>{alert.room_name}</span>
                        </div>
                      </div>

                      {/* Description */}
                      <p className="text-sm text-muted-foreground">{alert.description}</p>

                      {/* Device and Values */}
                      {alert.device_name && (
                        <p className="text-sm">
                          <span className="font-medium">Device:</span> {alert.device_name}
                        </p>
                      )}

                      {alert.value !== undefined && alert.expected_value !== undefined && (
                        <div className="text-sm">
                          <span className="font-medium">Current:</span> {alert.value}
                          {alert.type.includes("temperature") && "°C"}
                          {alert.type.includes("humidity") && "%"}
                          {alert.type.includes("energy") && " kWh"} | <span className="font-medium">Expected:</span>{" "}
                          {alert.expected_value}
                          {alert.type.includes("temperature") && "°C"}
                          {alert.type.includes("humidity") && "%"}
                          {alert.type.includes("energy") && " kWh"}
                        </div>
                      )}

                      {/* Recommended Action */}
                      <div className="bg-muted/50 p-3 rounded-lg">
                        <p className="text-sm">
                          <span className="font-medium">Recommended Action:</span> {alert.recommended_action}
                        </p>
                      </div>

                      {/* Timestamp */}
                      <p className="text-xs text-muted-foreground">
                        {format(new Date(alert.timestamp), "MMM d, yyyy HH:mm")}
                      </p>
                    </div>
                  </div>

                  {/* Actions */}
                  <div className="flex items-center gap-2 ml-4">
                    {alert.status === "active" && (
                      <>
                        <Button size="sm" variant="outline" onClick={() => handleAcknowledge(alert.id)}>
                          Acknowledge
                        </Button>
                        <Button size="sm" onClick={() => handleResolve(alert.id)}>
                          Resolve
                        </Button>
                      </>
                    )}
                    {alert.status === "acknowledged" && (
                      <Button size="sm" onClick={() => handleResolve(alert.id)}>
                        Resolve
                      </Button>
                    )}
                    <Button size="sm" variant="ghost" onClick={() => handleDismiss(alert.id)}>
                      <X className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          ))
        )}
      </div>
    </div>
  )
}
