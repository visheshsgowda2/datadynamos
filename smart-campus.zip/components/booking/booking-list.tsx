"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Calendar, Clock, Users, MapPin, QrCode, MoreHorizontal, CheckCircle, XCircle, AlertCircle } from "lucide-react"
import { format } from "date-fns"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"

interface Booking {
  id: number
  room_id: number
  room_name: string
  start_time: string
  end_time: string
  purpose: string
  attendees: number
  status: "confirmed" | "checked_in" | "completed" | "cancelled" | "auto_released"
  check_in_code: string
  checked_in_at?: string
  user_name: string
}

interface BookingListProps {
  bookings: Booking[]
  onCheckIn: (bookingId: number, checkInCode: string) => void
  onCancel: (bookingId: number) => void
  onExtend: (bookingId: number, minutes: number) => void
  currentUserId?: number
  showUserColumn?: boolean
}

const statusConfig = {
  confirmed: {
    label: "Confirmed",
    variant: "secondary" as const,
    icon: Calendar,
  },
  checked_in: {
    label: "Checked In",
    variant: "default" as const,
    icon: CheckCircle,
  },
  completed: {
    label: "Completed",
    variant: "outline" as const,
    icon: CheckCircle,
  },
  cancelled: {
    label: "Cancelled",
    variant: "destructive" as const,
    icon: XCircle,
  },
  auto_released: {
    label: "Auto-Released",
    variant: "destructive" as const,
    icon: AlertCircle,
  },
}

export function BookingList({
  bookings,
  onCheckIn,
  onCancel,
  onExtend,
  currentUserId,
  showUserColumn = false,
}: BookingListProps) {
  const [filter, setFilter] = useState<string>("all")
  const [searchTerm, setSearchTerm] = useState("")
  const [checkInCode, setCheckInCode] = useState<{ [key: number]: string }>({})

  const filteredBookings = bookings.filter((booking) => {
    const matchesFilter = filter === "all" || booking.status === filter
    const matchesSearch =
      booking.purpose.toLowerCase().includes(searchTerm.toLowerCase()) ||
      booking.room_name.toLowerCase().includes(searchTerm.toLowerCase())
    return matchesFilter && matchesSearch
  })

  const handleCheckIn = (bookingId: number) => {
    const code = checkInCode[bookingId]
    if (code && code.length === 8) {
      onCheckIn(bookingId, code)
      setCheckInCode((prev) => ({ ...prev, [bookingId]: "" }))
    }
  }

  const canCheckIn = (booking: Booking) => {
    if (booking.status !== "confirmed") return false

    const now = new Date()
    const startTime = new Date(booking.start_time)
    const checkInWindow = new Date(startTime.getTime() - 15 * 60 * 1000) // 15 min before
    const checkInDeadline = new Date(startTime.getTime() + 10 * 60 * 1000) // 10 min after

    return now >= checkInWindow && now <= checkInDeadline
  }

  const canCancel = (booking: Booking) => {
    return booking.status === "confirmed" || booking.status === "checked_in"
  }

  const canExtend = (booking: Booking) => {
    return booking.status === "checked_in"
  }

  return (
    <div className="space-y-4">
      {/* Filters */}
      <div className="flex gap-4 items-center">
        <Input
          placeholder="Search bookings..."
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          className="max-w-sm"
        />
        <Select value={filter} onValueChange={setFilter}>
          <SelectTrigger className="w-48">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Bookings</SelectItem>
            <SelectItem value="confirmed">Confirmed</SelectItem>
            <SelectItem value="checked_in">Checked In</SelectItem>
            <SelectItem value="completed">Completed</SelectItem>
            <SelectItem value="cancelled">Cancelled</SelectItem>
            <SelectItem value="auto_released">Auto-Released</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Bookings List */}
      <div className="space-y-3">
        {filteredBookings.length === 0 ? (
          <Card>
            <CardContent className="flex items-center justify-center py-8">
              <p className="text-muted-foreground">No bookings found</p>
            </CardContent>
          </Card>
        ) : (
          filteredBookings.map((booking) => {
            const status = statusConfig[booking.status]
            const StatusIcon = status.icon

            return (
              <Card key={booking.id} className="hover:shadow-md transition-shadow">
                <CardContent className="p-4">
                  <div className="flex items-start justify-between">
                    <div className="flex-1 space-y-2">
                      {/* Header */}
                      <div className="flex items-center gap-3">
                        <Badge variant={status.variant} className="flex items-center gap-1">
                          <StatusIcon className="h-3 w-3" />
                          {status.label}
                        </Badge>
                        <div className="flex items-center gap-1 text-sm text-muted-foreground">
                          <MapPin className="h-4 w-4" />
                          {booking.room_name}
                        </div>
                        {showUserColumn && <div className="text-sm text-muted-foreground">by {booking.user_name}</div>}
                      </div>

                      {/* Purpose */}
                      <h3 className="font-medium">{booking.purpose}</h3>

                      {/* Details */}
                      <div className="flex items-center gap-4 text-sm text-muted-foreground">
                        <div className="flex items-center gap-1">
                          <Calendar className="h-4 w-4" />
                          {format(new Date(booking.start_time), "MMM d, yyyy")}
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="h-4 w-4" />
                          {format(new Date(booking.start_time), "HH:mm")} -{" "}
                          {format(new Date(booking.end_time), "HH:mm")}
                        </div>
                        <div className="flex items-center gap-1">
                          <Users className="h-4 w-4" />
                          {booking.attendees} attendees
                        </div>
                      </div>

                      {/* Check-in section */}
                      {canCheckIn(booking) && (
                        <div className="flex items-center gap-2 p-3 bg-muted/50 rounded-lg">
                          <QrCode className="h-4 w-4" />
                          <Input
                            placeholder="Enter 8-digit check-in code"
                            value={checkInCode[booking.id] || ""}
                            onChange={(e) =>
                              setCheckInCode((prev) => ({
                                ...prev,
                                [booking.id]: e.target.value.toUpperCase(),
                              }))
                            }
                            maxLength={8}
                            className="max-w-48"
                          />
                          <Button
                            size="sm"
                            onClick={() => handleCheckIn(booking.id)}
                            disabled={!checkInCode[booking.id] || checkInCode[booking.id].length !== 8}
                          >
                            Check In
                          </Button>
                        </div>
                      )}

                      {booking.checked_in_at && (
                        <p className="text-sm text-green-600">
                          Checked in at {format(new Date(booking.checked_in_at), "HH:mm")}
                        </p>
                      )}
                    </div>

                    {/* Actions */}
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="sm">
                          <MoreHorizontal className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end">
                        {canExtend(booking) && (
                          <>
                            <DropdownMenuItem onClick={() => onExtend(booking.id, 15)}>Extend 15 min</DropdownMenuItem>
                            <DropdownMenuItem onClick={() => onExtend(booking.id, 30)}>Extend 30 min</DropdownMenuItem>
                          </>
                        )}
                        {canCancel(booking) && (
                          <DropdownMenuItem onClick={() => onCancel(booking.id)} className="text-destructive">
                            Cancel Booking
                          </DropdownMenuItem>
                        )}
                        <DropdownMenuItem>View Details</DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </CardContent>
              </Card>
            )
          })
        )}
      </div>
    </div>
  )
}
