"""
Security utilities for authentication and authorization
"""

from datetime import datetime, timedelta
from typing import Optional, Dict, Any, List
from passlib.context import CryptContext
from jose import JWTError, jwt
from fastapi import HTTPException, status
from pydantic import BaseModel

from core.config import settings
from models.user import UserRole

# Password hashing
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

class TokenData(BaseModel):
    user_id: str
    email: str
    role: UserRole
    scopes: List[str] = []

class Token(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a password against its hash"""
    return pwd_context.verify(plain_password, hashed_password)

def get_password_hash(password: str) -> str:
    """Hash a password"""
    return pwd_context.hash(password)

def create_access_token(data: Dict[str, Any], expires_delta: Optional[timedelta] = None) -> str:
    """Create a JWT access token"""
    to_encode = data.copy()
    
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(seconds=settings.JWT_EXPIRES_IN)
    
    to_encode.update({"exp": expire, "type": "access"})
    
    encoded_jwt = jwt.encode(
        to_encode, 
        settings.JWT_SECRET, 
        algorithm=settings.JWT_ALGORITHM
    )
    
    return encoded_jwt

def create_refresh_token(data: Dict[str, Any]) -> str:
    """Create a JWT refresh token"""
    to_encode = data.copy()
    expire = datetime.utcnow() + timedelta(seconds=settings.REFRESH_TOKEN_EXPIRES_IN)
    
    to_encode.update({"exp": expire, "type": "refresh"})
    
    encoded_jwt = jwt.encode(
        to_encode,
        settings.JWT_SECRET,
        algorithm=settings.JWT_ALGORITHM
    )
    
    return encoded_jwt

def verify_token(token: str, token_type: str = "access") -> TokenData:
    """Verify and decode a JWT token"""
    try:
        payload = jwt.decode(
            token,
            settings.JWT_SECRET,
            algorithms=[settings.JWT_ALGORITHM]
        )
        
        # Verify token type
        if payload.get("type") != token_type:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token type"
            )
        
        user_id: str = payload.get("sub")
        email: str = payload.get("email")
        role: str = payload.get("role")
        scopes: List[str] = payload.get("scopes", [])
        
        if user_id is None or email is None or role is None:
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="Invalid token payload"
            )
        
        return TokenData(
            user_id=user_id,
            email=email,
            role=UserRole(role),
            scopes=scopes
        )
        
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Could not validate credentials"
        )

def generate_scopes(role: UserRole, assignments: List[Dict[str, Any]]) -> List[str]:
    """Generate permission scopes based on user role and assignments"""
    scopes = []
    
    # Base scopes by role
    role_scopes = {
        UserRole.CEO: ["campus:read", "campus:write", "reports:read", "billing:read"],
        UserRole.FACILITY_MANAGER: ["campus:read", "campus:write", "devices:control", "reports:read"],
        UserRole.BUILDING_ADMIN: ["building:read", "building:write", "devices:control"],
        UserRole.RECEPTIONIST: ["bookings:read", "bookings:write", "rooms:read"],
        UserRole.EMPLOYEE: ["own-room:read", "own-room:write", "bookings:read", "bookings:write"],
        UserRole.AUDITOR: ["campus:read", "reports:read", "audit:read"],
        UserRole.SECURITY: ["campus:read", "alerts:read", "occupancy:read"]
    }
    
    scopes.extend(role_scopes.get(role, []))
    
    # Add assignment-specific scopes
    for assignment in assignments:
        if assignment.get("building_id"):
            scopes.append(f"building:{assignment['building_id']}:read")
            if role in [UserRole.FACILITY_MANAGER, UserRole.BUILDING_ADMIN]:
                scopes.append(f"building:{assignment['building_id']}:write")
        
        if assignment.get("floor_id"):
            scopes.append(f"floor:{assignment['floor_id']}:read")
            if role in [UserRole.FACILITY_MANAGER, UserRole.BUILDING_ADMIN]:
                scopes.append(f"floor:{assignment['floor_id']}:write")
        
        if assignment.get("room_id"):
            scopes.append(f"room:{assignment['room_id']}:read")
            if role != UserRole.AUDITOR:
                scopes.append(f"room:{assignment['room_id']}:write")
    
    return list(set(scopes))  # Remove duplicates
