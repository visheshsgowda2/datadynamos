"""
Role-Based Access Control (RBAC) middleware and utilities
"""

from typing import List, Optional, Dict, Any
from fastapi import HTTPException, status, Depends, Request
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
import structlog

from core.database import get_db
from core.security import verify_token, TokenData
from models.user import User, UserRole
from models.assignment import Assignment

logger = structlog.get_logger()

security = HTTPBearer()

class RBACChecker:
    """RBAC permission checker"""
    
    def __init__(self, required_scopes: List[str]):
        self.required_scopes = required_scopes
    
    async def __call__(
        self,
        request: Request,
        credentials: HTTPAuthorizationCredentials = Depends(security),
        db: AsyncSession = Depends(get_db)
    ) -> TokenData:
        """Check if user has required permissions"""
        
        # Verify token
        token_data = verify_token(credentials.credentials)
        
        # Get user from database
        result = await db.execute(
            select(User).where(User.id == token_data.user_id)
        )
        user = result.scalar_one_or_none()
        
        if not user or user.status != "active":
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="User not found or inactive"
            )
        
        # Check required scopes
        if self.required_scopes:
            if not any(scope in token_data.scopes for scope in self.required_scopes):
                logger.warning(
                    "Access denied - insufficient permissions",
                    user_id=str(user.id),
                    required_scopes=self.required_scopes,
                    user_scopes=token_data.scopes
                )
                raise HTTPException(
                    status_code=status.HTTP_403_FORBIDDEN,
                    detail="Insufficient permissions"
                )
        
        # Log access
        logger.info(
            "Access granted",
            user_id=str(user.id),
            email=user.email,
            role=user.role,
            endpoint=str(request.url),
            method=request.method
        )
        
        return token_data

def require_scopes(scopes: List[str]):
    """Decorator to require specific scopes"""
    return RBACChecker(scopes)

def require_role(roles: List[UserRole]):
    """Decorator to require specific roles"""
    async def role_checker(
        credentials: HTTPAuthorizationCredentials = Depends(security),
        db: AsyncSession = Depends(get_db)
    ) -> TokenData:
        token_data = verify_token(credentials.credentials)
        
        if token_data.role not in roles:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Insufficient role permissions"
            )
        
        return token_data
    
    return role_checker

async def get_current_user(
    credentials: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db)
) -> User:
    """Get current authenticated user"""
    token_data = verify_token(credentials.credentials)
    
    result = await db.execute(
        select(User).where(User.id == token_data.user_id)
    )
    user = result.scalar_one_or_none()
    
    if not user or user.status != "active":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found or inactive"
        )
    
    return user

def check_resource_access(
    user_scopes: List[str],
    resource_type: str,
    resource_id: str,
    action: str = "read"
) -> bool:
    """Check if user has access to specific resource"""
    
    # Check campus-wide access
    if f"campus:{action}" in user_scopes:
        return True
    
    # Check specific resource access
    resource_scope = f"{resource_type}:{resource_id}:{action}"
    if resource_scope in user_scopes:
        return True
    
    # Check parent resource access (e.g., building access for room)
    if resource_type == "room":
        # Extract building and floor from room ID (assuming format: BLD-FL-RM)
        parts = resource_id.split("-")
        if len(parts) >= 3:
            building_id = parts[0]
            floor_id = f"{parts[0]}-{parts[1]}"
            
            if f"building:{building_id}:{action}" in user_scopes:
                return True
            if f"floor:{floor_id}:{action}" in user_scopes:
                return True
    
    elif resource_type == "floor":
        # Extract building from floor ID
        parts = resource_id.split("-")
        if len(parts) >= 2:
            building_id = parts[0]
            if f"building:{building_id}:{action}" in user_scopes:
                return True
    
    return False
