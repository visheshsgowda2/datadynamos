"""
Application configuration using Pydantic Settings
"""

from typing import List, Optional
from pydantic import Field
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    # Application
    APP_NAME: str = "Smart Campus API"
    VERSION: str = "1.0.0"
    DEBUG: bool = False
    PORT: int = 8000
    
    # Database
    DATABASE_URL: str = Field(..., description="PostgreSQL database URL")
    
    # Redis
    REDIS_URL: str = Field(..., description="Redis connection URL")
    
    # MQTT
    MQTT_BROKER_URL: str = Field(..., description="MQTT broker URL")
    
    # Authentication
    JWT_SECRET: str = Field(..., description="JWT signing secret")
    JWT_ALGORITHM: str = "HS256"
    JWT_EXPIRES_IN: int = 24 * 60 * 60  # 24 hours
    REFRESH_TOKEN_EXPIRES_IN: int = 7 * 24 * 60 * 60  # 7 days
    
    # CORS
    ALLOWED_ORIGINS: List[str] = ["http://localhost:3000", "http://localhost:3001"]
    ALLOWED_HOSTS: List[str] = ["localhost", "127.0.0.1", "*"]
    
    # GenAI (Optional)
    GENAI_PROVIDER: Optional[str] = None
    GENAI_API_KEY: Optional[str] = None
    
    # ML Service
    ML_SERVICE_URL: str = "http://localhost:8001"
    
    # Logging
    LOG_LEVEL: str = "INFO"
    
    class Config:
        env_file = ".env"
        case_sensitive = True

settings = Settings()
