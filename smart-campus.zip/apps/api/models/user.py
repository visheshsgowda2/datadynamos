"""
User model and related schemas
"""

from datetime import datetime
from typing import Optional, List
from enum import Enum
from sqlalchemy import Column, String, DateTime, Boolean, Text
from sqlalchemy.dialects.postgresql import UUID, ENUM
from sqlalchemy.orm import relationship
import uuid

from core.database import Base

class UserRole(str, Enum):
    CEO = "ceo"
    FACILITY_MANAGER = "facility_manager"
    BUILDING_ADMIN = "building_admin"
    RECEPTIONIST = "receptionist"
    EMPLOYEE = "employee"
    AUDITOR = "auditor"
    SECURITY = "security"

class UserStatus(str, Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    SUSPENDED = "suspended"

class User(Base):
    __tablename__ = "users"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    name = Column(String(255), nullable=False)
    email = Column(String(255), unique=True, nullable=False, index=True)
    role = Column(ENUM(UserRole), nullable=False)
    dept = Column(String(100))
    password_hash = Column(String(255), nullable=False)
    status = Column(ENUM(UserStatus), default=UserStatus.ACTIVE)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    assignments = relationship("Assignment", back_populates="user", cascade="all, delete-orphan")
    bookings = relationship("Booking", back_populates="user")
    audit_logs = relationship("AuditLog", back_populates="user")
