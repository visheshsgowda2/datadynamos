"""
Anomaly detection models
"""

from datetime import datetime
from enum import Enum
from sqlalchemy import Column, String, DateTime, DOUBLE_PRECISION, Text, ForeignKey
from sqlalchemy.dialects.postgresql import UUID, ENUM
from sqlalchemy.orm import relationship
import uuid

from core.database import Base

class AnomalySeverity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"

class AnomalyStatus(str, Enum):
    OPEN = "open"
    ACKNOWLEDGED = "acknowledged"
    RESOLVED = "resolved"

class Anomaly(Base):
    __tablename__ = "anomalies"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    room_id = Column(String(50), ForeignKey("rooms.id", ondelete="CASCADE"))
    device_id = Column(String(50), ForeignKey("devices.id", ondelete="CASCADE"))
    metric = Column(String(100), nullable=False)
    baseline = Column(DOUBLE_PRECISION, nullable=False)
    observed = Column(DOUBLE_PRECISION, nullable=False)
    delta_pct = Column(DOUBLE_PRECISION, nullable=False)
    severity = Column(ENUM(AnomalySeverity))
    status = Column(ENUM(AnomalyStatus), default=AnomalyStatus.OPEN)
    explanation = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    acknowledged_at = Column(DateTime)
    acknowledged_by = Column(UUID(as_uuid=True), ForeignKey("users.id"))
    
    # Relationships
    room = relationship("Room", back_populates="anomalies")
    device = relationship("Device", back_populates="anomalies")
    acknowledger = relationship("User")
