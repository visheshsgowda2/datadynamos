"""
Billing and financial models
"""

from datetime import datetime, date
from sqlalchemy import Column, String, DateTime, Date, DECIMAL, DOUBLE_PRECISION, ForeignKey
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import relationship
import uuid

from core.database import Base

class Bill(Base):
    __tablename__ = "bills"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    building_id = Column(String(50), ForeignKey("buildings.id", ondelete="CASCADE"), nullable=False)
    period_start = Column(Date, nullable=False)
    period_end = Column(Date, nullable=False)
    energy_kwh = Column(DOUBLE_PRECISION, nullable=False)
    demand_kw = Column(DOUBLE_PRECISION, nullable=False)
    tariff = Column(JSONB, nullable=False)
    cost_currency = Column(String(3), default="USD")
    cost_total = Column(DECIMAL(12, 2), nullable=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    building = relationship("Building", back_populates="bills")

class Optimization(Base):
    __tablename__ = "optimizations"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    scope = Column(JSONB, nullable=False)
    action = Column(JSONB, nullable=False)
    expected_saving_kwh = Column(DOUBLE_PRECISION)
    expected_saving_currency = Column(DECIMAL(12, 2))
    created_at = Column(DateTime, default=datetime.utcnow)
