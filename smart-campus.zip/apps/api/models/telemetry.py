"""
Telemetry and energy time-series models
"""

from datetime import datetime
from sqlalchemy import Column, String, DateTime, DOUBLE_PRECISION, ForeignKey
from sqlalchemy.dialects.postgresql import JSONB

from core.database import Base

class TelemetryTS(Base):
    __tablename__ = "telemetry_ts"
    
    time = Column(DateTime, nullable=False, primary_key=True)
    device_id = Column(String(50), ForeignKey("devices.id", ondelete="CASCADE"), nullable=False, primary_key=True)
    metric = Column(String(100), nullable=False, primary_key=True)
    value = Column(DOUBLE_PRECISION, nullable=False)
    tags = Column(JSONB, default=dict)

class EnergyTS(Base):
    __tablename__ = "energy_ts"
    
    time = Column(DateTime, nullable=False, primary_key=True)
    room_id = Column(String(50), ForeignKey("rooms.id", ondelete="CASCADE"), nullable=False, primary_key=True)
    kw = Column(DOUBLE_PRECISION, nullable=False)
    kwh_rollup = Column(DOUBLE_PRECISION, default=0)
