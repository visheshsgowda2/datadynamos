"""
User assignment model for RBAC
"""

from datetime import datetime
from sqlalchemy import Column, String, DateTime, ForeignKey
from sqlalchemy.dialects.postgresql import UUID
from sqlalchemy.orm import relationship
import uuid

from core.database import Base

class Assignment(Base):
    __tablename__ = "assignments"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False)
    building_id = Column(String(50), ForeignKey("buildings.id", ondelete="CASCADE"))
    floor_id = Column(String(50), ForeignKey("floors.id", ondelete="CASCADE"))
    room_id = Column(String(50), ForeignKey("rooms.id", ondelete="CASCADE"))
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    user = relationship("User", back_populates="assignments")
    building = relationship("Building")
    floor = relationship("Floor")
    room = relationship("Room")
