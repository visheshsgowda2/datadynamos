"""
Building hierarchy models
"""

from datetime import datetime
from typing import List, Optional
from sqlalchemy import Column, String, DateTime, Integer, Text, DECIMAL, ForeignKey
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.orm import relationship

from core.database import Base

class Building(Base):
    __tablename__ = "buildings"
    
    id = Column(String(50), primary_key=True)
    name = Column(String(255), nullable=False)
    address = Column(Text)
    geofence = Column(JSONB)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    floors = relationship("Floor", back_populates="building", cascade="all, delete-orphan")
    bills = relationship("Bill", back_populates="building")

class Floor(Base):
    __tablename__ = "floors"
    
    id = Column(String(50), primary_key=True)
    building_id = Column(String(50), ForeignKey("buildings.id", ondelete="CASCADE"), nullable=False)
    name = Column(String(255), nullable=False)
    number = Column(Integer, nullable=False)
    floor_plan_url = Column(Text)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    building = relationship("Building", back_populates="floors")
    rooms = relationship("Room", back_populates="floor", cascade="all, delete-orphan")

class Room(Base):
    __tablename__ = "rooms"
    
    id = Column(String(50), primary_key=True)
    floor_id = Column(String(50), ForeignKey("floors.id", ondelete="CASCADE"), nullable=False)
    name = Column(String(255), nullable=False)
    capacity = Column(Integer, default=0)
    amenities = Column(JSONB, default=list)
    area_sqm = Column(DECIMAL(10, 2))
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    floor = relationship("Floor", back_populates="rooms")
    devices = relationship("Device", back_populates="room", cascade="all, delete-orphan")
    bookings = relationship("Booking", back_populates="room")
    anomalies = relationship("Anomaly", back_populates="room")
