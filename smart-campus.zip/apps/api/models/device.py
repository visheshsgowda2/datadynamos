"""
Device models
"""

from datetime import datetime
from enum import Enum
from sqlalchemy import Column, String, DateTime, ForeignKey
from sqlalchemy.dialects.postgresql import JSONB, ENUM
from sqlalchemy.orm import relationship

from core.database import Base

class DeviceType(str, Enum):
    LIGHT = "light"
    HVAC = "hvac"
    PLUG = "plug"
    PROJECTOR = "projector"
    SENSOR = "sensor"

class Device(Base):
    __tablename__ = "devices"
    
    id = Column(String(50), primary_key=True)
    room_id = Column(String(50), ForeignKey("rooms.id", ondelete="CASCADE"), nullable=False)
    type = Column(ENUM(DeviceType), nullable=False)
    model = Column(String(100))
    state = Column(JSONB, default=dict)
    last_seen = Column(DateTime)
    created_at = Column(DateTime, default=datetime.utcnow)
    
    # Relationships
    room = relationship("Room", back_populates="devices")
    anomalies = relationship("Anomaly", back_populates="device")
