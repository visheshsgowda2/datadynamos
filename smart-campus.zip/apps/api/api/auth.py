"""
Authentication API endpoints
"""

from datetime import timedelta
from typing import Dict, Any
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
import structlog

from core.database import get_db
from core.security import (
    verify_password, 
    get_password_hash,
    create_access_token, 
    create_refresh_token,
    verify_token,
    generate_scopes
)
from core.rbac import get_current_user
from models.user import User
from models.assignment import Assignment
from schemas.auth import (
    LoginRequest, 
    LoginResponse, 
    RefreshTokenRequest,
    UserResponse,
    ChangePasswordRequest
)

router = APIRouter()
logger = structlog.get_logger()

@router.post("/login", response_model=LoginResponse)
async def login(
    login_data: LoginRequest,
    db: AsyncSession = Depends(get_db)
):
    """Authenticate user and return JWT tokens"""
    
    # Find user by email
    result = await db.execute(
        select(User).where(User.email == login_data.email)
    )
    user = result.scalar_one_or_none()
    
    if not user or not verify_password(login_data.password, user.password_hash):
        logger.warning("Failed login attempt", email=login_data.email)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Invalid email or password"
        )
    
    if user.status != "active":
        logger.warning("Login attempt by inactive user", email=login_data.email)
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Account is inactive"
        )
    
    # Get user assignments for scope generation
    assignments_result = await db.execute(
        select(Assignment).where(Assignment.user_id == user.id)
    )
    assignments = [
        {
            "building_id": a.building_id,
            "floor_id": a.floor_id,
            "room_id": a.room_id
        }
        for a in assignments_result.scalars().all()
    ]
    
    # Generate scopes
    scopes = generate_scopes(user.role, assignments)
    
    # Create token payload
    token_payload = {
        "sub": str(user.id),
        "email": user.email,
        "role": user.role.value,
        "scopes": scopes
    }
    
    # Create tokens
    access_token = create_access_token(token_payload)
    refresh_token = create_refresh_token({"sub": str(user.id)})
    
    logger.info("User logged in successfully", user_id=str(user.id), email=user.email)
    
    return LoginResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        expires_in=24 * 60 * 60,  # 24 hours
        user=UserResponse.model_validate(user)
    )

@router.post("/refresh", response_model=Dict[str, Any])
async def refresh_token(
    refresh_data: RefreshTokenRequest,
    db: AsyncSession = Depends(get_db)
):
    """Refresh access token using refresh token"""
    
    # Verify refresh token
    token_data = verify_token(refresh_data.refresh_token, token_type="refresh")
    
    # Get user
    result = await db.execute(
        select(User).where(User.id == token_data.user_id)
    )
    user = result.scalar_one_or_none()
    
    if not user or user.status != "active":
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="User not found or inactive"
        )
    
    # Get assignments for scope generation
    assignments_result = await db.execute(
        select(Assignment).where(Assignment.user_id == user.id)
    )
    assignments = [
        {
            "building_id": a.building_id,
            "floor_id": a.floor_id,
            "room_id": a.room_id
        }
        for a in assignments_result.scalars().all()
    ]
    
    # Generate new scopes
    scopes = generate_scopes(user.role, assignments)
    
    # Create new access token
    token_payload = {
        "sub": str(user.id),
        "email": user.email,
        "role": user.role.value,
        "scopes": scopes
    }
    
    access_token = create_access_token(token_payload)
    
    return {
        "access_token": access_token,
        "token_type": "bearer",
        "expires_in": 24 * 60 * 60
    }

@router.get("/me", response_model=UserResponse)
async def get_current_user_info(
    current_user: User = Depends(get_current_user)
):
    """Get current user information"""
    return UserResponse.model_validate(current_user)

@router.post("/change-password")
async def change_password(
    password_data: ChangePasswordRequest,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Change user password"""
    
    # Verify current password
    if not verify_password(password_data.current_password, current_user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Current password is incorrect"
        )
    
    # Update password
    current_user.password_hash = get_password_hash(password_data.new_password)
    await db.commit()
    
    logger.info("Password changed", user_id=str(current_user.id))
    
    return {"message": "Password changed successfully"}

@router.post("/logout")
async def logout(current_user: User = Depends(get_current_user)):
    """Logout user (client should discard tokens)"""
    logger.info("User logged out", user_id=str(current_user.id))
    return {"message": "Logged out successfully"}
