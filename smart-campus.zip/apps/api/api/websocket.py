"""
WebSocket endpoints for real-time updates
"""

import asyncio
import json
from typing import Dict, Set, Any
from fastapi import APIRouter, WebSocket, WebSocketDisconnect, Depends, Query
from sqlalchemy.ext.asyncio import AsyncSession
import structlog

from core.database import get_db
from core.security import verify_token

router = APIRouter()
logger = structlog.get_logger()

class ConnectionManager:
    """Manages WebSocket connections"""
    
    def __init__(self):
        self.active_connections: Dict[str, Set[WebSocket]] = {}
        self.user_connections: Dict[str, WebSocket] = {}
    
    async def connect(self, websocket: WebSocket, user_id: str, room_id: str = None):
        """Connect a WebSocket client"""
        await websocket.accept()
        
        # Add to user connections
        self.user_connections[user_id] = websocket
        
        # Add to room-specific connections if specified
        if room_id:
            if room_id not in self.active_connections:
                self.active_connections[room_id] = set()
            self.active_connections[room_id].add(websocket)
        
        logger.info("WebSocket connected", user_id=user_id, room_id=room_id)
    
    def disconnect(self, websocket: WebSocket, user_id: str, room_id: str = None):
        """Disconnect a WebSocket client"""
        
        # Remove from user connections
        if user_id in self.user_connections:
            del self.user_connections[user_id]
        
        # Remove from room connections
        if room_id and room_id in self.active_connections:
            self.active_connections[room_id].discard(websocket)
            if not self.active_connections[room_id]:
                del self.active_connections[room_id]
        
        logger.info("WebSocket disconnected", user_id=user_id, room_id=room_id)
    
    async def send_personal_message(self, message: Dict[str, Any], user_id: str):
        """Send message to specific user"""
        if user_id in self.user_connections:
            websocket = self.user_connections[user_id]
            try:
                await websocket.send_text(json.dumps(message))
            except Exception as e:
                logger.warning("Failed to send personal message", user_id=user_id, error=str(e))
    
    async def broadcast_to_room(self, message: Dict[str, Any], room_id: str):
        """Broadcast message to all clients in a room"""
        if room_id in self.active_connections:
            disconnected = []
            
            for websocket in self.active_connections[room_id]:
                try:
                    await websocket.send_text(json.dumps(message))
                except Exception:
                    disconnected.append(websocket)
            
            # Clean up disconnected clients
            for websocket in disconnected:
                self.active_connections[room_id].discard(websocket)
    
    async def broadcast_to_all(self, message: Dict[str, Any]):
        """Broadcast message to all connected clients"""
        disconnected = []
        
        for websocket in self.user_connections.values():
            try:
                await websocket.send_text(json.dumps(message))
            except Exception:
                disconnected.append(websocket)
        
        # Clean up disconnected clients
        for websocket in disconnected:
            for user_id, ws in list(self.user_connections.items()):
                if ws == websocket:
                    del self.user_connections[user_id]
                    break

# Global connection manager
manager = ConnectionManager()

@router.websocket("/control")
async def websocket_control_endpoint(
    websocket: WebSocket,
    token: str = Query(...),
    room_id: str = Query(None),
    db: AsyncSession = Depends(get_db)
):
    """WebSocket endpoint for real-time device control and telemetry"""
    
    try:
        # Verify token
        token_data = verify_token(token)
        user_id = token_data.user_id
        
        # Connect WebSocket
        await manager.connect(websocket, user_id, room_id)
        
        # Send initial connection confirmation
        await websocket.send_text(json.dumps({
            "type": "connection",
            "status": "connected",
            "user_id": user_id,
            "room_id": room_id,
            "timestamp": "2024-01-01T00:00:00Z"
        }))
        
        # Listen for messages
        while True:
            try:
                data = await websocket.receive_text()
                message = json.loads(data)
                
                await handle_websocket_message(websocket, message, user_id, db)
                
            except WebSocketDisconnect:
                break
            except json.JSONDecodeError:
                await websocket.send_text(json.dumps({
                    "type": "error",
                    "message": "Invalid JSON format"
                }))
            except Exception as e:
                logger.error("Error handling WebSocket message", error=str(e))
                await websocket.send_text(json.dumps({
                    "type": "error",
                    "message": "Internal server error"
                }))
    
    except Exception as e:
        logger.error("WebSocket connection error", error=str(e))
        await websocket.close(code=1008, reason="Authentication failed")
    
    finally:
        manager.disconnect(websocket, user_id, room_id)

async def handle_websocket_message(
    websocket: WebSocket, 
    message: Dict[str, Any], 
    user_id: str,
    db: AsyncSession
):
    """Handle incoming WebSocket message"""
    
    message_type = message.get("type")
    
    if message_type == "ping":
        # Respond to ping with pong
        await websocket.send_text(json.dumps({
            "type": "pong",
            "timestamp": "2024-01-01T00:00:00Z"
        }))
    
    elif message_type == "subscribe":
        # Subscribe to specific data streams
        stream = message.get("stream")
        room_id = message.get("room_id")
        
        # Validate subscription permissions here
        
        await websocket.send_text(json.dumps({
            "type": "subscription",
            "status": "subscribed",
            "stream": stream,
            "room_id": room_id
        }))
    
    elif message_type == "device_command":
        # Handle device command via WebSocket
        device_id = message.get("device_id")
        command = message.get("command")
        
        # Process device command (integrate with device control API)
        # For now, just acknowledge
        await websocket.send_text(json.dumps({
            "type": "command_ack",
            "device_id": device_id,
            "command": command,
            "status": "success"
        }))
    
    else:
        await websocket.send_text(json.dumps({
            "type": "error",
            "message": f"Unknown message type: {message_type}"
        }))

# Functions to be called by other parts of the system
async def broadcast_telemetry_update(device_id: str, telemetry_data: Dict[str, Any]):
    """Broadcast telemetry update to relevant clients"""
    message = {
        "type": "telemetry_update",
        "device_id": device_id,
        "data": telemetry_data,
        "timestamp": "2024-01-01T00:00:00Z"
    }
    
    # Broadcast to all clients (in production, filter by permissions)
    await manager.broadcast_to_all(message)

async def broadcast_device_state_change(device_id: str, new_state: Dict[str, Any]):
    """Broadcast device state change to relevant clients"""
    message = {
        "type": "device_state_change",
        "device_id": device_id,
        "state": new_state,
        "timestamp": "2024-01-01T00:00:00Z"
    }
    
    await manager.broadcast_to_all(message)

async def broadcast_anomaly_alert(anomaly_data: Dict[str, Any]):
    """Broadcast anomaly alert to relevant clients"""
    message = {
        "type": "anomaly_alert",
        "anomaly": anomaly_data,
        "timestamp": "2024-01-01T00:00:00Z"
    }
    
    await manager.broadcast_to_all(message)
