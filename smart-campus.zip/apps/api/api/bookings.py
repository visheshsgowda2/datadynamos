from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.orm import Session
from sqlalchemy import and_, or_
from datetime import datetime, timedelta
from typing import List, Optional
import uuid
import logging

from core.database import get_db
from core.rbac import require_permissions, get_current_user
from models.user import User
from models.booking import Booking, BookingStatus
from models.room import Room
from schemas.booking import (
    BookingCreate, BookingUpdate, BookingResponse, 
    BookingListResponse, CheckInRequest, CheckInResponse
)
from services.booking_service import BookingService
from services.device_control import DeviceControlService

router = APIRouter(prefix="/bookings", tags=["bookings"])
logger = logging.getLogger(__name__)

@router.post("/", response_model=BookingResponse)
async def create_booking(
    booking_data: BookingCreate,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Create a new room booking"""
    
    # Check if user has permission to book this room
    room = db.query(Room).filter(Room.id == booking_data.room_id).first()
    if not room:
        raise HTTPException(status_code=404, detail="Room not found")
    
    # RBAC: Employees can only book rooms they have access to
    if current_user.role == "employee":
        # Check if user has access to this room's building
        user_assignments = current_user.assignments
        building_access = any(
            assignment.resource_type == "building" and 
            assignment.resource_id == room.building_id 
            for assignment in user_assignments
        )
        
        if not building_access:
            raise HTTPException(
                status_code=403, 
                detail="You don't have access to book rooms in this building"
            )
    
    # Check for conflicts
    existing_booking = db.query(Booking).filter(
        and_(
            Booking.room_id == booking_data.room_id,
            Booking.status.in_([BookingStatus.CONFIRMED, BookingStatus.CHECKED_IN]),
            or_(
                and_(
                    Booking.start_time <= booking_data.start_time,
                    Booking.end_time > booking_data.start_time
                ),
                and_(
                    Booking.start_time < booking_data.end_time,
                    Booking.end_time >= booking_data.end_time
                ),
                and_(
                    Booking.start_time >= booking_data.start_time,
                    Booking.end_time <= booking_data.end_time
                )
            )
        )
    ).first()
    
    if existing_booking:
        raise HTTPException(
            status_code=409, 
            detail="Room is already booked for this time period"
        )
    
    # Create booking
    booking = Booking(
        room_id=booking_data.room_id,
        user_id=current_user.id,
        start_time=booking_data.start_time,
        end_time=booking_data.end_time,
        purpose=booking_data.purpose,
        attendees=booking_data.attendees,
        status=BookingStatus.CONFIRMED,
        check_in_code=str(uuid.uuid4())[:8].upper(),  # 8-char check-in code
        created_at=datetime.utcnow()
    )
    
    db.add(booking)
    db.commit()
    db.refresh(booking)
    
    # Schedule auto-release check
    booking_service = BookingService()
    background_tasks.add_task(
        booking_service.schedule_auto_release_check,
        booking.id
    )
    
    logger.info(f"Booking created: {booking.id} for user {current_user.id}")
    
    return BookingResponse.from_orm(booking)

@router.get("/", response_model=BookingListResponse)
async def list_bookings(
    room_id: Optional[int] = None,
    building_id: Optional[int] = None,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    status: Optional[BookingStatus] = None,
    my_bookings: bool = False,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """List bookings with filtering options"""
    
    query = db.query(Booking).join(Room)
    
    # RBAC: Employees can only see their own bookings or bookings in accessible buildings
    if current_user.role == "employee":
        if my_bookings:
            query = query.filter(Booking.user_id == current_user.id)
        else:
            # Filter by accessible buildings
            user_buildings = [
                assignment.resource_id for assignment in current_user.assignments
                if assignment.resource_type == "building"
            ]
            query = query.filter(Room.building_id.in_(user_buildings))
    
    # Apply filters
    if room_id:
        query = query.filter(Booking.room_id == room_id)
    
    if building_id:
        query = query.filter(Room.building_id == building_id)
    
    if start_date:
        query = query.filter(Booking.start_time >= start_date)
    
    if end_date:
        query = query.filter(Booking.end_time <= end_date)
    
    if status:
        query = query.filter(Booking.status == status)
    
    bookings = query.order_by(Booking.start_time).all()
    
    return BookingListResponse(
        bookings=[BookingResponse.from_orm(booking) for booking in bookings],
        total=len(bookings)
    )

@router.get("/{booking_id}", response_model=BookingResponse)
async def get_booking(
    booking_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Get a specific booking"""
    
    booking = db.query(Booking).filter(Booking.id == booking_id).first()
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")
    
    # RBAC: Employees can only see their own bookings
    if current_user.role == "employee" and booking.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Access denied")
    
    return BookingResponse.from_orm(booking)

@router.put("/{booking_id}", response_model=BookingResponse)
async def update_booking(
    booking_id: int,
    booking_data: BookingUpdate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Update a booking"""
    
    booking = db.query(Booking).filter(Booking.id == booking_id).first()
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")
    
    # RBAC: Employees can only update their own bookings
    if current_user.role == "employee" and booking.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Access denied")
    
    # Can't update checked-in or completed bookings
    if booking.status in [BookingStatus.CHECKED_IN, BookingStatus.COMPLETED]:
        raise HTTPException(
            status_code=400, 
            detail="Cannot update booking that is checked-in or completed"
        )
    
    # Update fields
    for field, value in booking_data.dict(exclude_unset=True).items():
        setattr(booking, field, value)
    
    booking.updated_at = datetime.utcnow()
    
    db.commit()
    db.refresh(booking)
    
    return BookingResponse.from_orm(booking)

@router.delete("/{booking_id}")
async def cancel_booking(
    booking_id: int,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Cancel a booking"""
    
    booking = db.query(Booking).filter(Booking.id == booking_id).first()
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")
    
    # RBAC: Employees can only cancel their own bookings
    if current_user.role == "employee" and booking.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Access denied")
    
    # Can't cancel completed bookings
    if booking.status == BookingStatus.COMPLETED:
        raise HTTPException(status_code=400, detail="Cannot cancel completed booking")
    
    booking.status = BookingStatus.CANCELLED
    booking.updated_at = datetime.utcnow()
    
    db.commit()
    
    # Trigger eco scene if booking was active
    if booking.status in [BookingStatus.CONFIRMED, BookingStatus.CHECKED_IN]:
        device_service = DeviceControlService()
        background_tasks.add_task(
            device_service.trigger_eco_scene,
            booking.room_id
        )
    
    logger.info(f"Booking cancelled: {booking_id}")
    
    return {"message": "Booking cancelled successfully"}

@router.post("/{booking_id}/check-in", response_model=CheckInResponse)
async def check_in_booking(
    booking_id: int,
    check_in_data: CheckInRequest,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Check in to a booking using QR/NFC code"""
    
    booking = db.query(Booking).filter(Booking.id == booking_id).first()
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")
    
    # RBAC: Employees can only check in to their own bookings
    if current_user.role == "employee" and booking.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Access denied")
    
    # Validate check-in code
    if booking.check_in_code != check_in_data.check_in_code:
        raise HTTPException(status_code=400, detail="Invalid check-in code")
    
    # Check if booking is in valid state for check-in
    if booking.status != BookingStatus.CONFIRMED:
        raise HTTPException(
            status_code=400, 
            detail=f"Cannot check in to booking with status: {booking.status}"
        )
    
    # Check if check-in is within valid time window (15 minutes before to 10 minutes after start)
    now = datetime.utcnow()
    check_in_window_start = booking.start_time - timedelta(minutes=15)
    check_in_window_end = booking.start_time + timedelta(minutes=10)
    
    if now < check_in_window_start:
        raise HTTPException(
            status_code=400, 
            detail="Check-in window not yet open (opens 15 minutes before booking)"
        )
    
    if now > check_in_window_end:
        raise HTTPException(
            status_code=400, 
            detail="Check-in window closed (closes 10 minutes after booking start)"
        )
    
    # Update booking status
    booking.status = BookingStatus.CHECKED_IN
    booking.checked_in_at = now
    booking.updated_at = now
    
    db.commit()
    
    # Trigger comfort scene for the room
    device_service = DeviceControlService()
    background_tasks.add_task(
        device_service.trigger_comfort_scene,
        booking.room_id
    )
    
    logger.info(f"Booking checked in: {booking_id} at {now}")
    
    return CheckInResponse(
        success=True,
        message="Successfully checked in to booking",
        booking_id=booking_id,
        checked_in_at=now
    )

@router.post("/{booking_id}/extend")
async def extend_booking(
    booking_id: int,
    extension_minutes: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Extend a booking duration"""
    
    booking = db.query(Booking).filter(Booking.id == booking_id).first()
    if not booking:
        raise HTTPException(status_code=404, detail="Booking not found")
    
    # RBAC: Employees can only extend their own bookings
    if current_user.role == "employee" and booking.user_id != current_user.id:
        raise HTTPException(status_code=403, detail="Access denied")
    
    # Can only extend checked-in bookings
    if booking.status != BookingStatus.CHECKED_IN:
        raise HTTPException(status_code=400, detail="Can only extend checked-in bookings")
    
    # Check for conflicts with extended time
    new_end_time = booking.end_time + timedelta(minutes=extension_minutes)
    
    conflicting_booking = db.query(Booking).filter(
        and_(
            Booking.room_id == booking.room_id,
            Booking.id != booking.id,
            Booking.status.in_([BookingStatus.CONFIRMED, BookingStatus.CHECKED_IN]),
            Booking.start_time < new_end_time,
            Booking.start_time >= booking.end_time
        )
    ).first()
    
    if conflicting_booking:
        raise HTTPException(
            status_code=409, 
            detail="Cannot extend booking due to conflicting reservation"
        )
    
    booking.end_time = new_end_time
    booking.updated_at = datetime.utcnow()
    
    db.commit()
    
    return {"message": f"Booking extended by {extension_minutes} minutes"}

@router.get("/room/{room_id}/availability")
async def check_room_availability(
    room_id: int,
    start_time: datetime,
    end_time: datetime,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user)
):
    """Check if a room is available for booking"""
    
    room = db.query(Room).filter(Room.id == room_id).first()
    if not room:
        raise HTTPException(status_code=404, detail="Room not found")
    
    # Check for existing bookings
    conflicting_bookings = db.query(Booking).filter(
        and_(
            Booking.room_id == room_id,
            Booking.status.in_([BookingStatus.CONFIRMED, BookingStatus.CHECKED_IN]),
            or_(
                and_(Booking.start_time <= start_time, Booking.end_time > start_time),
                and_(Booking.start_time < end_time, Booking.end_time >= end_time),
                and_(Booking.start_time >= start_time, Booking.end_time <= end_time)
            )
        )
    ).all()
    
    is_available = len(conflicting_bookings) == 0
    
    return {
        "room_id": room_id,
        "start_time": start_time,
        "end_time": end_time,
        "is_available": is_available,
        "conflicting_bookings": [
            {
                "id": booking.id,
                "start_time": booking.start_time,
                "end_time": booking.end_time,
                "user_id": booking.user_id
            }
            for booking in conflicting_bookings
        ]
    }
