from fastapi import APIRouter, Depends, HTTPException, BackgroundTasks
from sqlalchemy.orm import Session
from sqlalchemy import and_, func, text
from datetime import datetime, timedelta
from typing import List, Optional, Dict, Any
import pandas as pd
import logging

from core.database import get_db
from core.rbac import require_permissions, get_current_user
from models.user import User
from models.building import Building
from models.room import Room
from models.billing import Bill, BillStatus
from models.report import Report, ReportType, ReportStatus
from models.telemetry import EnergyRollup
from schemas.report import (
    ReportRequest, ReportResponse, BillResponse, 
    EnergyAnalyticsResponse, ComplianceReportResponse
)
from services.report_service import ReportService
from services.genai import GenAIService

router = APIRouter(prefix="/reports", tags=["reports"])
logger = logging.getLogger(__name__)

@router.post("/energy-bill", response_model=BillResponse)
async def generate_energy_bill(
    building_id: int,
    start_date: datetime,
    end_date: datetime,
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permissions(["reports:read"]))
):
    """Generate energy bill for a building and period"""
    
    building = db.query(Building).filter(Building.id == building_id).first()
    if not building:
        raise HTTPException(status_code=404, detail="Building not found")
    
    report_service = ReportService()
    
    try:
        # Generate bill data
        bill_data = await report_service.generate_energy_bill(
            building_id=building_id,
            start_date=start_date,
            end_date=end_date
        )
        
        # Create bill record
        bill = Bill(
            building_id=building_id,
            period_start=start_date,
            period_end=end_date,
            total_consumption=bill_data["total_consumption"],
            total_cost=bill_data["total_cost"],
            breakdown=bill_data["breakdown"],
            status=BillStatus.GENERATED,
            generated_by=current_user.id,
            generated_at=datetime.utcnow()
        )
        
        db.add(bill)
        db.commit()
        db.refresh(bill)
        
        # Generate AI summary if previous bill exists
        previous_bill = db.query(Bill).filter(
            and_(
                Bill.building_id == building_id,
                Bill.period_end < start_date,
                Bill.status == BillStatus.GENERATED
            )
        ).order_by(Bill.period_end.desc()).first()
        
        if previous_bill:
            genai_service = GenAIService()
            background_tasks.add_task(
                genai_service.generate_bill_summary,
                current_bill_id=bill.id,
                previous_bill_id=previous_bill.id
            )
        
        logger.info(f"Generated energy bill {bill.id} for building {building_id}")
        
        return BillResponse.from_orm(bill)
        
    except Exception as e:
        logger.error(f"Error generating energy bill: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/energy-analytics", response_model=EnergyAnalyticsResponse)
async def get_energy_analytics(
    building_id: Optional[int] = None,
    room_id: Optional[int] = None,
    days_back: int = 30,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permissions(["reports:read"]))
):
    """Get energy consumption analytics and trends"""
    
    try:
        report_service = ReportService()
        
        analytics = await report_service.get_energy_analytics(
            building_id=building_id,
            room_id=room_id,
            days_back=days_back
        )
        
        return EnergyAnalyticsResponse(**analytics)
        
    except Exception as e:
        logger.error(f"Error getting energy analytics: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.post("/compliance-report", response_model=ComplianceReportResponse)
async def generate_compliance_report(
    building_id: int,
    report_period: str,  # "monthly", "quarterly", "annual"
    background_tasks: BackgroundTasks,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permissions(["reports:create"]))
):
    """Generate compliance report with AI-generated narratives"""
    
    building = db.query(Building).filter(Building.id == building_id).first()
    if not building:
        raise HTTPException(status_code=404, detail="Building not found")
    
    try:
        report_service = ReportService()
        
        # Generate compliance data
        compliance_data = await report_service.generate_compliance_data(
            building_id=building_id,
            report_period=report_period
        )
        
        # Create report record
        report = Report(
            building_id=building_id,
            report_type=ReportType.COMPLIANCE,
            title=f"{report_period.title()} Compliance Report - {building.name}",
            data=compliance_data,
            status=ReportStatus.GENERATING,
            generated_by=current_user.id,
            created_at=datetime.utcnow()
        )
        
        db.add(report)
        db.commit()
        db.refresh(report)
        
        # Generate AI narrative
        genai_service = GenAIService()
        background_tasks.add_task(
            genai_service.generate_compliance_report,
            building_id=building_id,
            report_period=report_period,
            compliance_data=compliance_data,
            report_id=report.id
        )
        
        logger.info(f"Started compliance report generation {report.id}")
        
        return ComplianceReportResponse.from_orm(report)
        
    except Exception as e:
        logger.error(f"Error generating compliance report: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/time-series/energy")
async def get_energy_time_series(
    building_id: Optional[int] = None,
    room_id: Optional[int] = None,
    start_date: Optional[datetime] = None,
    end_date: Optional[datetime] = None,
    granularity: str = "hourly",  # "hourly", "daily", "weekly"
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permissions(["reports:read"]))
):
    """Get time-series energy consumption data"""
    
    try:
        # Default to last 7 days if no dates provided
        if not end_date:
            end_date = datetime.utcnow()
        if not start_date:
            start_date = end_date - timedelta(days=7)
        
        # Build query based on granularity
        if granularity == "hourly":
            time_format = "YYYY-MM-DD HH24:00:00"
            time_bucket = "1 hour"
        elif granularity == "daily":
            time_format = "YYYY-MM-DD"
            time_bucket = "1 day"
        elif granularity == "weekly":
            time_format = "YYYY-\"W\"WW"
            time_bucket = "1 week"
        else:
            raise HTTPException(status_code=400, detail="Invalid granularity")
        
        # Build SQL query
        query = text(f"""
            SELECT 
                time_bucket('{time_bucket}', timestamp) as time_bucket,
                SUM(total_consumption) as total_consumption,
                SUM(hvac_consumption) as hvac_consumption,
                SUM(lighting_consumption) as lighting_consumption,
                SUM(equipment_consumption) as equipment_consumption,
                AVG(total_consumption) as avg_consumption
            FROM energy_rollups er
            JOIN rooms r ON er.room_id = r.id
            WHERE er.timestamp >= :start_date 
            AND er.timestamp <= :end_date
        """)
        
        params = {"start_date": start_date, "end_date": end_date}
        
        if building_id:
            query = text(str(query) + " AND r.building_id = :building_id")
            params["building_id"] = building_id
        
        if room_id:
            query = text(str(query) + " AND er.room_id = :room_id")
            params["room_id"] = room_id
        
        query = text(str(query) + " GROUP BY time_bucket ORDER BY time_bucket")
        
        result = db.execute(query, params)
        rows = result.fetchall()
        
        # Format response
        time_series = []
        for row in rows:
            time_series.append({
                "timestamp": row.time_bucket.isoformat(),
                "total_consumption": float(row.total_consumption or 0),
                "hvac_consumption": float(row.hvac_consumption or 0),
                "lighting_consumption": float(row.lighting_consumption or 0),
                "equipment_consumption": float(row.equipment_consumption or 0),
                "avg_consumption": float(row.avg_consumption or 0)
            })
        
        return {
            "time_series": time_series,
            "granularity": granularity,
            "start_date": start_date.isoformat(),
            "end_date": end_date.isoformat(),
            "building_id": building_id,
            "room_id": room_id,
            "total_points": len(time_series)
        }
        
    except Exception as e:
        logger.error(f"Error getting time series data: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/bills", response_model=List[BillResponse])
async def list_bills(
    building_id: Optional[int] = None,
    status: Optional[BillStatus] = None,
    limit: int = 50,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permissions(["reports:read"]))
):
    """List energy bills with filtering"""
    
    query = db.query(Bill)
    
    if building_id:
        query = query.filter(Bill.building_id == building_id)
    
    if status:
        query = query.filter(Bill.status == status)
    
    bills = query.order_by(Bill.period_end.desc()).limit(limit).all()
    
    return [BillResponse.from_orm(bill) for bill in bills]

@router.get("/bills/{bill_id}", response_model=BillResponse)
async def get_bill(
    bill_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permissions(["reports:read"]))
):
    """Get a specific bill with details"""
    
    bill = db.query(Bill).filter(Bill.id == bill_id).first()
    if not bill:
        raise HTTPException(status_code=404, detail="Bill not found")
    
    return BillResponse.from_orm(bill)

@router.get("/reports", response_model=List[ReportResponse])
async def list_reports(
    building_id: Optional[int] = None,
    report_type: Optional[ReportType] = None,
    status: Optional[ReportStatus] = None,
    limit: int = 50,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permissions(["reports:read"]))
):
    """List reports with filtering"""
    
    query = db.query(Report)
    
    if building_id:
        query = query.filter(Report.building_id == building_id)
    
    if report_type:
        query = query.filter(Report.report_type == report_type)
    
    if status:
        query = query.filter(Report.status == status)
    
    reports = query.order_by(Report.created_at.desc()).limit(limit).all()
    
    return [ReportResponse.from_orm(report) for report in reports]

@router.post("/export/{report_id}")
async def export_report(
    report_id: int,
    format: str = "pdf",  # "pdf", "excel", "csv"
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permissions(["reports:export"]))
):
    """Export report in specified format"""
    
    report = db.query(Report).filter(Report.id == report_id).first()
    if not report:
        raise HTTPException(status_code=404, detail="Report not found")
    
    try:
        report_service = ReportService()
        
        export_data = await report_service.export_report(
            report=report,
            format=format
        )
        
        return {
            "download_url": export_data["download_url"],
            "filename": export_data["filename"],
            "format": format,
            "generated_at": datetime.utcnow().isoformat()
        }
        
    except Exception as e:
        logger.error(f"Error exporting report: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@router.get("/dashboard-metrics")
async def get_dashboard_metrics(
    building_id: Optional[int] = None,
    db: Session = Depends(get_db),
    current_user: User = Depends(require_permissions(["reports:read"]))
):
    """Get real-time metrics for dashboard"""
    
    try:
        report_service = ReportService()
        
        metrics = await report_service.get_dashboard_metrics(
            building_id=building_id
        )
        
        return metrics
        
    except Exception as e:
        logger.error(f"Error getting dashboard metrics: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))
