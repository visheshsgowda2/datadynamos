"""
Device control API endpoints
"""

from datetime import datetime
from typing import List, Dict, Any, Optional
from fastapi import APIRouter, Depends, HTTPException, status, Query
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, update
from pydantic import BaseModel
import structlog

from core.database import get_db
from core.rbac import require_scopes, get_current_user, check_resource_access
from models.user import User
from models.device import Device, DeviceType
from models.room import Room
from models.audit_log import AuditLog

router = APIRouter()
logger = structlog.get_logger()

class DeviceCommand(BaseModel):
    action: str  # "set", "toggle", "scene"
    target: Optional[str] = None  # "power", "brightness", "temperature", etc.
    value: Optional[Any] = None
    scope: Optional[Dict[str, Any]] = None

class DeviceResponse(BaseModel):
    id: str
    room_id: str
    type: DeviceType
    model: Optional[str]
    state: Dict[str, Any]
    last_seen: Optional[datetime]
    
    class Config:
        from_attributes = True

class DeviceStateUpdate(BaseModel):
    state: Dict[str, Any]

@router.get("/", response_model=Dict[str, Any])
async def get_devices(
    room_id: Optional[str] = Query(None),
    device_type: Optional[DeviceType] = Query(None),
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get devices with optional filtering"""
    
    # Build query
    query = select(Device)
    
    if room_id:
        # Check if user has access to this room
        token_data = await get_current_user_token_data(current_user)
        if not check_resource_access(token_data.scopes, "room", room_id, "read"):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied to this room"
            )
        query = query.where(Device.room_id == room_id)
    
    if device_type:
        query = query.where(Device.type == device_type)
    
    # Execute query
    result = await db.execute(query)
    devices = result.scalars().all()
    
    # Filter devices based on user permissions
    accessible_devices = []
    for device in devices:
        if check_resource_access(token_data.scopes, "room", device.room_id, "read"):
            accessible_devices.append(device)
    
    return {
        "devices": [DeviceResponse.model_validate(device) for device in accessible_devices],
        "total": len(accessible_devices)
    }

@router.get("/{device_id}", response_model=DeviceResponse)
async def get_device(
    device_id: str,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Get specific device"""
    
    # Get device
    result = await db.execute(
        select(Device).where(Device.id == device_id)
    )
    device = result.scalar_one_or_none()
    
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found"
        )
    
    # Check permissions
    token_data = await get_current_user_token_data(current_user)
    if not check_resource_access(token_data.scopes, "room", device.room_id, "read"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied to this device"
        )
    
    return DeviceResponse.model_validate(device)

@router.put("/{device_id}/command")
async def send_device_command(
    device_id: str,
    command: DeviceCommand,
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Send command to device"""
    
    # Get device
    result = await db.execute(
        select(Device).where(Device.id == device_id)
    )
    device = result.scalar_one_or_none()
    
    if not device:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found"
        )
    
    # Check permissions
    token_data = await get_current_user_token_data(current_user)
    if not check_resource_access(token_data.scopes, "room", device.room_id, "write"):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Access denied to control this device"
        )
    
    # Validate command
    if not _validate_device_command(device, command):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Invalid command for this device type"
        )
    
    # Send command via MQTT (would be implemented with MQTT client)
    # For now, simulate immediate response
    new_state = _simulate_command_execution(device.state, command)
    
    # Update device state
    await db.execute(
        update(Device)
        .where(Device.id == device_id)
        .values(state=new_state, last_seen=datetime.utcnow())
    )
    
    # Log action
    audit_log = AuditLog(
        user_id=current_user.id,
        action="device_command",
        resource="device",
        resource_id=device_id,
        scope={"room_id": device.room_id},
        metadata={
            "command": command.model_dump(),
            "previous_state": device.state,
            "new_state": new_state
        }
    )
    db.add(audit_log)
    
    await db.commit()
    
    logger.info("Device command sent", 
                device_id=device_id, 
                user_id=str(current_user.id),
                command=command.model_dump())
    
    return {
        "message": "Command sent successfully",
        "device_id": device_id,
        "command": command.model_dump(),
        "new_state": new_state
    }

@router.put("/{device_id}/state")
async def update_device_state(
    device_id: str,
    state_update: DeviceStateUpdate,
    db: AsyncSession = Depends(get_db)
):
    """Update device state (used by IoT simulator)"""
    
    # This endpoint is used by the IoT simulator to update device states
    # In production, this would require API key authentication
    
    result = await db.execute(
        update(Device)
        .where(Device.id == device_id)
        .values(state=state_update.state, last_seen=datetime.utcnow())
    )
    
    if result.rowcount == 0:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Device not found"
        )
    
    await db.commit()
    
    return {"message": "Device state updated"}

@router.post("/scenes/{scene_id}/apply")
async def apply_scene(
    scene_id: str,
    scope: Dict[str, Any],
    current_user: User = Depends(get_current_user),
    db: AsyncSession = Depends(get_db)
):
    """Apply scene to devices in specified scope"""
    
    # Get scene
    from models.policy import Scene
    result = await db.execute(
        select(Scene).where(Scene.id == scene_id)
    )
    scene = result.scalar_one_or_none()
    
    if not scene:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Scene not found"
        )
    
    # Check permissions for scope
    token_data = await get_current_user_token_data(current_user)
    
    if "room_id" in scope:
        if not check_resource_access(token_data.scopes, "room", scope["room_id"], "write"):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Access denied to apply scene in this room"
            )
    
    # Apply scene (would send MQTT commands to IoT simulator)
    # For now, simulate scene application
    
    # Log action
    audit_log = AuditLog(
        user_id=current_user.id,
        action="scene_applied",
        resource="scene",
        resource_id=scene_id,
        scope=scope,
        metadata={"scene_payload": scene.payload}
    )
    db.add(audit_log)
    
    await db.commit()
    
    logger.info("Scene applied", 
                scene_id=scene_id,
                user_id=str(current_user.id),
                scope=scope)
    
    return {
        "message": "Scene applied successfully",
        "scene_id": scene_id,
        "scope": scope
    }

def _validate_device_command(device: Device, command: DeviceCommand) -> bool:
    """Validate if command is valid for device type"""
    
    device_type = device.type
    action = command.action
    target = command.target
    
    valid_commands = {
        DeviceType.LIGHT: {
            "set": ["power", "brightness"],
            "toggle": ["power"]
        },
        DeviceType.HVAC: {
            "set": ["power", "temperature", "mode"],
            "toggle": ["power"]
        },
        DeviceType.PROJECTOR: {
            "set": ["power", "input"],
            "toggle": ["power"]
        },
        DeviceType.PLUG: {
            "set": ["power"],
            "toggle": ["power"]
        }
    }
    
    if device_type not in valid_commands:
        return False
    
    if action not in valid_commands[device_type]:
        return False
    
    if target and target not in valid_commands[device_type][action]:
        return False
    
    return True

def _simulate_command_execution(current_state: Dict[str, Any], command: DeviceCommand) -> Dict[str, Any]:
    """Simulate command execution and return new state"""
    
    new_state = current_state.copy()
    
    if command.action == "set" and command.target and command.value is not None:
        new_state[command.target] = command.value
    elif command.action == "toggle" and command.target:
        if command.target in new_state:
            new_state[command.target] = not new_state[command.target]
    
    return new_state

async def get_current_user_token_data(user: User):
    """Helper to get token data for current user"""
    # This would normally be extracted from the JWT token
    # For now, simulate based on user role
    from core.security import generate_scopes
    
    # Simulate assignments (in real implementation, query from DB)
    assignments = []
    scopes = generate_scopes(user.role, assignments)
    
    class TokenData:
        def __init__(self, scopes):
            self.scopes = scopes
    
    return TokenData(scopes)
