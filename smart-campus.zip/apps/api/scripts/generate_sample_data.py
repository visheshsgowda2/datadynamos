"""
Generate additional sample data for testing and demos
"""

import asyncio
import random
from datetime import datetime, timedelta
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from core.database import AsyncSessionLocal
from models.telemetry import TelemetryTS, EnergyTS
from models.device import Device
from models.room import Room

async def generate_realtime_data():
    """Generate real-time telemetry data for the last hour"""
    
    async with AsyncSessionLocal() as db:
        # Get sample devices
        devices_result = await db.execute(select(Device).limit(20))
        devices = list(devices_result.scalars().all())
        
        rooms_result = await db.execute(select(Room).limit(10))
        rooms = list(rooms_result.scalars().all())
        
        # Generate data for last hour with 1-minute intervals
        end_time = datetime.utcnow()
        start_time = end_time - timedelta(hours=1)
        
        current_time = start_time
        
        while current_time <= end_time:
            # Device telemetry
            for device in devices:
                if device.type.value == "light":
                    # Simulate light power consumption
                    base_power = 15.0
                    variation = random.uniform(-3.0, 3.0)
                    power = max(0, base_power + variation) if device.state.get("power") else 0
                    
                    telemetry = TelemetryTS(
                        time=current_time,
                        device_id=device.id,
                        metric="power_w",
                        value=power
                    )
                    db.add(telemetry)
                    
                elif device.type.value == "hvac":
                    # Simulate HVAC power with daily patterns
                    hour = current_time.hour
                    base_power = 2.0
                    
                    # Higher consumption during business hours
                    if 8 <= hour <= 18:
                        base_power = 2.5
                    elif 19 <= hour <= 22:
                        base_power = 1.8
                    else:
                        base_power = 1.2
                    
                    variation = random.uniform(-0.3, 0.3)
                    power = max(0.5, base_power + variation)
                    
                    telemetry = TelemetryTS(
                        time=current_time,
                        device_id=device.id,
                        metric="power_kw",
                        value=power
                    )
                    db.add(telemetry)
                    
                elif device.type.value == "sensor":
                    # Simulate occupancy based on time of day
                    hour = current_time.hour
                    occupancy_prob = 0.1  # Default low occupancy
                    
                    if 8 <= hour <= 12:
                        occupancy_prob = 0.7  # Morning high occupancy
                    elif 13 <= hour <= 17:
                        occupancy_prob = 0.6  # Afternoon moderate occupancy
                    elif 18 <= hour <= 20:
                        occupancy_prob = 0.3  # Evening low occupancy
                    
                    occupancy = 1.0 if random.random() < occupancy_prob else 0.0
                    
                    telemetry = TelemetryTS(
                        time=current_time,
                        device_id=device.id,
                        metric="occupancy",
                        value=occupancy
                    )
                    db.add(telemetry)
                    
                    # Temperature with slight variations
                    base_temp = 22.0
                    temp_variation = random.uniform(-1.5, 1.5)
                    temperature = base_temp + temp_variation
                    
                    temp_telemetry = TelemetryTS(
                        time=current_time,
                        device_id=device.id,
                        metric="temperature",
                        value=temperature
                    )
                    db.add(temp_telemetry)
            
            # Room energy aggregation
            for room in rooms:
                # Aggregate power from room devices (simplified)
                base_kw = random.uniform(1.0, 4.0)
                hour = current_time.hour
                
                # Business hours multiplier
                if 8 <= hour <= 18:
                    multiplier = 1.2
                else:
                    multiplier = 0.6
                
                kw = base_kw * multiplier
                kwh_increment = kw / 60  # Per minute
                
                energy = EnergyTS(
                    time=current_time,
                    room_id=room.id,
                    kw=kw,
                    kwh_rollup=kwh_increment
                )
                db.add(energy)
            
            current_time += timedelta(minutes=1)
        
        await db.commit()
        print(f"✓ Generated real-time data for {len(devices)} devices and {len(rooms)} rooms")

async def simulate_anomaly_conditions():
    """Create conditions that would trigger anomaly detection"""
    
    async with AsyncSessionLocal() as db:
        # Get a few devices to create anomalies
        devices_result = await db.execute(select(Device).limit(3))
        devices = list(devices_result.scalars().all())
        
        current_time = datetime.utcnow()
        
        for i, device in enumerate(devices):
            if device.type.value == "hvac":
                # Create stuck HVAC (high power consumption)
                anomalous_power = 4.5  # Much higher than normal
                
                telemetry = TelemetryTS(
                    time=current_time,
                    device_id=device.id,
                    metric="power_kw",
                    value=anomalous_power,
                    tags={"anomaly_simulation": True}
                )
                db.add(telemetry)
                
            elif device.type.value == "light":
                # Create light that's stuck on during off-hours
                if current_time.hour < 7 or current_time.hour > 19:
                    anomalous_power = 25.0  # High power during off-hours
                    
                    telemetry = TelemetryTS(
                        time=current_time,
                        device_id=device.id,
                        metric="power_w",
                        value=anomalous_power,
                        tags={"anomaly_simulation": True}
                    )
                    db.add(telemetry)
        
        await db.commit()
        print("✓ Simulated anomaly conditions")

if __name__ == "__main__":
    print("🔄 Generating additional sample data...")
    asyncio.run(generate_realtime_data())
    asyncio.run(simulate_anomaly_conditions())
    print("✅ Sample data generation completed!")
