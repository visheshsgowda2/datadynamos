"""
Database seeding script for demo data
"""

import asyncio
import random
from datetime import datetime, timedelta, date
from decimal import Decimal
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from core.database import AsyncSessionLocal, engine, Base
from core.security import get_password_hash
from models.user import User, UserRole, UserStatus
from models.assignment import Assignment
from models.building import Building, Floor, Room
from models.device import Device, DeviceType
from models.telemetry import TelemetryTS, EnergyTS
from models.booking import Booking, BookingStatus
from models.policy import Policy, Scene
from models.anomaly import Anomaly, AnomalySeverity, AnomalyStatus
from models.billing import Bill
from models.report import Report, AuditLog

async def create_tables():
    """Create all database tables"""
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    print("✓ Database tables created")

async def seed_users(db: AsyncSession):
    """Create demo users with different roles"""
    
    users_data = [
        {
            "name": "John CEO",
            "email": "ceo@demo.local",
            "role": UserRole.CEO,
            "dept": "Executive",
            "password": "Pass123!"
        },
        {
            "name": "Sarah Manager",
            "email": "fm@demo.local",
            "role": UserRole.FACILITY_MANAGER,
            "dept": "Facilities",
            "password": "Pass123!"
        },
        {
            "name": "Mike Admin",
            "email": "admin@demo.local",
            "role": UserRole.BUILDING_ADMIN,
            "dept": "Operations",
            "password": "Pass123!"
        },
        {
            "name": "Lisa Receptionist",
            "email": "reception@demo.local",
            "role": UserRole.RECEPTIONIST,
            "dept": "Front Desk",
            "password": "Pass123!"
        },
        {
            "name": "Tom Employee",
            "email": "emp@demo.local",
            "role": UserRole.EMPLOYEE,
            "dept": "Engineering",
            "password": "Pass123!"
        },
        {
            "name": "Jane Auditor",
            "email": "auditor@demo.local",
            "role": UserRole.AUDITOR,
            "dept": "Compliance",
            "password": "Pass123!"
        },
        {
            "name": "Bob Security",
            "email": "security@demo.local",
            "role": UserRole.SECURITY,
            "dept": "Security",
            "password": "Pass123!"
        }
    ]
    
    for user_data in users_data:
        user = User(
            name=user_data["name"],
            email=user_data["email"],
            role=user_data["role"],
            dept=user_data["dept"],
            password_hash=get_password_hash(user_data["password"]),
            status=UserStatus.ACTIVE
        )
        db.add(user)
    
    await db.commit()
    print("✓ Demo users created")

async def seed_buildings(db: AsyncSession):
    """Create building hierarchy"""
    
    # Buildings
    buildings_data = [
        {
            "id": "MAIN",
            "name": "Main Campus Building",
            "address": "123 University Ave, Campus City, CC 12345"
        },
        {
            "id": "TECH",
            "name": "Technology Center",
            "address": "456 Innovation Blvd, Campus City, CC 12345"
        },
        {
            "id": "ADMIN",
            "name": "Administration Building",
            "address": "789 Admin Way, Campus City, CC 12345"
        }
    ]
    
    for building_data in buildings_data:
        building = Building(**building_data)
        db.add(building)
    
    # Floors
    floors_data = []
    for building_id in ["MAIN", "TECH", "ADMIN"]:
        for floor_num in range(1, 5):  # 4 floors each
            floors_data.append({
                "id": f"{building_id}-{floor_num}F",
                "building_id": building_id,
                "name": f"Floor {floor_num}",
                "number": floor_num
            })
    
    for floor_data in floors_data:
        floor = Floor(**floor_data)
        db.add(floor)
    
    # Rooms
    room_types = [
        {"prefix": "CONF", "name": "Conference Room", "capacity": 12, "amenities": ["projector", "whiteboard", "video_conf"]},
        {"prefix": "MEET", "name": "Meeting Room", "capacity": 6, "amenities": ["whiteboard", "tv"]},
        {"prefix": "OFFICE", "name": "Office", "capacity": 2, "amenities": ["desk", "computer"]},
        {"prefix": "LAB", "name": "Laboratory", "capacity": 20, "amenities": ["equipment", "safety_shower"]},
        {"prefix": "CLASS", "name": "Classroom", "capacity": 30, "amenities": ["projector", "whiteboard", "audio"]}
    ]
    
    for building_id in ["MAIN", "TECH", "ADMIN"]:
        for floor_num in range(1, 5):
            floor_id = f"{building_id}-{floor_num}F"
            
            for room_num in range(1, 11):  # 10 rooms per floor
                room_type = random.choice(room_types)
                room = Room(
                    id=f"{building_id}-{floor_num}F-{room_num:03d}",
                    floor_id=floor_id,
                    name=f"{room_type['name']} {room_num:03d}",
                    capacity=room_type["capacity"],
                    amenities=room_type["amenities"],
                    area_sqm=Decimal(str(random.uniform(15.0, 50.0)))
                )
                db.add(room)
    
    await db.commit()
    print("✓ Building hierarchy created (3 buildings, 12 floors, 120 rooms)")

async def seed_devices(db: AsyncSession):
    """Create devices for each room"""
    
    # Get all rooms
    result = await db.execute(select(Room))
    rooms = result.scalars().all()
    
    device_configs = {
        DeviceType.LIGHT: {"count": 2, "models": ["Philips Hue", "LIFX", "Smart LED"]},
        DeviceType.HVAC: {"count": 1, "models": ["Nest Thermostat", "Honeywell", "Ecobee"]},
        DeviceType.PLUG: {"count": 3, "models": ["Smart Outlet", "TP-Link Kasa", "Belkin WeMo"]},
        DeviceType.PROJECTOR: {"count": 1, "models": ["Epson", "BenQ", "Sony"]},
        DeviceType.SENSOR: {"count": 2, "models": ["Motion Sensor", "Occupancy Sensor", "Temperature Sensor"]}
    }
    
    for room in rooms:
        for device_type, config in device_configs.items():
            # Skip projectors for offices and some rooms
            if device_type == DeviceType.PROJECTOR and "Office" in room.name:
                continue
                
            for i in range(config["count"]):
                device = Device(
                    id=f"{room.id}-{device_type.value}-{i+1:02d}",
                    room_id=room.id,
                    type=device_type,
                    model=random.choice(config["models"]),
                    state={
                        "power": random.choice([True, False]),
                        "brightness": random.randint(0, 100) if device_type == DeviceType.LIGHT else None,
                        "temperature": random.randint(18, 26) if device_type == DeviceType.HVAC else None,
                        "occupancy": random.choice([True, False]) if device_type == DeviceType.SENSOR else None
                    },
                    last_seen=datetime.utcnow() - timedelta(minutes=random.randint(0, 60))
                )
                db.add(device)
    
    await db.commit()
    print("✓ Devices created for all rooms")

async def seed_assignments(db: AsyncSession):
    """Create user assignments for RBAC"""
    
    # Get users
    users_result = await db.execute(select(User))
    users = {user.email: user for user in users_result.scalars().all()}
    
    # CEO and Facility Manager get campus-wide access (no specific assignments needed)
    
    # Building Admin gets assigned to MAIN building
    admin_assignment = Assignment(
        user_id=users["admin@demo.local"].id,
        building_id="MAIN"
    )
    db.add(admin_assignment)
    
    # Receptionist gets assigned to MAIN building
    reception_assignment = Assignment(
        user_id=users["reception@demo.local"].id,
        building_id="MAIN"
    )
    db.add(reception_assignment)
    
    # Employee gets assigned to specific rooms
    employee_assignments = [
        Assignment(
            user_id=users["emp@demo.local"].id,
            room_id="MAIN-2F-005"
        ),
        Assignment(
            user_id=users["emp@demo.local"].id,
            room_id="TECH-1F-003"
        )
    ]
    
    for assignment in employee_assignments:
        db.add(assignment)
    
    await db.commit()
    print("✓ User assignments created")

async def seed_telemetry_data(db: AsyncSession):
    """Create sample telemetry and energy data"""
    
    # Get all devices
    devices_result = await db.execute(select(Device))
    devices = devices_result.scalars().all()
    
    # Get all rooms
    rooms_result = await db.execute(select(Room))
    rooms = rooms_result.scalars().all()
    
    # Generate data for last 7 days
    end_time = datetime.utcnow()
    start_time = end_time - timedelta(days=7)
    
    current_time = start_time
    
    while current_time <= end_time:
        # Device telemetry
        for device in devices[:50]:  # Limit to first 50 devices for demo
            if device.type == DeviceType.LIGHT:
                telemetry = TelemetryTS(
                    time=current_time,
                    device_id=device.id,
                    metric="power_w",
                    value=random.uniform(5.0, 25.0) if device.state.get("power") else 0.0
                )
                db.add(telemetry)
                
            elif device.type == DeviceType.HVAC:
                telemetry = TelemetryTS(
                    time=current_time,
                    device_id=device.id,
                    metric="power_kw",
                    value=random.uniform(1.0, 3.5)
                )
                db.add(telemetry)
                
            elif device.type == DeviceType.SENSOR:
                # Occupancy sensor
                telemetry = TelemetryTS(
                    time=current_time,
                    device_id=device.id,
                    metric="occupancy",
                    value=1.0 if random.random() > 0.7 else 0.0
                )
                db.add(telemetry)
                
                # Temperature sensor
                temp_telemetry = TelemetryTS(
                    time=current_time,
                    device_id=device.id,
                    metric="temperature",
                    value=random.uniform(20.0, 26.0)
                )
                db.add(temp_telemetry)
        
        # Room energy rollups
        for room in rooms[:30]:  # Limit to first 30 rooms for demo
            energy = EnergyTS(
                time=current_time,
                room_id=room.id,
                kw=random.uniform(0.5, 5.0),
                kwh_rollup=random.uniform(0.1, 1.0)
            )
            db.add(energy)
        
        current_time += timedelta(minutes=5)  # 5-minute intervals
        
        # Commit in batches to avoid memory issues
        if (current_time - start_time).total_seconds() % 3600 == 0:  # Every hour
            await db.commit()
    
    await db.commit()
    print("✓ Telemetry and energy data created (7 days)")

async def seed_bookings(db: AsyncSession):
    """Create sample bookings"""
    
    # Get users and rooms
    users_result = await db.execute(select(User))
    users = list(users_result.scalars().all())
    
    rooms_result = await db.execute(select(Room).where(Room.name.like("%Conference%")))
    conference_rooms = list(rooms_result.scalars().all())
    
    # Create bookings for next 30 days
    start_date = datetime.utcnow().date()
    
    for day_offset in range(30):
        booking_date = start_date + timedelta(days=day_offset)
        
        # Skip weekends
        if booking_date.weekday() >= 5:
            continue
        
        # Create 3-5 bookings per day
        for _ in range(random.randint(3, 5)):
            room = random.choice(conference_rooms)
            user = random.choice(users)
            
            # Random time between 9 AM and 5 PM
            start_hour = random.randint(9, 16)
            duration = random.choice([1, 2, 3])  # 1-3 hours
            
            start_ts = datetime.combine(booking_date, datetime.min.time()) + timedelta(hours=start_hour)
            end_ts = start_ts + timedelta(hours=duration)
            
            booking = Booking(
                room_id=room.id,
                user_id=user.id,
                start_ts=start_ts,
                end_ts=end_ts,
                status=random.choice([BookingStatus.CONFIRMED, BookingStatus.COMPLETED]),
                purpose=random.choice([
                    "Team Meeting", "Client Presentation", "Project Review",
                    "Training Session", "Board Meeting", "Design Review"
                ]),
                attendees=random.randint(2, room.capacity)
            )
            db.add(booking)
    
    await db.commit()
    print("✓ Sample bookings created")

async def seed_policies_and_scenes(db: AsyncSession):
    """Create sample policies and scenes"""
    
    # Get a user for created_by
    user_result = await db.execute(select(User).where(User.role == UserRole.FACILITY_MANAGER))
    fm_user = user_result.scalar_one()
    
    # Scenes
    scenes_data = [
        {
            "id": "eco-mode",
            "name": "Eco Mode",
            "description": "Energy-saving configuration for unoccupied rooms",
            "payload": {
                "lights": {"power": False},
                "hvac": {"temperature": 18, "mode": "eco"},
                "plugs": {"power": False}
            }
        },
        {
            "id": "comfort-mode",
            "name": "Comfort Mode",
            "description": "Standard comfort settings for occupied rooms",
            "payload": {
                "lights": {"power": True, "brightness": 80},
                "hvac": {"temperature": 22, "mode": "auto"},
                "plugs": {"power": True}
            }
        },
        {
            "id": "presentation-mode",
            "name": "Presentation Mode",
            "description": "Optimized for presentations and meetings",
            "payload": {
                "lights": {"power": True, "brightness": 60},
                "projector": {"power": True},
                "hvac": {"temperature": 21, "mode": "quiet"}
            }
        },
        {
            "id": "after-hours",
            "name": "After Hours",
            "description": "Minimal energy usage for after-hours periods",
            "payload": {
                "lights": {"power": False},
                "hvac": {"temperature": 16, "mode": "eco"},
                "plugs": {"power": False},
                "projector": {"power": False}
            }
        }
    ]
    
    for scene_data in scenes_data:
        scene = Scene(**scene_data)
        db.add(scene)
    
    # Policies
    policies_data = [
        {
            "name": "Auto Lights Off",
            "scope": {"type": "campus"},
            "rule_dsl": "IF occupancy == 0 AND time_since_last_motion > 10_minutes THEN apply_scene('eco-mode')",
            "enabled": True,
            "created_by": fm_user.id
        },
        {
            "name": "After Hours Energy Saving",
            "scope": {"type": "campus"},
            "rule_dsl": "IF time > 18:00 OR time < 07:00 THEN apply_scene('after-hours')",
            "enabled": True,
            "created_by": fm_user.id
        },
        {
            "name": "Meeting Room Auto Setup",
            "scope": {"type": "room", "room_types": ["Conference Room"]},
            "rule_dsl": "IF booking_starts_in < 5_minutes THEN apply_scene('presentation-mode')",
            "enabled": True,
            "created_by": fm_user.id
        }
    ]
    
    for policy_data in policies_data:
        policy = Policy(**policy_data)
        db.add(policy)
    
    await db.commit()
    print("✓ Policies and scenes created")

async def seed_anomalies(db: AsyncSession):
    """Create sample anomalies"""
    
    # Get some devices and rooms
    devices_result = await db.execute(select(Device).limit(10))
    devices = list(devices_result.scalars().all())
    
    rooms_result = await db.execute(select(Room).limit(5))
    rooms = list(rooms_result.scalars().all())
    
    anomalies_data = [
        {
            "room_id": rooms[0].id,
            "device_id": devices[0].id,
            "metric": "power_kw",
            "baseline": 1.2,
            "observed": 1.8,
            "delta_pct": 50.0,
            "severity": AnomalySeverity.HIGH,
            "status": AnomalyStatus.OPEN,
            "explanation": "HVAC power consumption 50% above baseline during unoccupied hours"
        },
        {
            "room_id": rooms[1].id,
            "device_id": devices[1].id,
            "metric": "temperature",
            "baseline": 22.0,
            "observed": 28.5,
            "delta_pct": 29.5,
            "severity": AnomalySeverity.MEDIUM,
            "status": AnomalyStatus.ACKNOWLEDGED,
            "explanation": "Room temperature significantly above setpoint, possible HVAC malfunction"
        },
        {
            "room_id": rooms[2].id,
            "device_id": devices[2].id,
            "metric": "power_w",
            "baseline": 15.0,
            "observed": 0.0,
            "delta_pct": -100.0,
            "severity": AnomalySeverity.CRITICAL,
            "status": AnomalyStatus.OPEN,
            "explanation": "Light fixture completely offline, possible electrical issue"
        }
    ]
    
    for anomaly_data in anomalies_data:
        anomaly = Anomaly(**anomaly_data)
        db.add(anomaly)
    
    await db.commit()
    print("✓ Sample anomalies created")

async def seed_bills(db: AsyncSession):
    """Create sample billing data"""
    
    # Get buildings
    buildings_result = await db.execute(select(Building))
    buildings = list(buildings_result.scalars().all())
    
    # Create bills for last 12 months
    current_date = date.today()
    
    for month_offset in range(12):
        bill_date = current_date - timedelta(days=30 * month_offset)
        period_start = bill_date.replace(day=1)
        
        # Calculate period_end (last day of month)
        if period_start.month == 12:
            period_end = period_start.replace(year=period_start.year + 1, month=1, day=1) - timedelta(days=1)
        else:
            period_end = period_start.replace(month=period_start.month + 1, day=1) - timedelta(days=1)
        
        for building in buildings:
            # Simulate seasonal variation
            base_kwh = random.uniform(8000, 12000)
            seasonal_factor = 1.2 if bill_date.month in [6, 7, 8, 12, 1, 2] else 1.0
            energy_kwh = base_kwh * seasonal_factor
            
            bill = Bill(
                building_id=building.id,
                period_start=period_start,
                period_end=period_end,
                energy_kwh=energy_kwh,
                demand_kw=random.uniform(50, 80),
                tariff={
                    "energy_rate": 0.12,  # $/kWh
                    "demand_rate": 15.0,  # $/kW
                    "fixed_charge": 25.0  # $/month
                },
                cost_currency="USD",
                cost_total=Decimal(str(round(energy_kwh * 0.12 + 65 * 15.0 + 25.0, 2)))
            )
            db.add(bill)
    
    await db.commit()
    print("✓ Billing data created (12 months)")

async def main():
    """Main seeding function"""
    print("🌱 Starting database seeding...")
    
    # Create tables
    await create_tables()
    
    # Create session
    async with AsyncSessionLocal() as db:
        try:
            await seed_users(db)
            await seed_buildings(db)
            await seed_devices(db)
            await seed_assignments(db)
            await seed_telemetry_data(db)
            await seed_bookings(db)
            await seed_policies_and_scenes(db)
            await seed_anomalies(db)
            await seed_bills(db)
            
            print("\n🎉 Database seeding completed successfully!")
            print("\nDemo users created:")
            print("- CEO: ceo@demo.local / Pass123!")
            print("- Facility Manager: fm@demo.local / Pass123!")
            print("- Building Admin: admin@demo.local / Pass123!")
            print("- Receptionist: reception@demo.local / Pass123!")
            print("- Employee: emp@demo.local / Pass123!")
            print("- Auditor: auditor@demo.local / Pass123!")
            print("- Security: security@demo.local / Pass123!")
            
        except Exception as e:
            print(f"❌ Error during seeding: {e}")
            await db.rollback()
            raise

if __name__ == "__main__":
    asyncio.run(main())
