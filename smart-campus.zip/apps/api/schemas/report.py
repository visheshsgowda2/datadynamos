from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional, List, Dict, Any
from enum import Enum

from models.report import ReportType, ReportStatus
from models.billing import BillStatus

class ReportRequest(BaseModel):
    building_id: int
    report_type: ReportType
    title: str
    parameters: Optional[Dict[str, Any]] = None

class ReportResponse(BaseModel):
    id: int
    building_id: int
    report_type: ReportType
    title: str
    status: ReportStatus
    data: Optional[Dict[str, Any]] = None
    narrative: Optional[str] = None
    generated_by: int
    created_at: datetime
    completed_at: Optional[datetime] = None
    
    class Config:
        from_attributes = True
    
    @classmethod
    def from_orm(cls, report):
        return cls(
            id=report.id,
            building_id=report.building_id,
            report_type=report.report_type,
            title=report.title,
            status=report.status,
            data=report.data,
            narrative=report.narrative,
            generated_by=report.generated_by,
            created_at=report.created_at,
            completed_at=report.completed_at
        )

class BillResponse(BaseModel):
    id: int
    building_id: int
    period_start: datetime
    period_end: datetime
    total_consumption: float
    total_cost: float
    breakdown: Dict[str, Any]
    status: BillStatus
    ai_summary: Optional[str] = None
    generated_by: int
    generated_at: datetime
    
    class Config:
        from_attributes = True
    
    @classmethod
    def from_orm(cls, bill):
        return cls(
            id=bill.id,
            building_id=bill.building_id,
            period_start=bill.period_start,
            period_end=bill.period_end,
            total_consumption=bill.total_consumption,
            total_cost=bill.total_cost,
            breakdown=bill.breakdown,
            status=bill.status,
            ai_summary=bill.ai_summary,
            generated_by=bill.generated_by,
            generated_at=bill.generated_at
        )

class EnergyAnalyticsResponse(BaseModel):
    period_days: int
    total_consumption: float
    total_cost: float
    daily_average: float
    daily_trends: List[Dict[str, Any]]
    peak_hours: List[Dict[str, Any]]
    efficiency_metrics: Dict[str, Any]
    savings_opportunities: List[Dict[str, Any]]
    generated_at: str

class ComplianceReportResponse(BaseModel):
    id: int
    building_id: int
    building_name: str
    report_period: str
    compliance_score: float
    status: ReportStatus
    data: Dict[str, Any]
    narrative: Optional[str] = None
    generated_at: datetime
    
    class Config:
        from_attributes = True
    
    @classmethod
    def from_orm(cls, report):
        compliance_score = 0
        if report.data and 'compliance_summary' in report.data:
            compliance_score = report.data['compliance_summary'].get('overall_score', 0)
        
        return cls(
            id=report.id,
            building_id=report.building_id,
            building_name=report.data.get('building_name', f'Building {report.building_id}') if report.data else f'Building {report.building_id}',
            report_period=report.data.get('report_period', 'unknown') if report.data else 'unknown',
            compliance_score=compliance_score,
            status=report.status,
            data=report.data or {},
            narrative=report.narrative,
            generated_at=report.created_at
        )
