from pydantic import BaseModel, Field
from datetime import datetime
from typing import Optional, List
from enum import Enum

from models.booking import BookingStatus

class BookingCreate(BaseModel):
    room_id: int
    start_time: datetime
    end_time: datetime
    purpose: str = Field(..., min_length=1, max_length=500)
    attendees: Optional[int] = Field(default=1, ge=1, le=50)

class BookingUpdate(BaseModel):
    start_time: Optional[datetime] = None
    end_time: Optional[datetime] = None
    purpose: Optional[str] = Field(None, min_length=1, max_length=500)
    attendees: Optional[int] = Field(None, ge=1, le=50)

class BookingResponse(BaseModel):
    id: int
    room_id: int
    user_id: int
    start_time: datetime
    end_time: datetime
    purpose: str
    attendees: int
    status: BookingStatus
    check_in_code: str
    checked_in_at: Optional[datetime] = None
    auto_released_at: Optional[datetime] = None
    created_at: datetime
    updated_at: Optional[datetime] = None
    
    # Related data
    room_name: Optional[str] = None
    user_name: Optional[str] = None
    
    class Config:
        from_attributes = True
    
    @classmethod
    def from_orm(cls, booking):
        data = {
            "id": booking.id,
            "room_id": booking.room_id,
            "user_id": booking.user_id,
            "start_time": booking.start_time,
            "end_time": booking.end_time,
            "purpose": booking.purpose,
            "attendees": booking.attendees,
            "status": booking.status,
            "check_in_code": booking.check_in_code,
            "checked_in_at": booking.checked_in_at,
            "auto_released_at": booking.auto_released_at,
            "created_at": booking.created_at,
            "updated_at": booking.updated_at,
        }
        
        # Add related data if available
        if hasattr(booking, 'room') and booking.room:
            data["room_name"] = booking.room.name
        
        if hasattr(booking, 'user') and booking.user:
            data["user_name"] = booking.user.full_name
        
        return cls(**data)

class BookingListResponse(BaseModel):
    bookings: List[BookingResponse]
    total: int

class CheckInRequest(BaseModel):
    check_in_code: str = Field(..., min_length=8, max_length=8)

class CheckInResponse(BaseModel):
    success: bool
    message: str
    booking_id: int
    checked_in_at: datetime
