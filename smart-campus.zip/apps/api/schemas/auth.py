"""
Authentication schemas
"""

from typing import Optional
from pydantic import BaseModel, EmailStr, Field
from models.user import UserRole

class LoginRequest(BaseModel):
    email: EmailStr
    password: str = Field(..., min_length=8)

class LoginResponse(BaseModel):
    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int
    user: "UserResponse"

class RefreshTokenRequest(BaseModel):
    refresh_token: str

class UserResponse(BaseModel):
    id: str
    name: str
    email: str
    role: UserRole
    dept: Optional[str] = None
    status: str
    
    class Config:
        from_attributes = True

class ChangePasswordRequest(BaseModel):
    current_password: str
    new_password: str = Field(..., min_length=8)

# Update forward reference
LoginResponse.model_rebuild()
