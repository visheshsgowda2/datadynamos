import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from sqlalchemy import and_, func, text
from typing import Dict, Any, Optional, List
import logging
import json

from core.database import get_db
from models.building import Building
from models.room import Room
from models.telemetry import EnergyRollup, Telemetry
from models.booking import Booking, BookingStatus
from models.device import Device
from models.billing import Bill

logger = logging.getLogger(__name__)

class ReportService:
    def __init__(self):
        self.energy_rate_per_kwh = 0.12  # $0.12 per kWh
        self.carbon_factor = 0.4  # kg CO2 per kWh
    
    async def generate_energy_bill(
        self,
        building_id: int,
        start_date: datetime,
        end_date: datetime
    ) -> Dict[str, Any]:
        """Generate comprehensive energy bill for a building"""
        
        try:
            db = next(get_db())
            
            # Get energy consumption data
            energy_query = text("""
                SELECT 
                    r.id as room_id,
                    r.name as room_name,
                    r.floor,
                    SUM(er.total_consumption) as total_consumption,
                    SUM(er.hvac_consumption) as hvac_consumption,
                    SUM(er.lighting_consumption) as lighting_consumption,
                    SUM(er.equipment_consumption) as equipment_consumption
                FROM energy_rollups er
                JOIN rooms r ON er.room_id = r.id
                WHERE r.building_id = :building_id
                AND er.timestamp >= :start_date
                AND er.timestamp <= :end_date
                GROUP BY r.id, r.name, r.floor
                ORDER BY total_consumption DESC
            """)
            
            result = db.execute(energy_query, {
                "building_id": building_id,
                "start_date": start_date,
                "end_date": end_date
            })
            
            room_data = []
            total_consumption = 0
            total_hvac = 0
            total_lighting = 0
            total_equipment = 0
            
            for row in result.fetchall():
                consumption = float(row.total_consumption or 0)
                hvac = float(row.hvac_consumption or 0)
                lighting = float(row.lighting_consumption or 0)
                equipment = float(row.equipment_consumption or 0)
                
                room_data.append({
                    "room_id": row.room_id,
                    "room_name": row.room_name,
                    "floor": row.floor,
                    "total_consumption": consumption,
                    "hvac_consumption": hvac,
                    "lighting_consumption": lighting,
                    "equipment_consumption": equipment,
                    "cost": consumption * self.energy_rate_per_kwh,
                    "carbon_footprint": consumption * self.carbon_factor
                })
                
                total_consumption += consumption
                total_hvac += hvac
                total_lighting += lighting
                total_equipment += equipment
            
            # Calculate costs
            total_cost = total_consumption * self.energy_rate_per_kwh
            total_carbon = total_consumption * self.carbon_factor
            
            # Get building info
            building = db.query(Building).filter(Building.id == building_id).first()
            
            # Calculate period metrics
            period_days = (end_date - start_date).days
            daily_avg = total_consumption / period_days if period_days > 0 else 0
            
            # Get previous period for comparison
            prev_start = start_date - timedelta(days=period_days)
            prev_end = start_date
            
            prev_result = db.execute(text("""
                SELECT SUM(er.total_consumption) as prev_consumption
                FROM energy_rollups er
                JOIN rooms r ON er.room_id = r.id
                WHERE r.building_id = :building_id
                AND er.timestamp >= :prev_start
                AND er.timestamp <= :prev_end
            """), {
                "building_id": building_id,
                "prev_start": prev_start,
                "prev_end": prev_end
            })
            
            prev_consumption = float(prev_result.fetchone().prev_consumption or 0)
            consumption_change = ((total_consumption - prev_consumption) / prev_consumption * 100) if prev_consumption > 0 else 0
            
            return {
                "building_id": building_id,
                "building_name": building.name if building else f"Building {building_id}",
                "period_start": start_date.isoformat(),
                "period_end": end_date.isoformat(),
                "period_days": period_days,
                "total_consumption": total_consumption,
                "total_cost": total_cost,
                "total_carbon_footprint": total_carbon,
                "daily_average": daily_avg,
                "consumption_change_percent": consumption_change,
                "breakdown": {
                    "hvac": {
                        "consumption": total_hvac,
                        "percentage": (total_hvac / total_consumption * 100) if total_consumption > 0 else 0,
                        "cost": total_hvac * self.energy_rate_per_kwh
                    },
                    "lighting": {
                        "consumption": total_lighting,
                        "percentage": (total_lighting / total_consumption * 100) if total_consumption > 0 else 0,
                        "cost": total_lighting * self.energy_rate_per_kwh
                    },
                    "equipment": {
                        "consumption": total_equipment,
                        "percentage": (total_equipment / total_consumption * 100) if total_consumption > 0 else 0,
                        "cost": total_equipment * self.energy_rate_per_kwh
                    }
                },
                "room_breakdown": room_data,
                "rate_per_kwh": self.energy_rate_per_kwh,
                "carbon_factor": self.carbon_factor
            }
            
        except Exception as e:
            logger.error(f"Error generating energy bill: {str(e)}")
            raise
    
    async def get_energy_analytics(
        self,
        building_id: Optional[int] = None,
        room_id: Optional[int] = None,
        days_back: int = 30
    ) -> Dict[str, Any]:
        """Get comprehensive energy analytics"""
        
        try:
            db = next(get_db())
            end_date = datetime.utcnow()
            start_date = end_date - timedelta(days=days_back)
            
            # Base query
            base_query = """
                FROM energy_rollups er
                JOIN rooms r ON er.room_id = r.id
                WHERE er.timestamp >= :start_date
                AND er.timestamp <= :end_date
            """
            
            params = {"start_date": start_date, "end_date": end_date}
            
            if building_id:
                base_query += " AND r.building_id = :building_id"
                params["building_id"] = building_id
            
            if room_id:
                base_query += " AND er.room_id = :room_id"
                params["room_id"] = room_id
            
            # Total consumption
            total_query = text(f"SELECT SUM(er.total_consumption) as total {base_query}")
            total_result = db.execute(total_query, params)
            total_consumption = float(total_result.fetchone().total or 0)
            
            # Daily trends
            daily_query = text(f"""
                SELECT 
                    DATE(er.timestamp) as date,
                    SUM(er.total_consumption) as daily_consumption,
                    SUM(er.hvac_consumption) as daily_hvac,
                    SUM(er.lighting_consumption) as daily_lighting,
                    SUM(er.equipment_consumption) as daily_equipment
                {base_query}
                GROUP BY DATE(er.timestamp)
                ORDER BY date
            """)
            
            daily_result = db.execute(daily_query, params)
            daily_trends = []
            
            for row in daily_result.fetchall():
                daily_trends.append({
                    "date": row.date.isoformat(),
                    "total_consumption": float(row.daily_consumption or 0),
                    "hvac_consumption": float(row.daily_hvac or 0),
                    "lighting_consumption": float(row.daily_lighting or 0),
                    "equipment_consumption": float(row.daily_equipment or 0)
                })
            
            # Peak usage analysis
            peak_query = text(f"""
                SELECT 
                    EXTRACT(hour FROM er.timestamp) as hour,
                    AVG(er.total_consumption) as avg_consumption
                {base_query}
                GROUP BY EXTRACT(hour FROM er.timestamp)
                ORDER BY avg_consumption DESC
                LIMIT 5
            """)
            
            peak_result = db.execute(peak_query, params)
            peak_hours = []
            
            for row in peak_result.fetchall():
                peak_hours.append({
                    "hour": int(row.hour),
                    "avg_consumption": float(row.avg_consumption or 0)
                })
            
            # Efficiency metrics
            if room_id:
                # Room-specific efficiency
                room_query = text("""
                    SELECT 
                        r.area,
                        COUNT(DISTINCT b.id) as booking_count
                    FROM rooms r
                    LEFT JOIN bookings b ON r.id = b.room_id
                    AND b.start_time >= :start_date
                    AND b.start_time <= :end_date
                    AND b.status IN ('confirmed', 'checked_in', 'completed')
                    WHERE r.id = :room_id
                    GROUP BY r.area
                """)
                
                room_result = db.execute(room_query, params)
                room_data = room_result.fetchone()
                
                if room_data and room_data.area:
                    consumption_per_sqm = total_consumption / room_data.area
                    utilization_rate = room_data.booking_count / days_back if days_back > 0 else 0
                else:
                    consumption_per_sqm = 0
                    utilization_rate = 0
                
                efficiency_metrics = {
                    "consumption_per_sqm": consumption_per_sqm,
                    "utilization_rate": utilization_rate,
                    "efficiency_score": max(0, 100 - (consumption_per_sqm * 10))  # Simple efficiency score
                }
            else:
                efficiency_metrics = {}
            
            # Calculate savings opportunities
            savings_opportunities = await self._calculate_savings_opportunities(
                building_id, room_id, days_back
            )
            
            return {
                "period_days": days_back,
                "total_consumption": total_consumption,
                "total_cost": total_consumption * self.energy_rate_per_kwh,
                "daily_average": total_consumption / days_back if days_back > 0 else 0,
                "daily_trends": daily_trends,
                "peak_hours": peak_hours,
                "efficiency_metrics": efficiency_metrics,
                "savings_opportunities": savings_opportunities,
                "generated_at": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error getting energy analytics: {str(e)}")
            raise
    
    async def generate_compliance_data(
        self,
        building_id: int,
        report_period: str
    ) -> Dict[str, Any]:
        """Generate compliance report data"""
        
        try:
            db = next(get_db())
            
            # Calculate period dates
            end_date = datetime.utcnow()
            if report_period == "monthly":
                start_date = end_date - timedelta(days=30)
            elif report_period == "quarterly":
                start_date = end_date - timedelta(days=90)
            elif report_period == "annual":
                start_date = end_date - timedelta(days=365)
            else:
                raise ValueError("Invalid report period")
            
            # Energy consumption compliance
            energy_query = text("""
                SELECT 
                    SUM(er.total_consumption) as total_consumption,
                    AVG(er.total_consumption) as avg_consumption,
                    MAX(er.total_consumption) as peak_consumption
                FROM energy_rollups er
                JOIN rooms r ON er.room_id = r.id
                WHERE r.building_id = :building_id
                AND er.timestamp >= :start_date
                AND er.timestamp <= :end_date
            """)
            
            energy_result = db.execute(energy_query, {
                "building_id": building_id,
                "start_date": start_date,
                "end_date": end_date
            })
            
            energy_data = energy_result.fetchone()
            total_consumption = float(energy_data.total_consumption or 0)
            
            # Calculate carbon footprint
            carbon_footprint = total_consumption * self.carbon_factor
            
            # Get building info for compliance targets
            building = db.query(Building).filter(Building.id == building_id).first()
            building_area = building.total_area if building else 1000  # Default area
            
            # Compliance metrics
            energy_intensity = total_consumption / building_area  # kWh per sqm
            carbon_intensity = carbon_footprint / building_area   # kg CO2 per sqm
            
            # Industry benchmarks (example values)
            benchmarks = {
                "energy_intensity_target": 150,  # kWh/sqm/year
                "carbon_intensity_target": 60,   # kg CO2/sqm/year
                "energy_efficiency_target": 0.85  # 85% efficiency target
            }
            
            # Calculate compliance scores
            energy_compliance = min(100, (benchmarks["energy_intensity_target"] / energy_intensity) * 100) if energy_intensity > 0 else 100
            carbon_compliance = min(100, (benchmarks["carbon_intensity_target"] / carbon_intensity) * 100) if carbon_intensity > 0 else 100
            
            # Device efficiency analysis
            device_query = text("""
                SELECT 
                    d.device_type,
                    COUNT(*) as device_count,
                    AVG(t.value) as avg_efficiency
                FROM devices d
                JOIN telemetry t ON d.id = t.device_id
                JOIN rooms r ON d.room_id = r.id
                WHERE r.building_id = :building_id
                AND t.timestamp >= :start_date
                AND t.timestamp <= :end_date
                AND t.metric_type = 'efficiency'
                GROUP BY d.device_type
            """)
            
            device_result = db.execute(device_query, {
                "building_id": building_id,
                "start_date": start_date,
                "end_date": end_date
            })
            
            device_efficiency = []
            for row in device_result.fetchall():
                device_efficiency.append({
                    "device_type": row.device_type,
                    "device_count": row.device_count,
                    "avg_efficiency": float(row.avg_efficiency or 0),
                    "compliance_status": "compliant" if row.avg_efficiency >= 0.8 else "non_compliant"
                })
            
            # Sustainability metrics
            renewable_percentage = 25.0  # Mock data - would come from energy provider
            waste_reduction = 15.0       # Mock data - would come from waste management
            
            return {
                "building_id": building_id,
                "building_name": building.name if building else f"Building {building_id}",
                "report_period": report_period,
                "period_start": start_date.isoformat(),
                "period_end": end_date.isoformat(),
                "energy_metrics": {
                    "total_consumption": total_consumption,
                    "energy_intensity": energy_intensity,
                    "energy_compliance_score": energy_compliance,
                    "target_intensity": benchmarks["energy_intensity_target"]
                },
                "carbon_metrics": {
                    "total_carbon_footprint": carbon_footprint,
                    "carbon_intensity": carbon_intensity,
                    "carbon_compliance_score": carbon_compliance,
                    "target_intensity": benchmarks["carbon_intensity_target"]
                },
                "device_efficiency": device_efficiency,
                "sustainability_metrics": {
                    "renewable_energy_percentage": renewable_percentage,
                    "waste_reduction_percentage": waste_reduction,
                    "water_conservation_percentage": 12.0  # Mock data
                },
                "compliance_summary": {
                    "overall_score": (energy_compliance + carbon_compliance) / 2,
                    "status": "compliant" if (energy_compliance + carbon_compliance) / 2 >= 80 else "needs_improvement",
                    "recommendations": await self._generate_compliance_recommendations(
                        energy_compliance, carbon_compliance, device_efficiency
                    )
                }
            }
            
        except Exception as e:
            logger.error(f"Error generating compliance data: {str(e)}")
            raise
    
    async def _calculate_savings_opportunities(
        self,
        building_id: Optional[int],
        room_id: Optional[int],
        days_back: int
    ) -> List[Dict[str, Any]]:
        """Calculate potential energy savings opportunities"""
        
        opportunities = []
        
        try:
            db = next(get_db())
            
            # Opportunity 1: Unoccupied room consumption
            unoccupied_query = text("""
                SELECT 
                    r.id,
                    r.name,
                    AVG(er.total_consumption) as avg_consumption
                FROM energy_rollups er
                JOIN rooms r ON er.room_id = r.id
                LEFT JOIN bookings b ON r.id = b.room_id
                AND b.start_time <= er.timestamp
                AND b.end_time > er.timestamp
                AND b.status IN ('confirmed', 'checked_in')
                WHERE er.timestamp >= :start_date
                AND b.id IS NULL  -- No active booking
            """)
            
            if building_id:
                unoccupied_query = text(str(unoccupied_query) + " AND r.building_id = :building_id")
            
            unoccupied_query = text(str(unoccupied_query) + " GROUP BY r.id, r.name HAVING AVG(er.total_consumption) > 2.0")
            
            end_date = datetime.utcnow()
            start_date = end_date - timedelta(days=days_back)
            
            params = {"start_date": start_date}
            if building_id:
                params["building_id"] = building_id
            
            result = db.execute(unoccupied_query, params)
            
            for row in result.fetchall():
                potential_savings = row.avg_consumption * 0.7 * days_back * 24  # 70% reduction potential
                opportunities.append({
                    "type": "unoccupied_consumption",
                    "room_id": row.id,
                    "room_name": row.name,
                    "description": f"High energy consumption in unoccupied room: {row.name}",
                    "current_consumption": float(row.avg_consumption),
                    "potential_savings_kwh": potential_savings,
                    "potential_savings_cost": potential_savings * self.energy_rate_per_kwh,
                    "priority": "high" if row.avg_consumption > 5.0 else "medium"
                })
            
            # Opportunity 2: HVAC optimization
            hvac_query = text("""
                SELECT 
                    r.id,
                    r.name,
                    AVG(er.hvac_consumption) as avg_hvac,
                    AVG(er.total_consumption) as avg_total
                FROM energy_rollups er
                JOIN rooms r ON er.room_id = r.id
                WHERE er.timestamp >= :start_date
            """)
            
            if building_id:
                hvac_query = text(str(hvac_query) + " AND r.building_id = :building_id")
            
            hvac_query = text(str(hvac_query) + " GROUP BY r.id, r.name")
            
            hvac_result = db.execute(hvac_query, params)
            
            for row in hvac_result.fetchall():
                hvac_percentage = (row.avg_hvac / row.avg_total * 100) if row.avg_total > 0 else 0
                
                if hvac_percentage > 60:  # HVAC consuming more than 60% of total
                    potential_savings = row.avg_hvac * 0.2 * days_back * 24  # 20% reduction potential
                    opportunities.append({
                        "type": "hvac_optimization",
                        "room_id": row.id,
                        "room_name": row.name,
                        "description": f"HVAC optimization opportunity in {row.name} (currently {hvac_percentage:.1f}% of consumption)",
                        "current_consumption": float(row.avg_hvac),
                        "potential_savings_kwh": potential_savings,
                        "potential_savings_cost": potential_savings * self.energy_rate_per_kwh,
                        "priority": "medium"
                    })
            
        except Exception as e:
            logger.error(f"Error calculating savings opportunities: {str(e)}")
        
        return opportunities
    
    async def _generate_compliance_recommendations(
        self,
        energy_compliance: float,
        carbon_compliance: float,
        device_efficiency: List[Dict[str, Any]]
    ) -> List[str]:
        """Generate compliance improvement recommendations"""
        
        recommendations = []
        
        if energy_compliance < 80:
            recommendations.append("Implement energy-efficient lighting systems and occupancy sensors")
            recommendations.append("Optimize HVAC schedules based on occupancy patterns")
        
        if carbon_compliance < 80:
            recommendations.append("Consider renewable energy sources or carbon offset programs")
            recommendations.append("Upgrade to high-efficiency equipment and appliances")
        
        # Device-specific recommendations
        for device in device_efficiency:
            if device["compliance_status"] == "non_compliant":
                recommendations.append(f"Replace or upgrade {device['device_type']} devices for better efficiency")
        
        if not recommendations:
            recommendations.append("Maintain current excellent performance and consider advanced optimization strategies")
        
        return recommendations
    
    async def export_report(self, report, format: str) -> Dict[str, Any]:
        """Export report in specified format"""
        
        # This would integrate with a document generation service
        # For now, return mock export data
        
        filename = f"report_{report.id}_{datetime.utcnow().strftime('%Y%m%d_%H%M%S')}.{format}"
        
        return {
            "download_url": f"/api/downloads/{filename}",
            "filename": filename,
            "size_bytes": 1024 * 1024,  # Mock 1MB file
            "expires_at": (datetime.utcnow() + timedelta(hours=24)).isoformat()
        }
    
    async def get_dashboard_metrics(self, building_id: Optional[int] = None) -> Dict[str, Any]:
        """Get real-time metrics for dashboard"""
        
        try:
            db = next(get_db())
            now = datetime.utcnow()
            
            # Current hour consumption
            current_hour_start = now.replace(minute=0, second=0, microsecond=0)
            
            current_query = text("""
                SELECT 
                    SUM(er.total_consumption) as current_consumption,
                    COUNT(DISTINCT er.room_id) as active_rooms
                FROM energy_rollups er
                JOIN rooms r ON er.room_id = r.id
                WHERE er.timestamp >= :current_hour
            """)
            
            params = {"current_hour": current_hour_start}
            
            if building_id:
                current_query = text(str(current_query) + " AND r.building_id = :building_id")
                params["building_id"] = building_id
            
            current_result = db.execute(current_query, params)
            current_data = current_result.fetchone()
            
            # Today's total
            today_start = now.replace(hour=0, minute=0, second=0, microsecond=0)
            
            today_query = text("""
                SELECT SUM(er.total_consumption) as today_consumption
                FROM energy_rollups er
                JOIN rooms r ON er.room_id = r.id
                WHERE er.timestamp >= :today_start
            """)
            
            today_params = {"today_start": today_start}
            
            if building_id:
                today_query = text(str(today_query) + " AND r.building_id = :building_id")
                today_params["building_id"] = building_id
            
            today_result = db.execute(today_query, today_params)
            today_consumption = float(today_result.fetchone().today_consumption or 0)
            
            return {
                "current_consumption": float(current_data.current_consumption or 0),
                "active_rooms": current_data.active_rooms or 0,
                "today_consumption": today_consumption,
                "today_cost": today_consumption * self.energy_rate_per_kwh,
                "carbon_footprint_today": today_consumption * self.carbon_factor,
                "last_updated": now.isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error getting dashboard metrics: {str(e)}")
            raise
