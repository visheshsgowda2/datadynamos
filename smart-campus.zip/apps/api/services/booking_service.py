import asyncio
from datetime import datetime, timedelta
from sqlalchemy.orm import Session
from sqlalchemy import and_
import logging

from core.database import get_db
from models.booking import Booking, BookingStatus
from services.device_control import DeviceControlService

logger = logging.getLogger(__name__)

class BookingService:
    def __init__(self):
        self.device_service = DeviceControlService()
    
    async def schedule_auto_release_check(self, booking_id: int):
        """Schedule auto-release check for a booking (10 minutes after start time)"""
        
        try:
            # Get booking details
            db = next(get_db())
            booking = db.query(Booking).filter(Booking.id == booking_id).first()
            
            if not booking:
                logger.error(f"Booking {booking_id} not found for auto-release check")
                return
            
            # Calculate delay until auto-release check (10 minutes after start time)
            check_time = booking.start_time + timedelta(minutes=10)
            now = datetime.utcnow()
            
            if check_time <= now:
                # Booking start time has already passed, check immediately
                await self.check_and_auto_release(booking_id)
            else:
                # Schedule check for future
                delay_seconds = (check_time - now).total_seconds()
                logger.info(f"Scheduling auto-release check for booking {booking_id} in {delay_seconds} seconds")
                
                await asyncio.sleep(delay_seconds)
                await self.check_and_auto_release(booking_id)
                
        except Exception as e:
            logger.error(f"Error scheduling auto-release check for booking {booking_id}: {str(e)}")
    
    async def check_and_auto_release(self, booking_id: int):
        """Check if booking should be auto-released and release if necessary"""
        
        try:
            db = next(get_db())
            booking = db.query(Booking).filter(Booking.id == booking_id).first()
            
            if not booking:
                logger.error(f"Booking {booking_id} not found for auto-release")
                return
            
            # Only auto-release confirmed bookings (not checked-in ones)
            if booking.status != BookingStatus.CONFIRMED:
                logger.info(f"Booking {booking_id} status is {booking.status}, skipping auto-release")
                return
            
            # Check if 10 minutes have passed since start time without check-in
            now = datetime.utcnow()
            auto_release_time = booking.start_time + timedelta(minutes=10)
            
            if now >= auto_release_time:
                # Auto-release the booking
                booking.status = BookingStatus.AUTO_RELEASED
                booking.updated_at = now
                booking.auto_released_at = now
                
                db.commit()
                
                logger.info(f"Auto-released booking {booking_id} - no check-in within 10 minutes")
                
                # Trigger eco scene for the room
                await self.device_service.trigger_eco_scene(booking.room_id)
                
                # Send notification to user (if notification service exists)
                await self._send_auto_release_notification(booking)
                
            else:
                logger.info(f"Booking {booking_id} not yet eligible for auto-release")
                
        except Exception as e:
            logger.error(f"Error in auto-release check for booking {booking_id}: {str(e)}")
    
    async def _send_auto_release_notification(self, booking: Booking):
        """Send notification to user about auto-released booking"""
        
        try:
            # This would integrate with a notification service
            # For now, just log the notification
            logger.info(f"NOTIFICATION: Booking {booking.id} was auto-released due to no check-in")
            
            # In a real implementation, this would:
            # - Send email notification
            # - Send push notification
            # - Create in-app notification
            # - Log to audit trail
            
        except Exception as e:
            logger.error(f"Error sending auto-release notification: {str(e)}")
    
    async def run_periodic_cleanup(self):
        """Run periodic cleanup of expired bookings"""
        
        try:
            db = next(get_db())
            now = datetime.utcnow()
            
            # Find bookings that should be marked as completed
            expired_bookings = db.query(Booking).filter(
                and_(
                    Booking.status == BookingStatus.CHECKED_IN,
                    Booking.end_time <= now
                )
            ).all()
            
            for booking in expired_bookings:
                booking.status = BookingStatus.COMPLETED
                booking.updated_at = now
                
                # Trigger eco scene when booking ends
                await self.device_service.trigger_eco_scene(booking.room_id)
                
                logger.info(f"Marked booking {booking.id} as completed")
            
            if expired_bookings:
                db.commit()
                logger.info(f"Completed cleanup of {len(expired_bookings)} expired bookings")
                
        except Exception as e:
            logger.error(f"Error in periodic booking cleanup: {str(e)}")
    
    async def get_booking_analytics(self, building_id: int = None, days_back: int = 30):
        """Get booking analytics for reporting"""
        
        try:
            db = next(get_db())
            
            # Calculate date range
            end_date = datetime.utcnow()
            start_date = end_date - timedelta(days=days_back)
            
            # Base query
            query = db.query(Booking).filter(
                Booking.created_at >= start_date
            )
            
            if building_id:
                query = query.join(Booking.room).filter(Room.building_id == building_id)
            
            bookings = query.all()
            
            # Calculate metrics
            total_bookings = len(bookings)
            checked_in_bookings = len([b for b in bookings if b.status == BookingStatus.CHECKED_IN])
            auto_released_bookings = len([b for b in bookings if b.status == BookingStatus.AUTO_RELEASED])
            cancelled_bookings = len([b for b in bookings if b.status == BookingStatus.CANCELLED])
            
            check_in_rate = (checked_in_bookings / total_bookings * 100) if total_bookings > 0 else 0
            auto_release_rate = (auto_released_bookings / total_bookings * 100) if total_bookings > 0 else 0
            
            return {
                "period_days": days_back,
                "total_bookings": total_bookings,
                "checked_in_bookings": checked_in_bookings,
                "auto_released_bookings": auto_released_bookings,
                "cancelled_bookings": cancelled_bookings,
                "check_in_rate_percent": round(check_in_rate, 2),
                "auto_release_rate_percent": round(auto_release_rate, 2),
                "building_id": building_id
            }
            
        except Exception as e:
            logger.error(f"Error getting booking analytics: {str(e)}")
            raise
