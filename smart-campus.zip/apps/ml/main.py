from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
import asyncio
import logging
from contextlib import asynccontextmanager

from core.config import settings
from core.database import get_db_connection
from services.forecasting import ForecastingService
from services.anomaly_detection import AnomalyDetectionService
from services.optimization import OptimizationService
from services.genai import GenAIService
from schemas.ml import (
    ForecastRequest, ForecastResponse,
    AnomalyDetectionRequest, AnomalyDetectionResponse,
    OptimizationRequest, OptimizationResponse,
    GenAIRequest, GenAIResponse
)

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Global services
forecasting_service = None
anomaly_service = None
optimization_service = None
genai_service = None

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    global forecasting_service, anomaly_service, optimization_service, genai_service
    
    logger.info("Initializing ML services...")
    forecasting_service = ForecastingService()
    anomaly_service = AnomalyDetectionService()
    optimization_service = OptimizationService()
    genai_service = GenAIService()
    
    # Train initial models
    await forecasting_service.initialize()
    await anomaly_service.initialize()
    await optimization_service.initialize()
    
    logger.info("ML services initialized successfully")
    yield
    
    # Shutdown
    logger.info("Shutting down ML services...")

app = FastAPI(
    title="Smart Campus ML API",
    description="AI/ML services for energy forecasting, anomaly detection, and optimization",
    version="1.0.0",
    lifespan=lifespan
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/health")
async def health_check():
    return {"status": "healthy", "timestamp": datetime.utcnow()}

@app.post("/forecast/energy", response_model=ForecastResponse)
async def forecast_energy(request: ForecastRequest):
    """Generate energy consumption forecasts for buildings/rooms"""
    try:
        result = await forecasting_service.forecast_energy(
            building_id=request.building_id,
            room_id=request.room_id,
            forecast_hours=request.forecast_hours,
            include_confidence=request.include_confidence
        )
        return ForecastResponse(**result)
    except Exception as e:
        logger.error(f"Forecasting error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/forecast/load-peaks", response_model=ForecastResponse)
async def forecast_load_peaks(request: ForecastRequest):
    """Predict peak load times and magnitudes"""
    try:
        result = await forecasting_service.forecast_load_peaks(
            building_id=request.building_id,
            forecast_hours=request.forecast_hours
        )
        return ForecastResponse(**result)
    except Exception as e:
        logger.error(f"Load peak forecasting error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/anomaly/detect", response_model=AnomalyDetectionResponse)
async def detect_anomalies(request: AnomalyDetectionRequest):
    """Detect anomalies in device behavior and energy consumption"""
    try:
        result = await anomaly_service.detect_anomalies(
            building_id=request.building_id,
            room_id=request.room_id,
            device_id=request.device_id,
            hours_back=request.hours_back,
            sensitivity=request.sensitivity
        )
        return AnomalyDetectionResponse(**result)
    except Exception as e:
        logger.error(f"Anomaly detection error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/optimize/hvac", response_model=OptimizationResponse)
async def optimize_hvac(request: OptimizationRequest):
    """Generate optimal HVAC schedules based on occupancy and weather"""
    try:
        result = await optimization_service.optimize_hvac_schedule(
            building_id=request.building_id,
            room_id=request.room_id,
            optimization_hours=request.optimization_hours,
            target_comfort=request.target_comfort,
            energy_weight=request.energy_weight
        )
        return OptimizationResponse(**result)
    except Exception as e:
        logger.error(f"HVAC optimization error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/optimize/lighting", response_model=OptimizationResponse)
async def optimize_lighting(request: OptimizationRequest):
    """Generate optimal lighting schedules based on occupancy and daylight"""
    try:
        result = await optimization_service.optimize_lighting_schedule(
            building_id=request.building_id,
            room_id=request.room_id,
            optimization_hours=request.optimization_hours
        )
        return OptimizationResponse(**result)
    except Exception as e:
        logger.error(f"Lighting optimization error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/genai/bill-summary", response_model=GenAIResponse)
async def generate_bill_summary(request: GenAIRequest):
    """Generate 'what changed' summaries for energy bills"""
    try:
        result = await genai_service.generate_bill_summary(
            current_bill_id=request.current_bill_id,
            previous_bill_id=request.previous_bill_id,
            context=request.context
        )
        return GenAIResponse(**result)
    except Exception as e:
        logger.error(f"Bill summary generation error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/genai/compliance-report", response_model=GenAIResponse)
async def generate_compliance_report(request: GenAIRequest):
    """Generate compliance report narratives"""
    try:
        result = await genai_service.generate_compliance_report(
            building_id=request.building_id,
            report_period=request.report_period,
            compliance_data=request.compliance_data
        )
        return GenAIResponse(**result)
    except Exception as e:
        logger.error(f"Compliance report generation error: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8002)
