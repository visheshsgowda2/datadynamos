import openai
from datetime import datetime
from typing import Dict, Any, Optional
import logging
import json

from core.config import settings
from core.database import db_manager

logger = logging.getLogger(__name__)

class GenAIService:
    def __init__(self):
        if settings.OPENAI_API_KEY:
            openai.api_key = settings.OPENAI_API_KEY
        else:
            logger.warning("OpenAI API key not configured")
    
    async def generate_bill_summary(
        self,
        current_bill_id: int,
        previous_bill_id: int,
        context: Optional[Dict[str, Any]] = None
    ) -> Dict[str, Any]:
        """Generate 'what changed' summary for energy bills"""
        
        try:
            # Get bill data from database
            current_bill = await self._get_bill_data(current_bill_id)
            previous_bill = await self._get_bill_data(previous_bill_id)
            
            if not current_bill or not previous_bill:
                raise ValueError("Bill data not found")
            
            # Calculate changes
            consumption_change = current_bill["total_consumption"] - previous_bill["total_consumption"]
            cost_change = current_bill["total_cost"] - previous_bill["total_cost"]
            consumption_change_pct = (consumption_change / previous_bill["total_consumption"] * 100) if previous_bill["total_consumption"] > 0 else 0
            
            # Prepare prompt for AI
            prompt = f"""
            Generate a comprehensive "What Changed" summary for an energy bill comparison.
            
            Current Period: {current_bill['period_start']} to {current_bill['period_end']}
            Previous Period: {previous_bill['period_start']} to {previous_bill['period_end']}
            
            Key Changes:
            - Total Consumption: {current_bill['total_consumption']:.2f} kWh (vs {previous_bill['total_consumption']:.2f} kWh)
            - Change: {consumption_change:+.2f} kWh ({consumption_change_pct:+.1f}%)
            - Total Cost: ${current_bill['total_cost']:.2f} (vs ${previous_bill['total_cost']:.2f})
            - Cost Change: ${cost_change:+.2f}
            
            Current Breakdown:
            - HVAC: {current_bill['breakdown']['hvac']['consumption']:.2f} kWh ({current_bill['breakdown']['hvac']['percentage']:.1f}%)
            - Lighting: {current_bill['breakdown']['lighting']['consumption']:.2f} kWh ({current_bill['breakdown']['lighting']['percentage']:.1f}%)
            - Equipment: {current_bill['breakdown']['equipment']['consumption']:.2f} kWh ({current_bill['breakdown']['equipment']['percentage']:.1f}%)
            
            Previous Breakdown:
            - HVAC: {previous_bill['breakdown']['hvac']['consumption']:.2f} kWh ({previous_bill['breakdown']['hvac']['percentage']:.1f}%)
            - Lighting: {previous_bill['breakdown']['lighting']['consumption']:.2f} kWh ({previous_bill['breakdown']['lighting']['percentage']:.1f}%)
            - Equipment: {previous_bill['breakdown']['equipment']['consumption']:.2f} kWh ({previous_bill['breakdown']['equipment']['percentage']:.1f}%)
            
            Please provide:
            1. Executive Summary (2-3 sentences)
            2. Key Changes Analysis (what drove the changes)
            3. Category-specific insights (HVAC, Lighting, Equipment)
            4. Recommendations for next period
            5. Notable trends or patterns
            
            Write in a professional, analytical tone suitable for facility managers and executives.
            """
            
            if not settings.OPENAI_API_KEY:
                # Return mock summary if no API key
                return self._generate_mock_bill_summary(consumption_change_pct, cost_change)
            
            # Generate AI summary
            response = await openai.ChatCompletion.acreate(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are an expert energy analyst providing insights on building energy consumption patterns."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=1000,
                temperature=0.3
            )
            
            generated_text = response.choices[0].message.content
            
            # Extract key insights
            key_insights = self._extract_key_insights(generated_text, consumption_change_pct, cost_change)
            
            return {
                "generated_text": generated_text,
                "summary_type": "bill_comparison",
                "generated_at": datetime.utcnow().isoformat(),
                "word_count": len(generated_text.split()),
                "key_insights": key_insights,
                "consumption_change_percent": consumption_change_pct,
                "cost_change": cost_change
            }
            
        except Exception as e:
            logger.error(f"Error generating bill summary: {str(e)}")
            # Return fallback summary
            return self._generate_fallback_bill_summary(current_bill_id, previous_bill_id)
    
    async def generate_compliance_report(
        self,
        building_id: int,
        report_period: str,
        compliance_data: Dict[str, Any],
        report_id: Optional[int] = None
    ) -> Dict[str, Any]:
        """Generate compliance report narrative"""
        
        try:
            # Prepare prompt for AI
            prompt = f"""
            Generate a comprehensive compliance report narrative for a smart building.
            
            Building: {compliance_data['building_name']}
            Report Period: {report_period} ({compliance_data['period_start']} to {compliance_data['period_end']})
            
            Energy Performance:
            - Total Consumption: {compliance_data['energy_metrics']['total_consumption']:.2f} kWh
            - Energy Intensity: {compliance_data['energy_metrics']['energy_intensity']:.2f} kWh/sqm
            - Compliance Score: {compliance_data['energy_metrics']['energy_compliance_score']:.1f}%
            - Target: {compliance_data['energy_metrics']['target_intensity']:.2f} kWh/sqm
            
            Carbon Footprint:
            - Total Carbon Footprint: {compliance_data['carbon_metrics']['total_carbon_footprint']:.2f} kg CO2
            - Carbon Intensity: {compliance_data['carbon_metrics']['carbon_intensity']:.2f} kg CO2/sqm
            - Compliance Score: {compliance_data['carbon_metrics']['carbon_compliance_score']:.1f}%
            - Target: {compliance_data['carbon_metrics']['target_intensity']:.2f} kg CO2/sqm
            
            Sustainability Metrics:
            - Renewable Energy: {compliance_data['sustainability_metrics']['renewable_energy_percentage']:.1f}%
            - Waste Reduction: {compliance_data['sustainability_metrics']['waste_reduction_percentage']:.1f}%
            - Water Conservation: {compliance_data['sustainability_metrics']['water_conservation_percentage']:.1f}%
            
            Overall Compliance Score: {compliance_data['compliance_summary']['overall_score']:.1f}%
            Status: {compliance_data['compliance_summary']['status']}
            
            Please provide:
            1. Executive Summary
            2. Performance Analysis (energy, carbon, sustainability)
            3. Compliance Assessment
            4. Areas of Excellence
            5. Improvement Opportunities
            6. Regulatory Compliance Status
            7. Recommendations for Next Period
            
            Write in a formal, professional tone suitable for regulatory submissions and executive reporting.
            """
            
            if not settings.OPENAI_API_KEY:
                # Return mock report if no API key
                return self._generate_mock_compliance_report(compliance_data)
            
            # Generate AI narrative
            response = await openai.ChatCompletion.acreate(
                model="gpt-4",
                messages=[
                    {"role": "system", "content": "You are an expert sustainability and compliance analyst specializing in building energy performance and environmental regulations."},
                    {"role": "user", "content": prompt}
                ],
                max_tokens=1500,
                temperature=0.2
            )
            
            generated_text = response.choices[0].message.content
            
            # Extract key insights
            key_insights = self._extract_compliance_insights(generated_text, compliance_data)
            
            # Update report in database if report_id provided
            if report_id:
                await self._update_report_with_narrative(report_id, generated_text)
            
            return {
                "generated_text": generated_text,
                "summary_type": "compliance_report",
                "generated_at": datetime.utcnow().isoformat(),
                "word_count": len(generated_text.split()),
                "key_insights": key_insights,
                "compliance_score": compliance_data['compliance_summary']['overall_score'],
                "report_period": report_period
            }
            
        except Exception as e:
            logger.error(f"Error generating compliance report: {str(e)}")
            # Return fallback report
            return self._generate_fallback_compliance_report(building_id, report_period)
    
    async def _get_bill_data(self, bill_id: int) -> Optional[Dict[str, Any]]:
        """Get bill data from database"""
        
        try:
            # This would query the actual database
            # For now, return mock data structure
            return {
                "id": bill_id,
                "total_consumption": 1250.5,
                "total_cost": 150.06,
                "period_start": "2024-01-01",
                "period_end": "2024-01-31",
                "breakdown": {
                    "hvac": {"consumption": 750.3, "percentage": 60.0},
                    "lighting": {"consumption": 300.1, "percentage": 24.0},
                    "equipment": {"consumption": 200.1, "percentage": 16.0}
                }
            }
            
        except Exception as e:
            logger.error(f"Error getting bill data: {str(e)}")
            return None
    
    def _extract_key_insights(self, text: str, consumption_change_pct: float, cost_change: float) -> List[str]:
        """Extract key insights from generated text"""
        
        insights = []
        
        if abs(consumption_change_pct) > 10:
            direction = "increased" if consumption_change_pct > 0 else "decreased"
            insights.append(f"Energy consumption {direction} by {abs(consumption_change_pct):.1f}%")
        
        if abs(cost_change) > 20:
            direction = "increased" if cost_change > 0 else "decreased"
            insights.append(f"Energy costs {direction} by ${abs(cost_change):.2f}")
        
        # Extract insights from AI text (simplified)
        if "HVAC" in text and ("increase" in text.lower() or "decrease" in text.lower()):
            insights.append("HVAC consumption patterns changed significantly")
        
        if "efficiency" in text.lower():
            insights.append("Energy efficiency opportunities identified")
        
        return insights[:5]  # Limit to 5 key insights
    
    def _extract_compliance_insights(self, text: str, compliance_data: Dict[str, Any]) -> List[str]:
        """Extract key insights from compliance report"""
        
        insights = []
        
        overall_score = compliance_data['compliance_summary']['overall_score']
        
        if overall_score >= 90:
            insights.append("Excellent compliance performance across all metrics")
        elif overall_score >= 80:
            insights.append("Good compliance with minor improvement opportunities")
        else:
            insights.append("Compliance improvements needed in key areas")
        
        # Energy compliance
        energy_score = compliance_data['energy_metrics']['energy_compliance_score']
        if energy_score < 80:
            insights.append("Energy intensity exceeds recommended targets")
        
        # Carbon compliance
        carbon_score = compliance_data['carbon_metrics']['carbon_compliance_score']
        if carbon_score < 80:
            insights.append("Carbon footprint reduction strategies recommended")
        
        # Sustainability
        renewable_pct = compliance_data['sustainability_metrics']['renewable_energy_percentage']
        if renewable_pct > 30:
            insights.append("Strong renewable energy adoption")
        
        return insights[:5]
    
    def _generate_mock_bill_summary(self, consumption_change_pct: float, cost_change: float) -> Dict[str, Any]:
        """Generate mock bill summary when AI is not available"""
        
        direction = "increased" if consumption_change_pct > 0 else "decreased"
        
        mock_text = f"""
        Executive Summary:
        Energy consumption {direction} by {abs(consumption_change_pct):.1f}% compared to the previous period, resulting in a cost change of ${cost_change:+.2f}. This change is primarily attributed to seasonal variations and occupancy patterns.
        
        Key Changes Analysis:
        The primary driver of consumption change was HVAC usage, which typically accounts for 60% of total building energy consumption. Weather conditions and building occupancy levels significantly influenced this period's performance.
        
        Recommendations:
        - Monitor HVAC efficiency and consider schedule optimization
        - Implement occupancy-based lighting controls
        - Review equipment usage patterns for potential savings
        """
        
        return {
            "generated_text": mock_text,
            "summary_type": "bill_comparison",
            "generated_at": datetime.utcnow().isoformat(),
            "word_count": len(mock_text.split()),
            "key_insights": [f"Consumption {direction} by {abs(consumption_change_pct):.1f}%"],
            "consumption_change_percent": consumption_change_pct,
            "cost_change": cost_change
        }
    
    def _generate_mock_compliance_report(self, compliance_data: Dict[str, Any]) -> Dict[str, Any]:
        """Generate mock compliance report when AI is not available"""
        
        overall_score = compliance_data['compliance_summary']['overall_score']
        status = "compliant" if overall_score >= 80 else "needs improvement"
        
        mock_text = f"""
        Executive Summary:
        {compliance_data['building_name']} achieved an overall compliance score of {overall_score:.1f}% for the {compliance_data.get('report_period', 'reporting')} period. The building is currently {status} with regulatory requirements.
        
        Performance Analysis:
        Energy performance shows {compliance_data['energy_metrics']['energy_compliance_score']:.1f}% compliance with intensity targets. Carbon footprint management achieved {compliance_data['carbon_metrics']['carbon_compliance_score']:.1f}% compliance with emission reduction goals.
        
        Sustainability Initiatives:
        The building maintains {compliance_data['sustainability_metrics']['renewable_energy_percentage']:.1f}% renewable energy usage and has achieved {compliance_data['sustainability_metrics']['waste_reduction_percentage']:.1f}% waste reduction.
        
        Recommendations:
        Continue current performance management practices and consider additional efficiency improvements to maintain compliance standards.
        """
        
        return {
            "generated_text": mock_text,
            "summary_type": "compliance_report",
            "generated_at": datetime.utcnow().isoformat(),
            "word_count": len(mock_text.split()),
            "key_insights": [f"Overall compliance: {overall_score:.1f}%"],
            "compliance_score": overall_score
        }
    
    def _generate_fallback_bill_summary(self, current_bill_id: int, previous_bill_id: int) -> Dict[str, Any]:
        """Generate fallback summary when AI generation fails"""
        
        return {
            "generated_text": "Bill comparison summary generation temporarily unavailable. Please review the detailed bill data for consumption and cost analysis.",
            "summary_type": "bill_comparison",
            "generated_at": datetime.utcnow().isoformat(),
            "word_count": 16,
            "key_insights": ["Detailed analysis available in bill data"],
            "error": "AI generation unavailable"
        }
    
    def _generate_fallback_compliance_report(self, building_id: int, report_period: str) -> Dict[str, Any]:
        """Generate fallback compliance report when AI generation fails"""
        
        return {
            "generated_text": "Compliance report narrative generation temporarily unavailable. Please review the detailed compliance metrics and data for assessment.",
            "summary_type": "compliance_report",
            "generated_at": datetime.utcnow().isoformat(),
            "word_count": 17,
            "key_insights": ["Detailed compliance data available"],
            "error": "AI generation unavailable"
        }
    
    async def _update_report_with_narrative(self, report_id: int, narrative: str):
        """Update report record with generated narrative"""
        
        try:
            # This would update the report in the database
            # Implementation depends on database setup
            logger.info(f"Updated report {report_id} with AI-generated narrative")
            
        except Exception as e:
            logger.error(f"Error updating report with narrative: {str(e)}")
