import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List
from prophet import Prophet
import logging
from sklearn.preprocessing import StandardScaler
from sklearn.ensemble import RandomForestRegressor
import joblib
import os

from core.database import db_manager

logger = logging.getLogger(__name__)

class ForecastingService:
    def __init__(self):
        self.energy_models = {}  # room_id -> Prophet model
        self.load_models = {}    # building_id -> RandomForest model
        self.scalers = {}
        self.model_dir = "models/forecasting"
        os.makedirs(self.model_dir, exist_ok=True)
    
    async def initialize(self):
        """Initialize and train forecasting models"""
        logger.info("Initializing forecasting service...")
        
        # Load existing models or train new ones
        await self._load_or_train_models()
        
        logger.info("Forecasting service initialized")
    
    async def _load_or_train_models(self):
        """Load existing models or train new ones from historical data"""
        try:
            # Get historical energy data for training
            energy_data = await db_manager.fetch_energy_rollups(hours_back=720)  # 30 days
            
            if len(energy_data) > 100:  # Minimum data for training
                await self._train_energy_models(energy_data)
                await self._train_load_models(energy_data)
            else:
                logger.warning("Insufficient historical data for model training")
                
        except Exception as e:
            logger.error(f"Error loading/training models: {str(e)}")
    
    async def _train_energy_models(self, data: pd.DataFrame):
        """Train Prophet models for energy forecasting per room"""
        
        for room_id in data['room_id'].unique():
            try:
                room_data = data[data['room_id'] == room_id].copy()
                
                if len(room_data) < 50:  # Minimum data points
                    continue
                
                # Prepare data for Prophet
                prophet_data = pd.DataFrame({
                    'ds': pd.to_datetime(room_data['timestamp']),
                    'y': room_data['total_consumption']
                })
                
                # Create and train Prophet model
                model = Prophet(
                    daily_seasonality=True,
                    weekly_seasonality=True,
                    yearly_seasonality=False,
                    changepoint_prior_scale=0.05
                )
                
                model.fit(prophet_data)
                self.energy_models[room_id] = model
                
                # Save model
                model_path = f"{self.model_dir}/energy_room_{room_id}.pkl"
                joblib.dump(model, model_path)
                
                logger.info(f"Trained energy model for room {room_id}")
                
            except Exception as e:
                logger.error(f"Error training energy model for room {room_id}: {str(e)}")
    
    async def _train_load_models(self, data: pd.DataFrame):
        """Train RandomForest models for load peak prediction per building"""
        
        for building_id in data['building_id'].unique():
            try:
                building_data = data[data['building_id'] == building_id].copy()
                
                if len(building_data) < 100:
                    continue
                
                # Aggregate by building and hour
                building_data['hour'] = pd.to_datetime(building_data['timestamp']).dt.hour
                building_data['day_of_week'] = pd.to_datetime(building_data['timestamp']).dt.dayofweek
                
                hourly_data = building_data.groupby(['timestamp', 'hour', 'day_of_week']).agg({
                    'total_consumption': 'sum'
                }).reset_index()
                
                # Create features
                features = ['hour', 'day_of_week']
                X = hourly_data[features]
                y = hourly_data['total_consumption']
                
                # Scale features
                scaler = StandardScaler()
                X_scaled = scaler.fit_transform(X)
                
                # Train model
                model = RandomForestRegressor(n_estimators=100, random_state=42)
                model.fit(X_scaled, y)
                
                self.load_models[building_id] = model
                self.scalers[building_id] = scaler
                
                # Save models
                model_path = f"{self.model_dir}/load_building_{building_id}.pkl"
                scaler_path = f"{self.model_dir}/scaler_building_{building_id}.pkl"
                joblib.dump(model, model_path)
                joblib.dump(scaler, scaler_path)
                
                logger.info(f"Trained load model for building {building_id}")
                
            except Exception as e:
                logger.error(f"Error training load model for building {building_id}: {str(e)}")
    
    async def forecast_energy(
        self,
        building_id: Optional[int] = None,
        room_id: Optional[int] = None,
        forecast_hours: int = 24,
        include_confidence: bool = True
    ) -> Dict[str, Any]:
        """Generate energy consumption forecasts"""
        
        try:
            forecasts = []
            
            if room_id and room_id in self.energy_models:
                # Single room forecast
                forecast = await self._forecast_room_energy(room_id, forecast_hours, include_confidence)
                forecasts.append(forecast)
                
            elif building_id:
                # All rooms in building
                energy_data = await db_manager.fetch_energy_rollups(
                    building_id=building_id, 
                    hours_back=24
                )
                
                room_ids = energy_data['room_id'].unique()
                
                for rid in room_ids:
                    if rid in self.energy_models:
                        forecast = await self._forecast_room_energy(rid, forecast_hours, include_confidence)
                        forecasts.append(forecast)
            
            return {
                "forecasts": forecasts,
                "forecast_horizon_hours": forecast_hours,
                "generated_at": datetime.utcnow().isoformat(),
                "model_type": "prophet"
            }
            
        except Exception as e:
            logger.error(f"Error generating energy forecast: {str(e)}")
            raise
    
    async def _forecast_room_energy(
        self, 
        room_id: int, 
        forecast_hours: int, 
        include_confidence: bool
    ) -> Dict[str, Any]:
        """Generate forecast for a specific room"""
        
        model = self.energy_models[room_id]
        
        # Create future dataframe
        future = model.make_future_dataframe(periods=forecast_hours, freq='H')
        
        # Generate forecast
        forecast = model.predict(future)
        
        # Get only future predictions
        future_forecast = forecast.tail(forecast_hours)
        
        result = {
            "room_id": room_id,
            "timestamps": future_forecast['ds'].dt.strftime('%Y-%m-%d %H:%M:%S').tolist(),
            "predicted_consumption": future_forecast['yhat'].tolist(),
        }
        
        if include_confidence:
            result.update({
                "lower_bound": future_forecast['yhat_lower'].tolist(),
                "upper_bound": future_forecast['yhat_upper'].tolist(),
            })
        
        return result
    
    async def forecast_load_peaks(
        self,
        building_id: int,
        forecast_hours: int = 24
    ) -> Dict[str, Any]:
        """Predict peak load times and magnitudes"""
        
        try:
            if building_id not in self.load_models:
                raise ValueError(f"No load model available for building {building_id}")
            
            model = self.load_models[building_id]
            scaler = self.scalers[building_id]
            
            # Generate future time points
            now = datetime.utcnow()
            future_times = [now + timedelta(hours=i) for i in range(forecast_hours)]
            
            # Create features for prediction
            features = []
            for dt in future_times:
                features.append([dt.hour, dt.weekday()])
            
            features_array = np.array(features)
            features_scaled = scaler.transform(features_array)
            
            # Predict loads
            predicted_loads = model.predict(features_scaled)
            
            # Find peaks (values above 80th percentile)
            peak_threshold = np.percentile(predicted_loads, 80)
            peak_indices = np.where(predicted_loads >= peak_threshold)[0]
            
            peaks = []
            for idx in peak_indices:
                peaks.append({
                    "timestamp": future_times[idx].isoformat(),
                    "predicted_load": float(predicted_loads[idx]),
                    "peak_magnitude": float(predicted_loads[idx] / np.mean(predicted_loads))
                })
            
            return {
                "building_id": building_id,
                "forecast_horizon_hours": forecast_hours,
                "predicted_loads": predicted_loads.tolist(),
                "timestamps": [dt.isoformat() for dt in future_times],
                "peaks": peaks,
                "peak_threshold": float(peak_threshold),
                "generated_at": datetime.utcnow().isoformat()
            }
            
        except Exception as e:
            logger.error(f"Error forecasting load peaks: {str(e)}")
            raise
