import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, List
from sklearn.ensemble import IsolationForest
from sklearn.preprocessing import StandardScaler
import logging
import joblib
import os

from core.database import db_manager

logger = logging.getLogger(__name__)

class AnomalyDetectionService:
    def __init__(self):
        self.models = {}  # device_id -> IsolationForest model
        self.scalers = {}  # device_id -> StandardScaler
        self.model_dir = "models/anomaly"
        os.makedirs(self.model_dir, exist_ok=True)
        
        # Anomaly types and their detection logic
        self.anomaly_types = {
            'energy_spike': self._detect_energy_spike,
            'temperature_anomaly': self._detect_temperature_anomaly,
            'humidity_anomaly': self._detect_humidity_anomaly,
            'occupancy_mismatch': self._detect_occupancy_mismatch,
            'device_malfunction': self._detect_device_malfunction,
            'water_leak': self._detect_water_leak
        }
    
    async def initialize(self):
        """Initialize anomaly detection models"""
        logger.info("Initializing anomaly detection service...")
        
        await self._train_anomaly_models()
        
        logger.info("Anomaly detection service initialized")
    
    async def _train_anomaly_models(self):
        """Train Isolation Forest models for each device type"""
        
        try:
            # Get historical telemetry data
            telemetry_data = await db_manager.fetch_telemetry_data(hours_back=720)  # 30 days
            
            if len(telemetry_data) < 100:
                logger.warning("Insufficient data for anomaly model training")
                return
            
            # Group by device and train models
            for device_id in telemetry_data['device_id'].unique():
                device_data = telemetry_data[telemetry_data['device_id'] == device_id]
                
                if len(device_data) < 50:  # Minimum data points
                    continue
                
                await self._train_device_model(device_id, device_data)
                
        except Exception as e:
            logger.error(f"Error training anomaly models: {str(e)}")
    
    async def _train_device_model(self, device_id: int, data: pd.DataFrame):
        """Train anomaly detection model for a specific device"""
        
        try:
            # Prepare features based on device type
            device_type = data['device_type'].iloc[0]
            features = self._extract_features(data, device_type)
            
            if len(features) < 10:
                return
            
            # Scale features
            scaler = StandardScaler()
            features_scaled = scaler.fit_transform(features)
            
            # Train Isolation Forest
            model = IsolationForest(
                contamination=0.1,  # Expect 10% anomalies
                random_state=42,
                n_estimators=100
            )
            model.fit(features_scaled)
            
            # Store models
            self.models[device_id] = model
            self.scalers[device_id] = scaler
            
            # Save to disk
            model_path = f"{self.model_dir}/anomaly_device_{device_id}.pkl"
            scaler_path = f"{self.model_dir}/scaler_device_{device_id}.pkl"
            joblib.dump(model, model_path)
            joblib.dump(scaler, scaler_path)
            
            logger.info(f"Trained anomaly model for device {device_id} ({device_type})")
            
        except Exception as e:
            logger.error(f"Error training model for device {device_id}: {str(e)}")
    
    def _extract_features(self, data: pd.DataFrame, device_type: str) -> np.ndarray:
        """Extract relevant features based on device type"""
        
        # Pivot data to get metrics as columns
        pivot_data = data.pivot_table(
            index='timestamp', 
            columns='metric_type', 
            values='value', 
            aggfunc='mean'
        ).fillna(0)
        
        if len(pivot_data) == 0:
            return np.array([])
        
        # Add time-based features
        pivot_data['hour'] = pd.to_datetime(pivot_data.index).hour
        pivot_data['day_of_week'] = pd.to_datetime(pivot_data.index).dayofweek
        
        # Device-specific feature engineering
        if device_type == 'hvac':
            # Add temperature difference, energy efficiency metrics
            if 'temperature' in pivot_data.columns and 'energy_consumption' in pivot_data.columns:
                pivot_data['temp_energy_ratio'] = pivot_data['temperature'] / (pivot_data['energy_consumption'] + 1)
        
        elif device_type == 'lighting':
            # Add brightness vs energy efficiency
            if 'brightness' in pivot_data.columns and 'energy_consumption' in pivot_data.columns:
                pivot_data['brightness_efficiency'] = pivot_data['brightness'] / (pivot_data['energy_consumption'] + 1)
        
        return pivot_data.values
    
    async def detect_anomalies(
        self,
        building_id: Optional[int] = None,
        room_id: Optional[int] = None,
        device_id: Optional[int] = None,
        hours_back: int = 24,
        sensitivity: float = 0.1
    ) -> Dict[str, Any]:
        """Detect anomalies in recent telemetry data"""
        
        try:
            # Get recent telemetry data
            telemetry_data = await db_manager.fetch_telemetry_data(
                building_id=building_id,
                room_id=room_id,
                device_id=device_id,
                hours_back=hours_back
            )
            
            if len(telemetry_data) == 0:
                return {
                    "anomalies": [],
                    "total_anomalies": 0,
                    "analysis_period_hours": hours_back,
                    "generated_at": datetime.utcnow().isoformat()
                }
            
            anomalies = []
            
            # Run different anomaly detection methods
            for anomaly_type, detector in self.anomaly_types.items():
                type_anomalies = await detector(telemetry_data, sensitivity)
                anomalies.extend(type_anomalies)
            
            # Run ML-based detection for devices with trained models
            ml_anomalies = await self._detect_ml_anomalies(telemetry_data, sensitivity)
            anomalies.extend(ml_anomalies)
            
            # Sort by severity and timestamp
            anomalies.sort(key=lambda x: (x['severity'], x['timestamp']), reverse=True)
            
            return {
                "anomalies": anomalies,
                "total_anomalies": len(anomalies),
                "analysis_period_hours": hours_back,
                "generated_at": datetime.utcnow().isoformat(),
                "sensitivity": sensitivity
            }
            
        except Exception as e:
            logger.error(f"Error detecting anomalies: {str(e)}")
            raise
    
    async def _detect_ml_anomalies(self, data: pd.DataFrame, sensitivity: float) -> List[Dict[str, Any]]:
        """Use trained ML models to detect anomalies"""
        
        anomalies = []
        
        for device_id in data['device_id'].unique():
            if device_id not in self.models:
                continue
            
            device_data = data[data['device_id'] == device_id]
            device_type = device_data['device_type'].iloc[0]
            
            # Extract features
            features = self._extract_features(device_data, device_type)
            
            if len(features) == 0:
                continue
            
            # Scale features
            scaler = self.scalers[device_id]
            features_scaled = scaler.transform(features)
            
            # Predict anomalies
            model = self.models[device_id]
            anomaly_scores = model.decision_function(features_scaled)
            predictions = model.predict(features_scaled)
            
            # Find anomalous points
            anomaly_indices = np.where(predictions == -1)[0]
            
            for idx in anomaly_indices:
                timestamp = device_data.iloc[idx]['timestamp']
                score = anomaly_scores[idx]
                
                # Calculate severity based on score
                severity = "high" if score < -0.5 else "medium" if score < -0.2 else "low"
                
                anomalies.append({
                    "type": "ml_detected_anomaly",
                    "device_id": device_id,
                    "device_type": device_type,
                    "room_id": device_data.iloc[idx]['room_id'],
                    "building_id": device_data.iloc[idx]['building_id'],
                    "timestamp": timestamp.isoformat(),
                    "severity": severity,
                    "anomaly_score": float(score),
                    "description": f"ML model detected anomalous behavior in {device_type}",
                    "recommended_action": self._get_recommended_action(device_type, "ml_anomaly")
                })
        
        return anomalies
    
    async def _detect_energy_spike(self, data: pd.DataFrame, sensitivity: float) -> List[Dict[str, Any]]:
        """Detect unusual energy consumption spikes"""
        
        anomalies = []
        energy_data = data[data['metric_type'] == 'energy_consumption']
        
        for device_id in energy_data['device_id'].unique():
            device_energy = energy_data[energy_data['device_id'] == device_id]
            
            if len(device_energy) < 10:
                continue
            
            values = device_energy['value'].values
            mean_consumption = np.mean(values)
            std_consumption = np.std(values)
            
            # Detect spikes (values > mean + 3*std)
            threshold = mean_consumption + (3 - sensitivity) * std_consumption
            spike_indices = np.where(values > threshold)[0]
            
            for idx in spike_indices:
                row = device_energy.iloc[idx]
                spike_magnitude = (row['value'] - mean_consumption) / std_consumption
                
                anomalies.append({
                    "type": "energy_spike",
                    "device_id": device_id,
                    "device_type": row['device_type'],
                    "room_id": row['room_id'],
                    "building_id": row['building_id'],
                    "timestamp": row['timestamp'].isoformat(),
                    "severity": "high" if spike_magnitude > 4 else "medium",
                    "value": float(row['value']),
                    "expected_range": f"{mean_consumption:.2f} ± {std_consumption:.2f}",
                    "spike_magnitude": float(spike_magnitude),
                    "description": f"Energy consumption spike detected: {row['value']:.2f} kWh (expected: {mean_consumption:.2f})",
                    "recommended_action": self._get_recommended_action(row['device_type'], "energy_spike")
                })
        
        return anomalies
    
    async def _detect_temperature_anomaly(self, data: pd.DataFrame, sensitivity: float) -> List[Dict[str, Any]]:
        """Detect temperature anomalies"""
        
        anomalies = []
        temp_data = data[data['metric_type'] == 'temperature']
        
        for device_id in temp_data['device_id'].unique():
            device_temp = temp_data[temp_data['device_id'] == device_id]
            
            if len(device_temp) < 5:
                continue
            
            values = device_temp['value'].values
            
            # Check for extreme temperatures
            for idx, row in device_temp.iterrows():
                temp = row['value']
                
                # Define normal ranges by device type
                if row['device_type'] == 'hvac':
                    normal_range = (18, 26)  # Celsius
                elif row['device_type'] == 'temperature_sensor':
                    normal_range = (15, 30)
                else:
                    continue
                
                if temp < normal_range[0] or temp > normal_range[1]:
                    severity = "high" if (temp < 10 or temp > 35) else "medium"
                    
                    anomalies.append({
                        "type": "temperature_anomaly",
                        "device_id": device_id,
                        "device_type": row['device_type'],
                        "room_id": row['room_id'],
                        "building_id": row['building_id'],
                        "timestamp": row['timestamp'].isoformat(),
                        "severity": severity,
                        "value": float(temp),
                        "normal_range": normal_range,
                        "description": f"Temperature outside normal range: {temp}°C (expected: {normal_range[0]}-{normal_range[1]}°C)",
                        "recommended_action": self._get_recommended_action(row['device_type'], "temperature_anomaly")
                    })
        
        return anomalies
    
    async def _detect_humidity_anomaly(self, data: pd.DataFrame, sensitivity: float) -> List[Dict[str, Any]]:
        """Detect humidity anomalies"""
        
        anomalies = []
        humidity_data = data[data['metric_type'] == 'humidity']
        
        for device_id in humidity_data['device_id'].unique():
            device_humidity = humidity_data[humidity_data['device_id'] == device_id]
            
            for idx, row in device_humidity.iterrows():
                humidity = row['value']
                
                # Normal humidity range: 30-70%
                if humidity < 20 or humidity > 80:
                    severity = "high" if (humidity < 10 or humidity > 90) else "medium"
                    
                    anomalies.append({
                        "type": "humidity_anomaly",
                        "device_id": device_id,
                        "device_type": row['device_type'],
                        "room_id": row['room_id'],
                        "building_id": row['building_id'],
                        "timestamp": row['timestamp'].isoformat(),
                        "severity": severity,
                        "value": float(humidity),
                        "normal_range": (30, 70),
                        "description": f"Humidity outside normal range: {humidity}% (expected: 30-70%)",
                        "recommended_action": self._get_recommended_action(row['device_type'], "humidity_anomaly")
                    })
        
        return anomalies
    
    async def _detect_occupancy_mismatch(self, data: pd.DataFrame, sensitivity: float) -> List[Dict[str, Any]]:
        """Detect occupancy vs energy consumption mismatches"""
        
        anomalies = []
        
        # Get occupancy and energy data by room
        occupancy_data = data[data['metric_type'] == 'occupancy']
        energy_data = data[data['metric_type'] == 'energy_consumption']
        
        for room_id in occupancy_data['room_id'].unique():
            room_occupancy = occupancy_data[occupancy_data['room_id'] == room_id]
            room_energy = energy_data[energy_data['room_id'] == room_id]
            
            if len(room_occupancy) == 0 or len(room_energy) == 0:
                continue
            
            # Check for high energy consumption with no occupancy
            for _, occ_row in room_occupancy.iterrows():
                if occ_row['value'] == 0:  # No occupancy
                    # Find energy consumption around the same time
                    time_window = timedelta(minutes=30)
                    nearby_energy = room_energy[
                        abs(room_energy['timestamp'] - occ_row['timestamp']) <= time_window
                    ]
                    
                    if len(nearby_energy) > 0:
                        avg_energy = nearby_energy['value'].mean()
                        
                        # If energy consumption is high despite no occupancy
                        if avg_energy > 5.0:  # Threshold in kWh
                            anomalies.append({
                                "type": "occupancy_mismatch",
                                "room_id": room_id,
                                "building_id": occ_row['building_id'],
                                "timestamp": occ_row['timestamp'].isoformat(),
                                "severity": "medium",
                                "occupancy": 0,
                                "energy_consumption": float(avg_energy),
                                "description": f"High energy consumption ({avg_energy:.2f} kWh) with no occupancy detected",
                                "recommended_action": "Check for devices left on or phantom loads"
                            })
        
        return anomalies
    
    async def _detect_device_malfunction(self, data: pd.DataFrame, sensitivity: float) -> List[Dict[str, Any]]:
        """Detect device malfunctions based on erratic behavior"""
        
        anomalies = []
        
        for device_id in data['device_id'].unique():
            device_data = data[data['device_id'] == device_id]
            
            if len(device_data) < 10:
                continue
            
            # Check for devices stuck at same value
            for metric_type in device_data['metric_type'].unique():
                metric_data = device_data[device_data['metric_type'] == metric_type]
                values = metric_data['value'].values
                
                # Check if all values are identical (stuck sensor)
                if len(set(values)) == 1 and len(values) > 5:
                    anomalies.append({
                        "type": "device_malfunction",
                        "device_id": device_id,
                        "device_type": device_data.iloc[0]['device_type'],
                        "room_id": device_data.iloc[0]['room_id'],
                        "building_id": device_data.iloc[0]['building_id'],
                        "timestamp": device_data.iloc[-1]['timestamp'].isoformat(),
                        "severity": "high",
                        "metric_type": metric_type,
                        "stuck_value": float(values[0]),
                        "description": f"Device appears stuck - {metric_type} constant at {values[0]}",
                        "recommended_action": "Inspect device and check connections"
                    })
        
        return anomalies
    
    async def _detect_water_leak(self, data: pd.DataFrame, sensitivity: float) -> List[Dict[str, Any]]:
        """Detect potential water leaks from humidity spikes"""
        
        anomalies = []
        humidity_data = data[data['metric_type'] == 'humidity']
        
        for room_id in humidity_data['room_id'].unique():
            room_humidity = humidity_data[humidity_data['room_id'] == room_id]
            
            if len(room_humidity) < 5:
                continue
            
            values = room_humidity['value'].values
            
            # Look for rapid humidity increases
            for i in range(1, len(values)):
                humidity_change = values[i] - values[i-1]
                
                # Rapid increase in humidity (>20% in short time)
                if humidity_change > 20:
                    row = room_humidity.iloc[i]
                    
                    anomalies.append({
                        "type": "water_leak",
                        "room_id": room_id,
                        "building_id": row['building_id'],
                        "timestamp": row['timestamp'].isoformat(),
                        "severity": "high",
                        "humidity_change": float(humidity_change),
                        "current_humidity": float(values[i]),
                        "description": f"Rapid humidity increase detected: +{humidity_change:.1f}% (possible water leak)",
                        "recommended_action": "Immediate inspection for water leaks or pipe damage"
                    })
        
        return anomalies
    
    def _get_recommended_action(self, device_type: str, anomaly_type: str) -> str:
        """Get recommended action based on device type and anomaly"""
        
        actions = {
            ('hvac', 'energy_spike'): "Check HVAC filters and settings, inspect for blockages",
            ('hvac', 'temperature_anomaly'): "Calibrate temperature sensors, check HVAC operation",
            ('lighting', 'energy_spike'): "Check for faulty bulbs or ballasts",
            ('occupancy_sensor', 'ml_anomaly'): "Clean sensor lens, check mounting position",
            ('temperature_sensor', 'temperature_anomaly'): "Calibrate sensor, check placement",
            ('humidity_sensor', 'humidity_anomaly'): "Check ventilation system, inspect for moisture sources"
        }
        
        return actions.get((device_type, anomaly_type), "Inspect device and check system logs")
