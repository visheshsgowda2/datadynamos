from pydantic_settings import BaseSettings
from typing import Optional

class Settings(BaseSettings):
    # Database
    DATABASE_URL: str = "postgresql://postgres:postgres@localhost:5432/smart_campus"
    
    # OpenAI
    OPENAI_API_KEY: Optional[str] = None
    
    # ML Model Settings
    MODEL_RETRAIN_HOURS: int = 24
    ANOMALY_THRESHOLD: float = 2.0
    FORECAST_CONFIDENCE_LEVEL: float = 0.95
    
    # API Settings
    API_HOST: str = "0.0.0.0"
    API_PORT: int = 8002
    
    class Config:
        env_file = ".env"

settings = Settings()
