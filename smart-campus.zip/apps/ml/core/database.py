import asyncpg
import pandas as pd
from typing import Optional, Dict, Any, List
from datetime import datetime, timedelta
import logging

from core.config import settings

logger = logging.getLogger(__name__)

class DatabaseManager:
    def __init__(self):
        self.pool = None
    
    async def initialize(self):
        """Initialize database connection pool"""
        self.pool = await asyncpg.create_pool(settings.DATABASE_URL)
        logger.info("Database connection pool initialized")
    
    async def close(self):
        """Close database connection pool"""
        if self.pool:
            await self.pool.close()
    
    async def fetch_telemetry_data(
        self, 
        building_id: Optional[int] = None,
        room_id: Optional[int] = None,
        device_id: Optional[int] = None,
        hours_back: int = 24
    ) -> pd.DataFrame:
        """Fetch telemetry data for ML processing"""
        
        query = """
        SELECT 
            t.timestamp,
            t.device_id,
            t.metric_type,
            t.value,
            d.device_type,
            d.room_id,
            r.building_id
        FROM telemetry t
        JOIN devices d ON t.device_id = d.id
        JOIN rooms r ON d.room_id = r.id
        WHERE t.timestamp >= $1
        """
        
        params = [datetime.utcnow() - timedelta(hours=hours_back)]
        
        if building_id:
            query += " AND r.building_id = $" + str(len(params) + 1)
            params.append(building_id)
        
        if room_id:
            query += " AND d.room_id = $" + str(len(params) + 1)
            params.append(room_id)
        
        if device_id:
            query += " AND t.device_id = $" + str(len(params) + 1)
            params.append(device_id)
        
        query += " ORDER BY t.timestamp"
        
        async with self.pool.acquire() as conn:
            rows = await conn.fetch(query, *params)
            
        return pd.DataFrame([dict(row) for row in rows])
    
    async def fetch_energy_rollups(
        self,
        building_id: Optional[int] = None,
        room_id: Optional[int] = None,
        hours_back: int = 168  # 1 week default
    ) -> pd.DataFrame:
        """Fetch energy rollup data for forecasting"""
        
        query = """
        SELECT 
            er.timestamp,
            er.room_id,
            er.total_consumption,
            er.hvac_consumption,
            er.lighting_consumption,
            er.equipment_consumption,
            r.building_id,
            r.name as room_name
        FROM energy_rollups er
        JOIN rooms r ON er.room_id = r.id
        WHERE er.timestamp >= $1
        """
        
        params = [datetime.utcnow() - timedelta(hours=hours_back)]
        
        if building_id:
            query += " AND r.building_id = $" + str(len(params) + 1)
            params.append(building_id)
        
        if room_id:
            query += " AND er.room_id = $" + str(len(params) + 1)
            params.append(room_id)
        
        query += " ORDER BY er.timestamp"
        
        async with self.pool.acquire() as conn:
            rows = await conn.fetch(query, *params)
            
        return pd.DataFrame([dict(row) for row in rows])
    
    async def fetch_occupancy_data(
        self,
        building_id: Optional[int] = None,
        room_id: Optional[int] = None,
        hours_back: int = 168
    ) -> pd.DataFrame:
        """Fetch occupancy data from bookings and sensors"""
        
        query = """
        SELECT 
            b.start_time as timestamp,
            b.room_id,
            1 as occupancy,
            r.building_id
        FROM bookings b
        JOIN rooms r ON b.room_id = r.id
        WHERE b.start_time >= $1 AND b.status = 'confirmed'
        
        UNION ALL
        
        SELECT 
            t.timestamp,
            d.room_id,
            CASE WHEN t.value > 0 THEN 1 ELSE 0 END as occupancy,
            r.building_id
        FROM telemetry t
        JOIN devices d ON t.device_id = d.id
        JOIN rooms r ON d.room_id = r.id
        WHERE t.timestamp >= $1 
        AND d.device_type = 'occupancy_sensor'
        AND t.metric_type = 'occupancy'
        """
        
        params = [datetime.utcnow() - timedelta(hours=hours_back)]
        
        if building_id:
            query += " AND r.building_id = $" + str(len(params) + 1)
            params.append(building_id)
        
        if room_id:
            query += " AND r.room_id = $" + str(len(params) + 1)
            params.append(room_id)
        
        query += " ORDER BY timestamp"
        
        async with self.pool.acquire() as conn:
            rows = await conn.fetch(query, *params)
            
        return pd.DataFrame([dict(row) for row in rows])

# Global database manager instance
db_manager = DatabaseManager()

async def get_db_connection():
    """Dependency for getting database connection"""
    if not db_manager.pool:
        await db_manager.initialize()
    return db_manager
