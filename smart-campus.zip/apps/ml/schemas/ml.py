from pydantic import BaseModel, Field
from typing import Optional, List, Dict, Any
from datetime import datetime

# Forecasting Schemas
class ForecastRequest(BaseModel):
    building_id: Optional[int] = None
    room_id: Optional[int] = None
    forecast_hours: int = Field(default=24, ge=1, le=168)  # 1 hour to 1 week
    include_confidence: bool = True

class ForecastResponse(BaseModel):
    forecasts: List[Dict[str, Any]]
    forecast_horizon_hours: int
    generated_at: str
    model_type: str

# Anomaly Detection Schemas
class AnomalyDetectionRequest(BaseModel):
    building_id: Optional[int] = None
    room_id: Optional[int] = None
    device_id: Optional[int] = None
    hours_back: int = Field(default=24, ge=1, le=168)
    sensitivity: float = Field(default=0.1, ge=0.01, le=1.0)

class AnomalyDetectionResponse(BaseModel):
    anomalies: List[Dict[str, Any]]
    total_anomalies: int
    analysis_period_hours: int
    generated_at: str
    sensitivity: float

# Optimization Schemas
class OptimizationRequest(BaseModel):
    building_id: Optional[int] = None
    room_id: Optional[int] = None
    optimization_hours: int = Field(default=24, ge=1, le=168)
    target_comfort: float = Field(default=22.0, ge=18.0, le=26.0)  # Target temperature
    energy_weight: float = Field(default=0.7, ge=0.0, le=1.0)  # Weight for energy vs comfort

class OptimizationResponse(BaseModel):
    optimized_schedules: List[Dict[str, Any]]
    optimization_horizon_hours: int
    estimated_savings: Dict[str, float]
    generated_at: str

# GenAI Schemas
class GenAIRequest(BaseModel):
    # For bill summaries
    current_bill_id: Optional[int] = None
    previous_bill_id: Optional[int] = None
    
    # For compliance reports
    building_id: Optional[int] = None
    report_period: Optional[str] = None
    compliance_data: Optional[Dict[str, Any]] = None
    
    # Common
    context: Optional[Dict[str, Any]] = None

class GenAIResponse(BaseModel):
    generated_text: str
    summary_type: str
    generated_at: str
    word_count: int
    key_insights: List[str]
