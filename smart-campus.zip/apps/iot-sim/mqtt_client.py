"""
MQTT client for device communication
"""

import asyncio
import json
from typing import Dict, Any, Callable, Optional
import structlog
from asyncio_mqtt import Client
import os

logger = structlog.get_logger()

class MQTTClient:
    """MQTT client wrapper for device communication"""
    
    def __init__(self):
        self.broker_url = os.getenv("MQTT_BROKER_URL", "mqtt://localhost:1883")
        self.client: Optional[Client] = None
        self.message_handlers: Dict[str, Callable] = {}
        
    async def connect(self):
        """Connect to MQTT broker"""
        try:
            # Parse broker URL
            if self.broker_url.startswith("mqtt://"):
                host = self.broker_url.replace("mqtt://", "").split(":")[0]
                port = int(self.broker_url.split(":")[-1]) if ":" in self.broker_url else 1883
            else:
                host = "localhost"
                port = 1883
            
            self.client = Client(hostname=host, port=port)
            await self.client.__aenter__()
            
            logger.info("Connected to MQTT broker", host=host, port=port)
            
        except Exception as e:
            logger.error("Failed to connect to MQTT broker", error=str(e))
            raise
    
    async def disconnect(self):
        """Disconnect from MQTT broker"""
        if self.client:
            await self.client.__aexit__(None, None, None)
            logger.info("Disconnected from MQTT broker")
    
    async def publish(self, topic: str, payload: Dict[str, Any]):
        """Publish message to MQTT topic"""
        if not self.client:
            logger.warning("MQTT client not connected")
            return
        
        try:
            message = json.dumps(payload)
            await self.client.publish(topic, message)
            
            logger.debug("Published MQTT message", topic=topic, payload=payload)
            
        except Exception as e:
            logger.error("Failed to publish MQTT message", topic=topic, error=str(e))
    
    async def subscribe(self, topic_pattern: str, handler: Callable):
        """Subscribe to MQTT topic pattern"""
        if not self.client:
            logger.warning("MQTT client not connected")
            return
        
        try:
            await self.client.subscribe(topic_pattern)
            self.message_handlers[topic_pattern] = handler
            
            logger.info("Subscribed to MQTT topic", pattern=topic_pattern)
            
            # Start message listener task
            asyncio.create_task(self._message_listener(topic_pattern))
            
        except Exception as e:
            logger.error("Failed to subscribe to MQTT topic", pattern=topic_pattern, error=str(e))
    
    async def _message_listener(self, topic_pattern: str):
        """Listen for messages on subscribed topics"""
        if not self.client:
            return
        
        try:
            async with self.client.messages() as messages:
                async for message in messages:
                    if message.topic.matches(topic_pattern):
                        try:
                            payload = json.loads(message.payload.decode())
                            handler = self.message_handlers.get(topic_pattern)
                            
                            if handler:
                                await handler(str(message.topic), payload)
                                
                        except json.JSONDecodeError:
                            logger.warning("Invalid JSON in MQTT message", topic=str(message.topic))
                        except Exception as e:
                            logger.error("Error handling MQTT message", topic=str(message.topic), error=str(e))
                            
        except Exception as e:
            logger.error("Error in MQTT message listener", pattern=topic_pattern, error=str(e))
