"""
Telemetry data generator with realistic patterns
"""

import asyncio
import random
import math
from datetime import datetime, timedelta
from typing import Dict, Any, List
import structlog
import numpy as np

from mqtt_client import MQTTClient
from api_client import APIClient

logger = structlog.get_logger()

class TelemetryGenerator:
    """Generates realistic telemetry data for devices"""
    
    def __init__(self, mqtt_client: MQTTClient, api_client: APIClient):
        self.mqtt_client = mqtt_client
        self.api_client = api_client
        self.devices: List[Dict[str, Any]] = []
        self.rooms: List[Dict[str, Any]] = []
        self.running = False
        self.tasks: List[asyncio.Task] = []
        
    async def start(self):
        """Start telemetry generation"""
        try:
            # Load devices and rooms
            self.devices = await self.api_client.get_devices()
            self.rooms = await self.api_client.get_rooms()
            
            logger.info("Starting telemetry generation", 
                       device_count=len(self.devices), 
                       room_count=len(self.rooms))
            
            self.running = True
            
            # Start telemetry generation tasks
            self.tasks.append(asyncio.create_task(self._generate_device_telemetry()))
            self.tasks.append(asyncio.create_task(self._generate_energy_rollups()))
            self.tasks.append(asyncio.create_task(self._simulate_occupancy_patterns()))
            
        except Exception as e:
            logger.error("Failed to start telemetry generation", error=str(e))
            raise
    
    async def stop(self):
        """Stop telemetry generation"""
        self.running = False
        
        # Cancel all tasks
        for task in self.tasks:
            task.cancel()
        
        # Wait for tasks to complete
        await asyncio.gather(*self.tasks, return_exceptions=True)
        
        logger.info("Telemetry generation stopped")
    
    async def _generate_device_telemetry(self):
        """Generate telemetry data for individual devices"""
        while self.running:
            try:
                current_time = datetime.utcnow()
                
                for device in self.devices:
                    await self._generate_device_metrics(device, current_time)
                
                # Wait 5 seconds before next generation cycle
                await asyncio.sleep(5)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error("Error in device telemetry generation", error=str(e))
                await asyncio.sleep(5)
    
    async def _generate_device_metrics(self, device: Dict[str, Any], timestamp: datetime):
        """Generate metrics for a specific device"""
        device_id = device["id"]
        device_type = device["type"]
        device_state = device.get("state", {})
        room_id = device["room_id"]
        
        # Parse room location for MQTT topic
        room_parts = room_id.split("-")
        if len(room_parts) >= 3:
            building_id = room_parts[0]
            floor_id = f"{room_parts[0]}-{room_parts[1]}"
            room_name = room_parts[2]
        else:
            building_id = "UNKNOWN"
            floor_id = "UNKNOWN"
            room_name = "UNKNOWN"
        
        telemetry_data = []
        
        if device_type == "light":
            # Light power consumption
            if device_state.get("power", False):
                base_power = 15.0
                brightness_factor = device_state.get("brightness", 80) / 100.0
                power = base_power * brightness_factor + random.uniform(-2, 2)
            else:
                power = random.uniform(0, 0.5)  # Standby power
            
            telemetry_data.append({
                "metric": "power_w",
                "value": max(0, power),
                "tags": {"device_type": "light", "room_id": room_id}
            })
            
        elif device_type == "hvac":
            # HVAC power consumption with daily patterns
            hour = timestamp.hour
            base_power = self._get_hvac_base_power(hour, device_state)
            
            # Add some randomness
            power = base_power + random.uniform(-0.3, 0.3)
            
            telemetry_data.append({
                "metric": "power_kw",
                "value": max(0.2, power),
                "tags": {"device_type": "hvac", "room_id": room_id}
            })
            
            # HVAC temperature
            target_temp = device_state.get("temperature", 22)
            current_temp = target_temp + random.uniform(-1, 1)
            
            telemetry_data.append({
                "metric": "temperature_setpoint",
                "value": target_temp,
                "tags": {"device_type": "hvac", "room_id": room_id}
            })
            
        elif device_type == "sensor":
            # Occupancy sensor
            occupancy = self._simulate_occupancy(timestamp, room_id)
            
            telemetry_data.append({
                "metric": "occupancy",
                "value": 1.0 if occupancy else 0.0,
                "tags": {"device_type": "sensor", "room_id": room_id}
            })
            
            # Temperature sensor
            base_temp = 22.0
            daily_variation = 2.0 * math.sin(2 * math.pi * timestamp.hour / 24)
            temperature = base_temp + daily_variation + random.uniform(-0.5, 0.5)
            
            telemetry_data.append({
                "metric": "temperature",
                "value": temperature,
                "tags": {"device_type": "sensor", "room_id": room_id}
            })
            
            # Humidity sensor
            base_humidity = 45.0
            humidity = base_humidity + random.uniform(-5, 5)
            
            telemetry_data.append({
                "metric": "humidity",
                "value": max(20, min(80, humidity)),
                "tags": {"device_type": "sensor", "room_id": room_id}
            })
            
        elif device_type == "projector":
            # Projector power consumption
            if device_state.get("power", False):
                power = random.uniform(180, 220)  # Typical projector power
            else:
                power = random.uniform(0, 2)  # Standby power
            
            telemetry_data.append({
                "metric": "power_w",
                "value": power,
                "tags": {"device_type": "projector", "room_id": room_id}
            })
            
        elif device_type == "plug":
            # Smart plug power consumption
            if device_state.get("power", False):
                # Simulate connected device power
                power = random.uniform(10, 150)
            else:
                power = 0
            
            telemetry_data.append({
                "metric": "power_w",
                "value": power,
                "tags": {"device_type": "plug", "room_id": room_id}
            })
        
        # Publish telemetry data
        for data in telemetry_data:
            topic = f"campus/{building_id}/{floor_id}/{room_name}/{device_id.split('-')[-1]}/telemetry"
            
            payload = {
                "device_id": device_id,
                "timestamp": timestamp.isoformat(),
                "metric": data["metric"],
                "value": data["value"],
                "tags": data["tags"]
            }
            
            await self.mqtt_client.publish(topic, payload)
            
            # Also send to API for storage
            try:
                await self.api_client.post_telemetry(payload)
            except Exception as e:
                logger.warning("Failed to send telemetry to API", device_id=device_id, error=str(e))
    
    def _get_hvac_base_power(self, hour: int, device_state: Dict[str, Any]) -> float:
        """Calculate HVAC base power consumption based on time and settings"""
        # Business hours have higher consumption
        if 7 <= hour <= 18:
            base = 2.5
        elif 19 <= hour <= 22:
            base = 1.8
        else:
            base = 1.2
        
        # Adjust based on temperature setpoint
        target_temp = device_state.get("temperature", 22)
        if target_temp < 20:
            base *= 0.8  # Eco mode
        elif target_temp > 24:
            base *= 1.3  # High cooling/heating
        
        # Mode adjustments
        mode = device_state.get("mode", "auto")
        if mode == "eco":
            base *= 0.7
        elif mode == "boost":
            base *= 1.4
        
        return base
    
    def _simulate_occupancy(self, timestamp: datetime, room_id: str) -> bool:
        """Simulate occupancy based on time patterns and room type"""
        hour = timestamp.hour
        day_of_week = timestamp.weekday()  # 0 = Monday
        
        # Weekend has lower occupancy
        if day_of_week >= 5:
            base_prob = 0.1
        else:
            # Weekday occupancy patterns
            if 8 <= hour <= 12:
                base_prob = 0.7  # Morning peak
            elif 13 <= hour <= 17:
                base_prob = 0.6  # Afternoon
            elif 18 <= hour <= 20:
                base_prob = 0.2  # Evening
            else:
                base_prob = 0.05  # Night/early morning
        
        # Room type adjustments
        if "CONF" in room_id or "MEET" in room_id:
            # Meeting rooms have more sporadic usage
            base_prob *= 0.6
        elif "OFFICE" in room_id:
            # Offices have more consistent usage
            base_prob *= 1.2
        elif "LAB" in room_id:
            # Labs might have extended hours
            if 8 <= hour <= 22:
                base_prob *= 1.1
        
        return random.random() < base_prob
    
    async def _generate_energy_rollups(self):
        """Generate room-level energy rollups"""
        while self.running:
            try:
                current_time = datetime.utcnow()
                
                for room in self.rooms:
                    await self._generate_room_energy(room, current_time)
                
                # Wait 1 minute before next rollup
                await asyncio.sleep(60)
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error("Error in energy rollup generation", error=str(e))
                await asyncio.sleep(60)
    
    async def _generate_room_energy(self, room: Dict[str, Any], timestamp: datetime):
        """Generate energy consumption for a room"""
        room_id = room["id"]
        
        # Get room devices (simplified - in real implementation, query from API)
        room_devices = [d for d in self.devices if d["room_id"] == room_id]
        
        # Calculate total room power consumption
        total_kw = 0.0
        
        for device in room_devices:
            device_state = device.get("state", {})
            device_type = device["type"]
            
            if device_type == "light" and device_state.get("power", False):
                brightness = device_state.get("brightness", 80) / 100.0
                total_kw += 0.015 * brightness  # 15W max per light
                
            elif device_type == "hvac":
                hour = timestamp.hour
                hvac_power = self._get_hvac_base_power(hour, device_state)
                total_kw += hvac_power
                
            elif device_type == "projector" and device_state.get("power", False):
                total_kw += 0.2  # 200W projector
                
            elif device_type == "plug" and device_state.get("power", False):
                total_kw += random.uniform(0.01, 0.15)  # Variable plug load
        
        # Add base load (always-on systems)
        total_kw += random.uniform(0.1, 0.3)
        
        # Calculate kWh increment (1 minute = 1/60 hour)
        kwh_increment = total_kw / 60
        
        # Parse room location for MQTT topic
        room_parts = room_id.split("-")
        if len(room_parts) >= 3:
            building_id = room_parts[0]
            floor_id = f"{room_parts[0]}-{room_parts[1]}"
            room_name = room_parts[2]
        else:
            building_id = "UNKNOWN"
            floor_id = "UNKNOWN"
            room_name = "UNKNOWN"
        
        # Publish energy data
        topic = f"campus/{building_id}/{floor_id}/{room_name}/energy"
        
        payload = {
            "room_id": room_id,
            "timestamp": timestamp.isoformat(),
            "kw": round(total_kw, 3),
            "kwh_increment": round(kwh_increment, 4),
            "device_count": len(room_devices)
        }
        
        await self.mqtt_client.publish(topic, payload)
        
        # Send to API
        try:
            await self.api_client.post_energy_data(payload)
        except Exception as e:
            logger.warning("Failed to send energy data to API", room_id=room_id, error=str(e))
    
    async def _simulate_occupancy_patterns(self):
        """Simulate realistic occupancy patterns based on bookings"""
        while self.running:
            try:
                # This would integrate with booking system to create realistic occupancy
                # For now, just add some variation to the base patterns
                await asyncio.sleep(300)  # Check every 5 minutes
                
            except asyncio.CancelledError:
                break
            except Exception as e:
                logger.error("Error in occupancy simulation", error=str(e))
                await asyncio.sleep(300)
