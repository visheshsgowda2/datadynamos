"""
API client for communicating with the Smart Campus API
"""

import aiohttp
import asyncio
from typing import Dict, Any, List, Optional
import structlog
import os

logger = structlog.get_logger()

class APIClient:
    """HTTP client for Smart Campus API"""
    
    def __init__(self):
        self.base_url = os.getenv("API_BASE_URL", "http://localhost:8000")
        self.session: Optional[aiohttp.ClientSession] = None
        
    async def _get_session(self) -> aiohttp.ClientSession:
        """Get or create HTTP session"""
        if not self.session:
            self.session = aiohttp.ClientSession(
                timeout=aiohttp.ClientTimeout(total=30)
            )
        return self.session
    
    async def close(self):
        """Close HTTP session"""
        if self.session:
            await self.session.close()
    
    async def get_devices(self) -> List[Dict[str, Any]]:
        """Get all devices from API"""
        try:
            session = await self._get_session()
            
            async with session.get(f"{self.base_url}/api/v1/devices") as response:
                if response.status == 200:
                    data = await response.json()
                    return data.get("devices", [])
                else:
                    logger.warning("Failed to get devices", status=response.status)
                    return []
                    
        except Exception as e:
            logger.error("Error getting devices from API", error=str(e))
            return []
    
    async def get_rooms(self) -> List[Dict[str, Any]]:
        """Get all rooms from API"""
        try:
            session = await self._get_session()
            
            async with session.get(f"{self.base_url}/api/v1/rooms") as response:
                if response.status == 200:
                    data = await response.json()
                    return data.get("rooms", [])
                else:
                    logger.warning("Failed to get rooms", status=response.status)
                    return []
                    
        except Exception as e:
            logger.error("Error getting rooms from API", error=str(e))
            return []
    
    async def update_device_state(self, device_id: str, state: Dict[str, Any]) -> bool:
        """Update device state in API"""
        try:
            session = await self._get_session()
            
            payload = {"state": state}
            
            async with session.put(
                f"{self.base_url}/api/v1/devices/{device_id}/state",
                json=payload
            ) as response:
                if response.status == 200:
                    return True
                else:
                    logger.warning("Failed to update device state", 
                                 device_id=device_id, status=response.status)
                    return False
                    
        except Exception as e:
            logger.error("Error updating device state", device_id=device_id, error=str(e))
            return False
    
    async def post_telemetry(self, telemetry_data: Dict[str, Any]) -> bool:
        """Post telemetry data to API"""
        try:
            session = await self._get_session()
            
            async with session.post(
                f"{self.base_url}/api/v1/telemetry",
                json=telemetry_data
            ) as response:
                if response.status in [200, 201]:
                    return True
                else:
                    logger.debug("Failed to post telemetry", status=response.status)
                    return False
                    
        except Exception as e:
            logger.debug("Error posting telemetry", error=str(e))
            return False
    
    async def post_energy_data(self, energy_data: Dict[str, Any]) -> bool:
        """Post energy data to API"""
        try:
            session = await self._get_session()
            
            async with session.post(
                f"{self.base_url}/api/v1/energy",
                json=energy_data
            ) as response:
                if response.status in [200, 201]:
                    return True
                else:
                    logger.debug("Failed to post energy data", status=response.status)
                    return False
                    
        except Exception as e:
            logger.debug("Error posting energy data", error=str(e))
            return False
    
    async def get_bookings(self, room_id: Optional[str] = None) -> List[Dict[str, Any]]:
        """Get bookings from API"""
        try:
            session = await self._get_session()
            
            url = f"{self.base_url}/api/v1/bookings"
            if room_id:
                url += f"?room_id={room_id}"
            
            async with session.get(url) as response:
                if response.status == 200:
                    data = await response.json()
                    return data.get("bookings", [])
                else:
                    logger.warning("Failed to get bookings", status=response.status)
                    return []
                    
        except Exception as e:
            logger.error("Error getting bookings from API", error=str(e))
            return []
