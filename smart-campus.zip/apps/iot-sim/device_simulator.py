"""
Device simulator that responds to commands and maintains state
"""

import asyncio
import json
import random
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
import structlog

from mqtt_client import MQTTClient
from api_client import APIClient

logger = structlog.get_logger()

class DeviceSimulator:
    """Simulates IoT devices and handles commands"""
    
    def __init__(self, mqtt_client: MQTTClient, api_client: APIClient):
        self.mqtt_client = mqtt_client
        self.api_client = api_client
        self.devices: Dict[str, Dict[str, Any]] = {}
        self.running = False
        
    async def initialize(self):
        """Initialize device simulator with devices from API"""
        try:
            # Fetch devices from API
            devices_data = await self.api_client.get_devices()
            
            for device_data in devices_data:
                device_id = device_data["id"]
                self.devices[device_id] = {
                    "id": device_id,
                    "room_id": device_data["room_id"],
                    "type": device_data["type"],
                    "model": device_data["model"],
                    "state": device_data.get("state", {}),
                    "last_command": None,
                    "last_update": datetime.utcnow()
                }
            
            logger.info("Initialized device simulator", device_count=len(self.devices))
            
        except Exception as e:
            logger.error("Failed to initialize device simulator", error=str(e))
            raise
    
    async def start_command_listener(self):
        """Start listening for device commands"""
        # Subscribe to device command topics
        await self.mqtt_client.subscribe("campus/+/+/+/+/command", self._handle_device_command)
        
        logger.info("Started device command listener")
    
    async def _handle_device_command(self, topic: str, payload: Dict[str, Any]):
        """Handle device command from MQTT"""
        try:
            # Parse topic: campus/{building}/{floor}/{room}/{device}/command
            topic_parts = topic.split("/")
            if len(topic_parts) != 6:
                logger.warning("Invalid command topic format", topic=topic)
                return
            
            building_id = topic_parts[1]
            floor_id = topic_parts[2]
            room_id = topic_parts[3]
            device_id = topic_parts[4]
            
            # Find device
            full_device_id = f"{building_id}-{floor_id}-{room_id}-{device_id}"
            device = self.devices.get(full_device_id)
            
            if not device:
                logger.warning("Device not found for command", device_id=full_device_id)
                return
            
            # Process command
            await self._process_device_command(device, payload)
            
            # Send acknowledgment
            ack_topic = f"campus/{building_id}/{floor_id}/{room_id}/{device_id}/ack"
            ack_payload = {
                "device_id": full_device_id,
                "command": payload,
                "status": "success",
                "timestamp": datetime.utcnow().isoformat(),
                "new_state": device["state"]
            }
            
            await self.mqtt_client.publish(ack_topic, ack_payload)
            
            logger.info("Processed device command", device_id=full_device_id, command=payload)
            
        except Exception as e:
            logger.error("Error handling device command", topic=topic, error=str(e))
    
    async def _process_device_command(self, device: Dict[str, Any], command: Dict[str, Any]):
        """Process a specific device command"""
        device_type = device["type"]
        action = command.get("action")
        target = command.get("target")
        value = command.get("value")
        
        # Update device state based on command
        if action == "set":
            if device_type == "light":
                if target == "power":
                    device["state"]["power"] = bool(value)
                elif target == "brightness":
                    device["state"]["brightness"] = max(0, min(100, int(value)))
                    
            elif device_type == "hvac":
                if target == "temperature":
                    device["state"]["temperature"] = max(16, min(30, float(value)))
                elif target == "mode":
                    device["state"]["mode"] = str(value)
                elif target == "power":
                    device["state"]["power"] = bool(value)
                    
            elif device_type == "projector":
                if target == "power":
                    device["state"]["power"] = bool(value)
                elif target == "input":
                    device["state"]["input"] = str(value)
                    
            elif device_type == "plug":
                if target == "power":
                    device["state"]["power"] = bool(value)
        
        elif action == "toggle":
            if target == "power" and "power" in device["state"]:
                device["state"]["power"] = not device["state"]["power"]
        
        # Update timestamps
        device["last_command"] = command
        device["last_update"] = datetime.utcnow()
        
        # Update device state in API
        try:
            await self.api_client.update_device_state(device["id"], device["state"])
        except Exception as e:
            logger.warning("Failed to update device state in API", device_id=device["id"], error=str(e))
    
    async def apply_scene(self, room_id: str, scene_payload: Dict[str, Any]):
        """Apply a scene to all devices in a room"""
        room_devices = [d for d in self.devices.values() if d["room_id"] == room_id]
        
        for device in room_devices:
            device_type = device["type"]
            
            if device_type in scene_payload:
                scene_config = scene_payload[device_type]
                
                # Apply scene configuration to device
                for key, value in scene_config.items():
                    if key in ["power", "brightness", "temperature", "mode"]:
                        device["state"][key] = value
                
                device["last_update"] = datetime.utcnow()
                
                # Update in API
                try:
                    await self.api_client.update_device_state(device["id"], device["state"])
                except Exception as e:
                    logger.warning("Failed to update device state", device_id=device["id"], error=str(e))
        
        logger.info("Applied scene to room", room_id=room_id, device_count=len(room_devices))
    
    async def get_device_state(self, device_id: str) -> Optional[Dict[str, Any]]:
        """Get current device state"""
        return self.devices.get(device_id)
    
    async def stop(self):
        """Stop device simulator"""
        self.running = False
        logger.info("Device simulator stopped")
