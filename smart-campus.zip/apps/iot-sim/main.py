"""
Smart Campus IoT Simulator
Generates synthetic telemetry data and responds to device commands
"""

import asyncio
import json
import logging
import random
import signal
import sys
from datetime import datetime, timedelta
from typing import Dict, Any, List
import structlog
from dotenv import load_dotenv
import os

from mqtt_client import MQTTClient
from device_simulator import DeviceSimulator
from telemetry_generator import TelemetryGenerator
from api_client import APIClient

# Load environment variables
load_dotenv()

# Configure logging
structlog.configure(
    processors=[
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso"),
        structlog.processors.JSONRenderer()
    ],
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
    cache_logger_on_first_use=True,
)

logger = structlog.get_logger()

class IoTSimulator:
    """Main IoT simulator orchestrator"""
    
    def __init__(self):
        self.mqtt_client = MQTTClient()
        self.api_client = APIClient()
        self.device_simulator = DeviceSimulator(self.mqtt_client, self.api_client)
        self.telemetry_generator = TelemetryGenerator(self.mqtt_client, self.api_client)
        self.running = False
        
    async def start(self):
        """Start the IoT simulator"""
        logger.info("Starting Smart Campus IoT Simulator")
        
        try:
            # Connect to MQTT broker
            await self.mqtt_client.connect()
            
            # Initialize device simulator
            await self.device_simulator.initialize()
            
            # Start telemetry generation
            await self.telemetry_generator.start()
            
            # Start device command listener
            await self.device_simulator.start_command_listener()
            
            self.running = True
            logger.info("IoT Simulator started successfully")
            
            # Keep running
            while self.running:
                await asyncio.sleep(1)
                
        except Exception as e:
            logger.error("Error starting IoT simulator", error=str(e))
            raise
    
    async def stop(self):
        """Stop the IoT simulator"""
        logger.info("Stopping IoT Simulator")
        self.running = False
        
        await self.telemetry_generator.stop()
        await self.device_simulator.stop()
        await self.mqtt_client.disconnect()
        
        logger.info("IoT Simulator stopped")

# Global simulator instance
simulator = IoTSimulator()

async def signal_handler(signum, frame):
    """Handle shutdown signals"""
    logger.info("Received shutdown signal", signal=signum)
    await simulator.stop()
    sys.exit(0)

async def main():
    """Main entry point"""
    # Set up signal handlers
    signal.signal(signal.SIGINT, lambda s, f: asyncio.create_task(signal_handler(s, f)))
    signal.signal(signal.SIGTERM, lambda s, f: asyncio.create_task(signal_handler(s, f)))
    
    try:
        await simulator.start()
    except KeyboardInterrupt:
        await simulator.stop()
    except Exception as e:
        logger.error("Fatal error in IoT simulator", error=str(e))
        await simulator.stop()
        sys.exit(1)

if __name__ == "__main__":
    asyncio.run(main())
